# PSI-walk-test

## Requirements

- python 3.6+
- install library

```text
pip install -r requirements.txt
```

## Test

```text
python main.py {PSI_graph_path}
```

- For example:

```text
python main.py data/b8ed9d07e772bbc43bf44d09eb302fda00fab1f931e0496ff78dcb033db49b36.txt
```
