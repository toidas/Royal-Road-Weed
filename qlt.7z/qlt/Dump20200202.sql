-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mvt
-- ------------------------------------------------------
-- Server version	5.5.62

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `chuyen_tau`
--

LOCK TABLES `chuyen_tau` WRITE;
/*!40000 ALTER TABLE `chuyen_tau` DISABLE KEYS */;
INSERT INTO `chuyen_tau` VALUES (1,'2020-01-10 00:00:00',1,1,1,NULL),(2,'2019-11-26 21:13:00',1,1,2,NULL),(3,'2020-01-10 00:00:00',1,1,1,NULL),(4,'2020-01-10 00:00:00',1,1,1,NULL),(5,'2020-01-10 00:00:00',1,1,1,NULL);
/*!40000 ALTER TABLE `chuyen_tau` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `doan_duong`
--

LOCK TABLES `doan_duong` WRITE;
/*!40000 ALTER TABLE `doan_duong` DISABLE KEYS */;
INSERT INTO `doan_duong` VALUES (1,'1',1,1),(2,'2',4,1),(3,'3',5,1),(4,'4',6,1),(5,'1',1,2),(6,'2',9,2),(7,'3',7,2),(8,'4',8,2),(9,'5',10,2);
/*!40000 ALTER TABLE `doan_duong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `doan_tau`
--

LOCK TABLES `doan_tau` WRITE;
/*!40000 ALTER TABLE `doan_tau` DISABLE KEYS */;
INSERT INTO `doan_tau` VALUES (1,'VietNam','1','2019-11-26 21:13:00','Tau1'),(2,'VietNam','2','2019-11-26 21:13:00','Tau2');
/*!40000 ALTER TABLE `doan_tau` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ga`
--

LOCK TABLES `ga` WRITE;
/*!40000 ALTER TABLE `ga` DISABLE KEYS */;
INSERT INTO `ga` VALUES (1,'Hà Nội'),(2,'Hà Nam'),(3,'Hưng Yên'),(4,'Bắc Ninh'),(5,'Hải Dương'),(6,'Hải Phòng'),(7,'Ninh Bình'),(8,'Thanh Hóa'),(9,'Nam Định'),(10,'Hà Tĩnh');
/*!40000 ALTER TABLE `ga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ghe`
--

LOCK TABLES `ghe` WRITE;
/*!40000 ALTER TABLE `ghe` DISABLE KEYS */;
INSERT INTO `ghe` VALUES (1,'1',1),(2,'2',1),(3,'3',1),(4,'4',1),(5,'1',2),(6,'2',2),(7,'3',2),(8,'4',2),(9,'1',3),(10,'2',3),(11,'3',3),(12,'4',3);
/*!40000 ALTER TABLE `ghe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `giuong`
--

LOCK TABLES `giuong` WRITE;
/*!40000 ALTER TABLE `giuong` DISABLE KEYS */;
INSERT INTO `giuong` VALUES (1,'1',1),(2,'2',1),(3,'1',2),(4,'2',2),(5,'1',3),(6,'2',3),(7,'1',4),(8,'2',4),(9,'1',5),(10,'2',5),(11,'1',6),(12,'2',6);
/*!40000 ALTER TABLE `giuong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `khach_hang`
--

LOCK TABLES `khach_hang` WRITE;
/*!40000 ALTER TABLE `khach_hang` DISABLE KEYS */;
INSERT INTO `khach_hang` VALUES ('1','Hà Nội','kh1@gmail.com','Nguyễn Văn Nam','2019-11-26 21:13:00'),('2','Hà Nội','kh2@gmail.com','Nguyễn Thị Mây','2019-11-26 21:13:00');
/*!40000 ALTER TABLE `khach_hang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `phong`
--

LOCK TABLES `phong` WRITE;
/*!40000 ALTER TABLE `phong` DISABLE KEYS */;
INSERT INTO `phong` VALUES (1,'1',1),(2,'2',1),(3,'1',2),(4,'2',2),(5,'1',3),(6,'2',3);
/*!40000 ALTER TABLE `phong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tknhan_vien`
--

LOCK TABLES `tknhan_vien` WRITE;
/*!40000 ALTER TABLE `tknhan_vien` DISABLE KEYS */;
INSERT INTO `tknhan_vien` VALUES (1,'123','Nữ','Nguyễn','123456','2019-11-26 21:13:00','Thị','Hà','tk1','QuanLy'),(2,'124','Nam','Nguyễn','123456','2019-11-26 21:13:00','Văn','An','tk2','TinHoc'),(3,'125','Nữ','Nguyễn','123456','2019-11-26 21:13:00','Quỳnh','Mai','tk3','BanVe');
/*!40000 ALTER TABLE `tknhan_vien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tknhan_vien_ban_ve`
--

LOCK TABLES `tknhan_vien_ban_ve` WRITE;
/*!40000 ALTER TABLE `tknhan_vien_ban_ve` DISABLE KEYS */;
INSERT INTO `tknhan_vien_ban_ve` VALUES (1,3);
/*!40000 ALTER TABLE `tknhan_vien_ban_ve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tknhan_vien_quan_ly`
--

LOCK TABLES `tknhan_vien_quan_ly` WRITE;
/*!40000 ALTER TABLE `tknhan_vien_quan_ly` DISABLE KEYS */;
INSERT INTO `tknhan_vien_quan_ly` VALUES (1,1);
/*!40000 ALTER TABLE `tknhan_vien_quan_ly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tknhan_vien_tin_hoc`
--

LOCK TABLES `tknhan_vien_tin_hoc` WRITE;
/*!40000 ALTER TABLE `tknhan_vien_tin_hoc` DISABLE KEYS */;
INSERT INTO `tknhan_vien_tin_hoc` VALUES (1,2);
/*!40000 ALTER TABLE `tknhan_vien_tin_hoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tknhan_viensdt`
--

LOCK TABLES `tknhan_viensdt` WRITE;
/*!40000 ALTER TABLE `tknhan_viensdt` DISABLE KEYS */;
INSERT INTO `tknhan_viensdt` VALUES (1,'0123456789',1),(2,'0123654789',1),(3,'123456789',2),(4,'1025487856',3);
/*!40000 ALTER TABLE `tknhan_viensdt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `toa`
--

LOCK TABLES `toa` WRITE;
/*!40000 ALTER TABLE `toa` DISABLE KEYS */;
INSERT INTO `toa` VALUES (1,'Ghe',1,'1'),(2,'Ghe',1,'2'),(3,'Ghe',1,'3'),(4,'Giuong',1,'4'),(5,'Giuong',1,'5'),(6,'Giuong',1,'6');
/*!40000 ALTER TABLE `toa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `toa_ghe`
--

LOCK TABLES `toa_ghe` WRITE;
/*!40000 ALTER TABLE `toa_ghe` DISABLE KEYS */;
INSERT INTO `toa_ghe` VALUES (1,'Ghe mềm',1),(2,'Ghe cứng',2),(3,'Ghe cứng',3);
/*!40000 ALTER TABLE `toa_ghe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `toa_giuong`
--

LOCK TABLES `toa_giuong` WRITE;
/*!40000 ALTER TABLE `toa_giuong` DISABLE KEYS */;
INSERT INTO `toa_giuong` VALUES (1,'Giường Đơn',4),(2,'Giường Đôi',5),(3,'Giường Đôi',6);
/*!40000 ALTER TABLE `toa_giuong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tuyen`
--

LOCK TABLES `tuyen` WRITE;
/*!40000 ALTER TABLE `tuyen` DISABLE KEYS */;
INSERT INTO `tuyen` VALUES (1,'Hà Nội-Hải Phòng'),(2,'Hà Nội-Hà Tĩnh');
/*!40000 ALTER TABLE `tuyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ve`
--

LOCK TABLES `ve` WRITE;
/*!40000 ALTER TABLE `ve` DISABLE KEYS */;
INSERT INTO `ve` VALUES (1,'Hải Phòng','Hà Nội',123456,'Ghe','2019-11-26 21:13:00','2019-11-26 21:13:00','1',1),(2,'Hải Phòng','Hà Nội',1457,'Giuong','2019-11-26 21:13:00','2019-11-26 21:13:00','2',1);
/*!40000 ALTER TABLE `ve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ve_ghe`
--

LOCK TABLES `ve_ghe` WRITE;
/*!40000 ALTER TABLE `ve_ghe` DISABLE KEYS */;
INSERT INTO `ve_ghe` VALUES (1,1,5);
/*!40000 ALTER TABLE `ve_ghe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ve_giuong`
--

LOCK TABLES `ve_giuong` WRITE;
/*!40000 ALTER TABLE `ve_giuong` DISABLE KEYS */;
INSERT INTO `ve_giuong` VALUES (1,2,6);
/*!40000 ALTER TABLE `ve_giuong` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-02 23:28:30
