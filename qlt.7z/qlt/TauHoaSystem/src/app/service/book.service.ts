import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  trainList = [];
  gadi = "Hà Nội";
  gaden = "Hải Dương";
  date = "2020-01-10 00:00:00";

  maCT = 1;
  // gadi = "";
  // gaden = "";
  // date = "";
  constructor() { }
}
