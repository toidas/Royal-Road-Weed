import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FileService {

  constructor(private http : HttpClient) { }

  uploadFile(formdata){
   let url = environment.host +'/upload';
   return this.http.post(url,formdata);
  }
   
  generateDoc() {
    let url = environment.host+ '/gen_table';
    return this.http.get(url);
  }
}
