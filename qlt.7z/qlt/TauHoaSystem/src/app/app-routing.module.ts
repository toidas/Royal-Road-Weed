import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainLayoutComponent} from './main-layout/main-layout.component';
import { LoginComponent } from './account/login/login.component';
import { UserBookComponent } from './container/user-book/user-book.component';
import {TrainBookComponent} from "./container/train-book/train-book.component";
import {TrainBookDetailComponent} from "./container/train-book/train-book-detail/train-book-detail.component";
const routes: Routes = [
  { path: '',   redirectTo: '/user-book', pathMatch: 'full' },
  { path: 'user-book', component: UserBookComponent },
  { path: 'train-book', component: TrainBookComponent },
  { path: 'train-book/:id', component: TrainBookDetailComponent },
  { path:'login' , component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
