import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BookService } from '../../service/book.service';

@Component({
  selector: 'app-user-book',
  templateUrl: './user-book.component.html',
  styleUrls: ['./user-book.component.css']
})
export class UserBookComponent implements OnInit {
  public list = [];
  public dateTime: any;
  public gaDi: any;
  public gaDen: any;

  constructor( public router: Router,private httpClient: HttpClient,private bookService: BookService) { 
  }

  ngOnInit() {
    this.getGa();
    // this.list = [
    //   {id: 1, label: 'a', value: 'a'},
    //   {id: 2, label: 'b', value: 'b'}
    // ];
    
  }

  getGa(){
    this.httpClient.get('http://localhost:7000/api/ga/get-all-ga-by-name').subscribe((data)=>{
      let gas = data as any[]
      this.list = [];
      gas.forEach((element,i) => {
        this.list.push({id: element.maGa, label: element.diaDiem, value: element.diaDiem});
      });
      console.log(this.list);
    });
  }

  convertDate(date){
    // Year
      var year = date.getFullYear();

      // Month
      var month = date.getMonth();
      if(month<=9){
        month = "0"+month;
      }

      // Day
      var day = date.getDate();
      if(day<=9){
        day = "0"+day;
      }

      // Hours
      var hours = "00";

      // Minutes
      var minutes = "00";

      // Seconds
      var seconds = "00";

      // Display date time in MM-dd-yyyy h:m:s format
      var convdataTime = year+'-'+month+'-'+day+' '+hours + ':' + minutes + ':' + seconds;

      return convdataTime;
  }

  public search(): void {
    let dateTime = new Date().setFullYear(this.dateTime.year, this.dateTime.month, this.dateTime.day);
    let k = new Date(dateTime);
    // let dateString = _dateTime.toDateString("yyyy-MM-dd");
    console.log(this.convertDate(k) + "/" +this.gaDi +"/"+this.gaDen);
    this.bookService.gadi = this.gaDi;
    this.bookService.gaden = this.gaDen;
    this.bookService.date = this.convertDate(k);
    this.router.navigate(['/train-book']);
  }

  public isDisable(): boolean {
    return !this.gaDi || !this.gaDen || !this.dateTime;
  }

  goLogin(){
    console.log("hahahahha");
    this.router.navigate(['/login']);
  }
}
