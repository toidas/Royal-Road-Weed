import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { BookService } from '../../service/book.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-train-book',
  templateUrl: './train-book.component.html',
  styleUrls: ['./train-book.component.css']
})
export class TrainBookComponent implements OnInit {
  public trainList = [];
  public size = 10;
  public paginationPage = {
    page: 1,
    pageSize: 5
  };
  constructor(public router: Router,private bookService: BookService,private httpClient: HttpClient) { }

  ngOnInit() {
    this.trainList = this.bookService.trainList;
    // this.trainList = [
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'},
    //   {maCT: 'CT01', doanTau: 'DT01', gaDi: 'Ha Nội', gaDen: 'Hai Phòng', ngayXP: '01/01/2020', gioXP: '09'}
    // ];
    this.getChuyenTau();
  }

  convertDate(date){
    // Year
      var year = date.getFullYear();

      // Month
      var month = date.getMonth();
      if(month<=9){
        month = "0"+month;
      }

      // Day
      var day = date.getDate();
      if(day<=9){
        day = "0"+day;
      }

      // Hours
      var hours = "00";

      // Minutes
      var minutes = "00";

      // Seconds
      var seconds = "00";

      // Display date time in MM-dd-yyyy h:m:s format
      var convdataTime = year+'-'+month+'-'+day+' '+hours + ':' + minutes + ':' + seconds;

      return convdataTime;
  }

  getChuyenTau(){
    
    let gadi = this.bookService.gadi;
    if(gadi == ""){
      this.router.navigate(['/user-book']);
    }
    let gaden = this.bookService.gaden;
    let date = this.bookService.date;
    this.httpClient.get('http://localhost:7000/api/chuyentau/get-chuyen-tau-by-tuyen/'+gadi+"/"+gaden+"/"+date).subscribe((data)=>{
      let chuyentaus = data['content'] as any[]
      console.log(data);
      this.trainList = [];
      this.size = data['totalElements'];
      chuyentaus.forEach((element,i) => {
        let date = new Date(element.thoiGianXP);
        let dateString = this.convertDate(date);
        this.trainList.push({maCT: element.maCT, doanTau: element.maTau.tenTau, tuyen: element.maTuyen.tenTuyen,ngayXP:dateString});
      });
    });
  }

  public showDetail(train: any): void {
    this.bookService.maCT = train.maCT;
    this.router.navigate(['/train-book/' + train.maCT]);
  }
}
