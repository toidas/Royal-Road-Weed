import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainBookComponent } from './train-book.component';

describe('TrainBookComponent', () => {
  let component: TrainBookComponent;
  let fixture: ComponentFixture<TrainBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
