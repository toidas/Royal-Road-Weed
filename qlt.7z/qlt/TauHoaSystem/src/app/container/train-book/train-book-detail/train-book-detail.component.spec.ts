import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainBookDetailComponent } from './train-book-detail.component';

describe('TrainBookDetailComponent', () => {
  let component: TrainBookDetailComponent;
  let fixture: ComponentFixture<TrainBookDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainBookDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainBookDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
