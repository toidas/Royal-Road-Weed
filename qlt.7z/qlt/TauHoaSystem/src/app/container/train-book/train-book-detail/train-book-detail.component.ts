import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {NgbModal, NgbModalConfig} from "@ng-bootstrap/ng-bootstrap";
import { BookService } from '../../../service/book.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-train-book-detail',
  templateUrl: './train-book-detail.component.html',
  styleUrls: ['./train-book-detail.component.css']
})
export class TrainBookDetailComponent implements OnInit {
  public ticketList = [];
  public ticketsShow = [];
  public chuyentau : any;
  public isValid : false;
  public typesList = [
    {name: 'Ghế', value: 'ghế'},
    {name: 'Giường', value: 'giường'}
  ];
  public radioSelected: any;
  public paginationPage = {
    page: 1,
    pageSize: 10
  };
  public customerInfo = {
    name: '',
    idCard: '',
    address: '',
    email: ''
  };

  constructor(public router: Router,
              private activatedRoute: ActivatedRoute,
              public modalConfig: NgbModalConfig,
              private modalService: NgbModal,private bookService: BookService,private httpClient: HttpClient) { }

  
  getGheTrong(){
    let maCT = this.bookService.maCT;
    this.httpClient.get('http://localhost:7000/api/ghe/get-ghe-by-ct/'+maCT).subscribe((data)=>{
      let ghes = data['content'] as any[]
      console.log(data);
      this.ticketsShow = [];
      ghes.forEach((element,i) => {
        let giaVe = 0;
        if(this.chuyentau.giaVe != null){
          giaVe = this.chuyentau.giaVe;
        }
        this.ticketsShow.push({maVe:element.soHieuGhe, soghe:element.soGhe , tau:element.maToaGhe.maToa.maTau.tenTau , toa:element.maToaGhe.maToa.maToa , loai:element.maToaGhe.maToa.loai , gia:giaVe});
      });
    });
  }

  getCT(){
    let maCT = this.bookService.maCT;
    this.httpClient.get('http://localhost:7000/api/chuyentau/get-chuyen-tau-by-mact/'+maCT).subscribe((data)=>{
      this.chuyentau = data;
      this.getGheTrong();
    });
  }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    this.radioSelected = this.typesList[0].value;
    this.getCT();
  }



  getTicketList(): void {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    console.log(id);
    this.radioSelected = this.typesList[0].value;
    // this.ticketList = [
    //   {maVe: 'T01', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T02', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'giường', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T03', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T04', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T05', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'giường', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T06', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T07', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'giường', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T08', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T09', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'giường', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T10', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T11', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'giường', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T12', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T13', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T14', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T15', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T16', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'},
    //   {maVe: 'T17', diemDi: 'Hà Nội', diemDen: 'Hải Phòng', loai: 'ghế', ngayXP: '01/01/2020', gia: '500.000', gioXP: '90:00'}
    // ];
    // this.ticketsShow = this.ticketList.filter(function (item) {
    //   return item.loai === 'ghế';
    // });
  }

  public onItemChange(item: any): void {

    

    this.ticketsShow = this.ticketList.filter(function (ticket) {
      return ticket.loai === item.value;
    });
  }

  public book(content: any): void {
    this.modalService.open(content);
  }

  public isDisabled(): boolean {
    return !this.customerInfo.name || !this.customerInfo.idCard;
  }

  public pay(): void {
    console.log(this.customerInfo);
  }
}
