import { Component, OnInit } from '@angular/core';
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public trainList = [];
  public paginationPage = {
    page: 1,
    pageSize: 10
  };
  public trainTrip: any;
  public fleetList = [];
  public fleet: any;
  public gaList = [];
  public gaDi: any;
  public gaDen: any;
  public dateTime: any;
  public btnNamePopup: any;
  constructor(private modalService: NgbModal) { }

  ngOnInit() {
    this.trainList = [
      {maCT: 'CT01', doanTau: 'DT01', gaDi: {maGa: 'G01', tenGa: 'Hà Nội'}, gaDen: {maGa: 'G02', tenGa: 'Hải Phòng'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT02', gaDi: {maGa: 'G02', tenGa: 'Hải Phòng'}, gaDen: {maGa: 'G01', tenGa: 'Hà Nội'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT03', gaDi: {maGa: 'G01', tenGa: 'Hà Nội'}, gaDen: {maGa: 'G03', tenGa: 'Đà Lạt'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT04', gaDi: {maGa: 'G03', tenGa: 'Đà Lạt'}, gaDen: {maGa: 'G01', tenGa: 'Hà Nội'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT05', gaDi: {maGa: 'G02', tenGa: 'Hải Phòng'}, gaDen: {maGa: 'G03', tenGa: 'Đà Lạt'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT05', gaDi: {maGa: 'G03', tenGa: 'Đà Lạt'}, gaDen: {maGa: 'G02', tenGa: 'Hải Phòng'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT04', gaDi: {maGa: 'G02', tenGa: 'Hải Phòng'}, gaDen: {maGa: 'G04', tenGa: 'Kim Liên'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT03', gaDi: {maGa: 'G04', tenGa: 'Kim Liên'}, gaDen: {maGa: 'G02', tenGa: 'Hải Phòng'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT02', gaDi: {maGa: 'G04', tenGa: 'Kim Liên'}, gaDen: {maGa: 'G01', tenGa: 'Hà Nội'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT01', gaDi: {maGa: 'G04', tenGa: 'Kim Liên'}, gaDen: {maGa: 'G03', tenGa: 'Đà Lạt'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT02', gaDi: {maGa: 'G03', tenGa: 'Đà Lạt'}, gaDen: {maGa: 'G04', tenGa: 'Kim Liên'}, ngayXP: '01/01/2020', gioXP: '09'},
      {maCT: 'CT01', doanTau: 'DT03', gaDi: {maGa: 'G01', tenGa: 'Hà Nội'}, gaDen: {maGa: 'G04', tenGa: 'Kim Liên'}, ngayXP: '01/01/2020', gioXP: '09'}
    ];
    this.fleetList = [
      {value: 'DT01', label: 'Đoàn tàu 1'},
      {value: 'DT02', label: 'Đoàn tàu 2'},
      {value: 'DT03', label: 'Đoàn tàu 3'},
      {value: 'DT04', label: 'Đoàn tàu 4'},
      {value: 'DT05', label: 'Đoàn tàu 5'}
    ];
    this.gaList = [
      {value: 'G01', label: 'Hà Nội'},
      {value: 'G02', label: 'Hải Phòng'},
      {value: 'G03', label: 'Đà Lạt'},
      {value: 'G04', label: 'Kim Liên'}
    ];
  }

  public openEdit(content: any, train: any) {
    if (train) {
      this.btnNamePopup = 'Cập nhật';
      this.trainTrip = train;
      this.fleet = this.trainTrip.doanTau;
      this.gaDi = this.trainTrip.gaDi.maGa;
      this.gaDen = this.trainTrip.gaDen.maGa;
    } else {
      this.btnNamePopup = 'Lưu';
      this.trainTrip = {};
      this.gaDi = '';
      this.fleet = '';
      this.gaDen = '';
      this.trainTrip.maCT = 'CT02';
    }
    this.modalService.open(content);
  }

  public save(): void {

  }

  public isDisabled(): boolean {
    return false;
  }
}
