import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-sidebar',
  templateUrl: './setting-sidebar.component.html',
  styleUrls: ['./setting-sidebar.component.css']
})
export class SettingSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
