import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainLayoutComponent } from './main-layout.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SettingSidebarComponent } from './setting-sidebar/setting-sidebar.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { FooterComponent } from './footer/footer.component';
import { DropzoneModule } from 'ngx-dropzone-wrapper';

import { NgxDropzoneModule } from 'ngx-dropzone';
// Import angular-fusioncharts
import { FusionChartsModule } from 'angular-fusioncharts';

// Import FusionCharts library
import * as FusionCharts from 'fusioncharts';

// Load FusionCharts Individual Charts
import * as Charts from 'fusioncharts/fusioncharts.charts';
import * as FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { NgxSpinnerModule } from "ngx-spinner";
import { PageWrapperModule } from './page-wrapper/page-wrapper.module';
import {SelectModule} from "ng-select";
FusionChartsModule.fcRoot(FusionCharts, Charts,FusionTheme)
@NgModule({
  declarations: [MainLayoutComponent, SidebarComponent, SettingSidebarComponent, TopBarComponent, FooterComponent],
  imports: [
    CommonModule,
    PageWrapperModule,
    DropzoneModule,
    NgxDropzoneModule,
    FusionChartsModule,
    NgxSpinnerModule,
    SelectModule
  ],
  providers: [
  ],
  exports: [MainLayoutComponent]
})
export class MainLayoutModule { }
