import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageWrapperComponent } from './page-wrapper.component';
import { DashboardComponent } from 'src/app/container/dashboard/dashboard.component';
import { TrainBookComponent } from 'src/app/container/train-book/train-book.component';
import { PageRoutingModule } from './page-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import {NgbModule, NgbPaginationModule} from "@ng-bootstrap/ng-bootstrap";
import {SelectModule} from "ng-select";
import {FormsModule} from "@angular/forms";

@NgModule({
  declarations: [PageWrapperComponent,DashboardComponent,TrainBookComponent],
  imports: [
    BrowserModule,
    CommonModule,
    PageRoutingModule,
    NgbPaginationModule,
    SelectModule,
    FormsModule,
    NgbModule
  ],
  exports:[PageWrapperComponent]
})
export class PageWrapperModule { }
