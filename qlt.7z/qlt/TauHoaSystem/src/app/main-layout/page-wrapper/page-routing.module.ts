import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from 'src/app/container/dashboard/dashboard.component';
import { TrainBookComponent } from 'src/app/container/train-book/train-book.component';
import { MainLayoutComponent } from '../main-layout.component';
import {TrainBookDetailComponent} from "../../container/train-book/train-book-detail/train-book-detail.component";
const routes: Routes = [
  {
    path: 'dashboard',
    component: MainLayoutComponent,
    children: [
      {
        path: '',
        component: DashboardComponent
      },
    ]
  },
  {
    path: 'book',
    component: MainLayoutComponent,
    children: [
      {
        path: '',
        component: TrainBookComponent,
        children: [
          {
            path: '',
            component: TrainBookDetailComponent
          }
        ]
      },
    ]
  },
];
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(
      routes
    )
  ],
  exports:[RouterModule]
})
export class PageRoutingModule { }
