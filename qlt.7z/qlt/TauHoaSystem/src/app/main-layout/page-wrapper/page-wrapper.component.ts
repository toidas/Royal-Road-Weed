import { Component, OnInit } from '@angular/core';
import { FileService } from '../../service/file.service';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import * as $ from 'jquery';
import 'bootstrap';

const data = {
  chart: {
    caption: "",
    drawanchors: "0",
    plottooltext: "<b>$dataValue</b> iPhones sold in $label",
    theme: "fusion",
    showValues: "1",
    placeValuesInside: "0",
    divLineColor: "#ffffff",
    yAxisValueFontColor: "#fff",
    showPlotBorder: "1",
    plotBorderThickness: "5",
    // plotFillColor: "#69D5D1",
    drawFullAreaBorder: "0",
   
  },
  data: [
    {
      label: "2007",
      value: "1380000"
    },
    {
      label: "2008",
      value: "1450000"
    },
    {
      label: "2009",
      value: "1610000"
    },
    {
      label: "2010",
      value: "1540000"
    },
    {
      label: "2011",
      value: "1480000"
    },
    {
      label: "2012",
      value: "1573000"
    },
    {
      label: "2013",
      value: "2232000"
    },
    {
      label: "2014",
      value: "2476000"
    },
    {
      label: "2015",
      value: "2832000"
    },
    {
      label: "2016",
      value: "3808000"
    }
  ]
};
@Component({
  selector: 'app-page-wrapper',
  templateUrl: './page-wrapper.component.html',
  styleUrls: ['./page-wrapper.component.css']
})


export class PageWrapperComponent implements OnInit {
  width = 600;
  height = 400;
  type = "splinearea";
  dataFormat = "json";
  dataSource = data;

  files1: File[] = [];
  files2: File[] = [];
  link : string;
  isDisabled: boolean = true;
  timer: any;
  number: number = 10;
  fixedNumber: number = 10;
  constructor(private fileService: FileService,private toastr: ToastrService,private spinner: NgxSpinnerService) { }

  ngOnInit() {
  }
  
  onSelectRawData(event) {
    this.files1.push(...event.addedFiles);
    let form = new FormData;
    form.append('file',this.files1[0]);
    this.spinner.show();
    this.fileService.uploadFile(form).subscribe(res=> {
      this.link = res['content'];
      this.isDisabled = false;
      this.toastr.success('Upload Successfully!', 'Notice');
      this.spinner.hide();
    },err => {
      this.toastr.error(JSON.stringify(err.message), 'Notice');
      this.spinner.hide();
    })

  }
   
  onRemoveRawData(event) {
    this.files1.splice(this.files1.indexOf(event), 1);
    this.link = '#';
    this.isDisabled = true;
  }

  onSelectFixedData(event) {
    this.files2.push(...event.addedFiles);
  }
   
  onRemoveFixedData(event) {
    this.files2.splice(this.files2.indexOf(event), 1);
  }
  download(){
    clearInterval(this.timer);
    this.number = 10;

    $('#exampleModalCenter').modal('show');
    this.timer = setInterval(() => {
       if(this.number === 0) {
           $('#exampleModalCenter').modal('hide');
           clearInterval(this.timer);
       } else {
        this.number--;
       }
    },1000)
    // this.spinner.show();
    // this.fileService.generateDoc().subscribe(res => {
    //    this.link = res['url']
    //    window.open(this.link);
    //    this.isDisabled = true;
    //    this.spinner.hide();

    // },err => {
    //    this.toastr.error(JSON.stringify(err.message), 'Notice');
    //    this.spinner.hide();
    // })
  }

  clearDatabase(){

  }
}
