import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainLayoutModule } from './main-layout/main-layout.module';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { LoginModule } from './account/login.module';
import { UserBookComponent } from './container/user-book/user-book.component';
import {SelectModule} from "ng-select";
import {FormsModule} from "@angular/forms";
import { TrainBookDetailComponent } from './container/train-book/train-book-detail/train-book-detail.component';


@NgModule({
  declarations: [
    AppComponent,
    UserBookComponent,
    TrainBookDetailComponent

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MainLayoutModule,
    LoginModule,
    ToastrModule.forRoot(),
    NgbModule,
    SelectModule,
    FormsModule
  ],
  providers: [],
  exports: [
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
