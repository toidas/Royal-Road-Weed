package com.example.mvt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mvt.dto.ChuyenTauDTO;
import com.example.mvt.dto.book.GheDTO;
import com.example.mvt.service.ChuyenTauService;
import com.example.mvt.service.GheService;

@RestController
@RequestMapping(value = "api/ghe" , produces = "application/json")
public class GheController {
	@Autowired
	GheService gheService;
	
	@GetMapping("/get-ghe-by-ct/{maCT}/{page}/{size}")
	public Page<GheDTO> getGheByCT(@PathVariable(name = "maCT") Long maCT,@PathVariable(name = "page") int page,@PathVariable(name = "size") int size) {
		return gheService.getGheTrongByChuyenTau(maCT, page, size);
	}
	
	@GetMapping("/get-ghe-by-ct/{maCT}")
	public Page<GheDTO> getGheByCT(@PathVariable(name = "maCT") Long maCT) {
		return gheService.getGheTrongByChuyenTau(maCT, 0, 10000);
	}
}
