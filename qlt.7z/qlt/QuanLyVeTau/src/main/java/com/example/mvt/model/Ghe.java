package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Ghe")
public class Ghe {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long soHieuGhe;
	
	@Column(name = "so_ghe")
	private String soGhe;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_toa_ghe")
	private ToaGhe maToaGhe;
	
	@OneToMany(mappedBy = "soHieuGhe", cascade = CascadeType.REMOVE)
	private Set<VeGhe> veGhe;

	public Long getSoHieuGhe() {
		return soHieuGhe;
	}

	public void setSoHieuGhe(Long soHieuGhe) {
		this.soHieuGhe = soHieuGhe;
	}

	
	public String getSoGhe() {
		return soGhe;
	}

	public void setSoGhe(String soGhe) {
		this.soGhe = soGhe;
	}

	public Set<VeGhe> getVeGhe() {
		return veGhe;
	}

	public void setVeGhe(Set<VeGhe> veGhe) {
		this.veGhe = veGhe;
	}

	public ToaGhe getMaToaGhe() {
		return maToaGhe;
	}

	public void setMaToaGhe(ToaGhe maToaGhe) {
		this.maToaGhe = maToaGhe;
	}

}
