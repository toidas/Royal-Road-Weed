package com.example.mvt.service;

import org.springframework.data.domain.Page;

import com.example.mvt.dto.ChuyenTauDTO;
import com.example.mvt.model.ChuyenTau;

public interface ChuyenTauService {
	Page<ChuyenTauDTO> getChuyenTauByTuyen(String gadi,String gaden,String date,int page,int size);
	
	ChuyenTauDTO getChuyenTauByMaCT(Long mact);
}
