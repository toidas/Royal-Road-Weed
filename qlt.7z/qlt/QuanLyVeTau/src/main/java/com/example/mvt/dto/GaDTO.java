package com.example.mvt.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.example.mvt.model.DoanDuong;

public class GaDTO {
	private Long maGa;
	private String diaDiem;

	public Long getMaGa() {
		return maGa;
	}

	public void setMaGa(Long maGa) {
		this.maGa = maGa;
	}

	public String getDiaDiem() {
		return diaDiem;
	}

	public void setDiaDiem(String diaDiem) {
		this.diaDiem = diaDiem;
	}

}
