package com.example.mvt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mvt.dto.ChuyenTauDTO;
import com.example.mvt.dto.GaDTO;
import com.example.mvt.service.ChuyenTauService;

@RestController
@RequestMapping(value = "api/chuyentau" , produces = "application/json")
public class ChuyenTauController {
	@Autowired
	ChuyenTauService chuyenTauService;
	
	@GetMapping("/get-chuyen-tau-by-tuyen/{gadi}/{gaden}/{date}/{page}/{size}")
	public Page<ChuyenTauDTO> getChuyenTauByTuyen(@PathVariable(name = "gadi") String gadi,@PathVariable(name = "gaden") String gaden,@PathVariable(name = "date") String date,@PathVariable(name = "page") int page,@PathVariable(name = "size") int size) {
		return chuyenTauService.getChuyenTauByTuyen(gadi, gaden, date, page, size);
	}
	
	@GetMapping("/get-chuyen-tau-by-tuyen/{gadi}/{gaden}/{date}")
	public Page<ChuyenTauDTO> getChuyenTauByTuyen(@PathVariable(name = "gadi") String gadi,@PathVariable(name = "gaden") String gaden,@PathVariable(name = "date") String date) {
		return chuyenTauService.getChuyenTauByTuyen(gadi, gaden, date, 0, 10000);
	}
	
	@GetMapping("/get-chuyen-tau-by-mact/{mact}")
	public ChuyenTauDTO getChuyenTauByMaCT(@PathVariable(name = "mact") Long mact) {
		return chuyenTauService.getChuyenTauByMaCT(mact);
	}
}
