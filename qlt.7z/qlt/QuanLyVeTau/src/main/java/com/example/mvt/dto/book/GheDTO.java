package com.example.mvt.dto.book;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.example.mvt.model.ToaGhe;
import com.example.mvt.model.VeGhe;

public class GheDTO {
	private Long soHieuGhe;
	private String soGhe;
	private ToaGheDTO maToaGhe;
	public Long getSoHieuGhe() {
		return soHieuGhe;
	}
	public void setSoHieuGhe(Long soHieuGhe) {
		this.soHieuGhe = soHieuGhe;
	}
	public String getSoGhe() {
		return soGhe;
	}
	public void setSoGhe(String soGhe) {
		this.soGhe = soGhe;
	}
	public ToaGheDTO getMaToaGhe() {
		return maToaGhe;
	}
	public void setMaToaGhe(ToaGheDTO maToaGhe) {
		this.maToaGhe = maToaGhe;
	}
	
	
}
