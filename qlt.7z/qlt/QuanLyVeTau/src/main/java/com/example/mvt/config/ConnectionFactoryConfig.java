package com.example.mvt.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.social.connect.ConnectionFactoryLocator;
import org.springframework.social.connect.support.ConnectionFactoryRegistry;
import org.springframework.social.facebook.connect.FacebookConnectionFactory;

@Configuration
public class ConnectionFactoryConfig {
	
	@Value("${facebook.clientId}")
    private String facebookClientId;
	
    @Value("${facebook.clientSecret}")
    private String facebookClientSecret;
    
//    private static String facebookClientId;
//	private static String facebookClientSecret;
//
//	@Value("${facebook.clientId}")
//	public void setClientID(String facebookClientId) {
//		facebookClientId = facebookClientId;
//	}
//	
//	@Value("${facebook.clientSecret}")
//	public void setClientSecret(String facebookClientSecret) {
//		facebookClientSecret = facebookClientSecret;
//	}
	
    @Bean
    public ConnectionFactoryLocator connectionFactoryLocator() {
        ConnectionFactoryRegistry registry = new ConnectionFactoryRegistry();
        registry.addConnectionFactory(new FacebookConnectionFactory(facebookClientId, facebookClientSecret));
        return registry;
    }

    
	
}
