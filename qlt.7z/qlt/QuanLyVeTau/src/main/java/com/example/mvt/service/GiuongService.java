package com.example.mvt.service;

import org.springframework.data.domain.Page;

import com.example.mvt.dto.book.GheDTO;
import com.example.mvt.dto.book.GiuongDTO;

public interface GiuongService {
	Page<GiuongDTO> getGiuongTrongByChuyenTau(Long maCT,int page,int size);
}
