package com.example.mvt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.mvt.dto.book.GheDTO;
import com.example.mvt.dto.book.GiuongDTO;
import com.example.mvt.model.Ghe;
import com.example.mvt.model.Giuong;
import com.example.mvt.repository.GheRepository;
import com.example.mvt.repository.GiuongRepository;
import com.example.mvt.service.GiuongService;
import com.example.mvt.service.util.MapperUtils;

@Service
public class GiuongServiceImpl implements GiuongService{
	
	@Autowired
	GiuongRepository giuongRepository;
	
	@Override
	public Page<GiuongDTO> getGiuongTrongByChuyenTau(Long maCT, int page, int size) {
		PageRequest pageable = PageRequest.of(page, size);
		
		 Page<Giuong> giuongPage = giuongRepository.getGiuongTrongByChuyenTau(maCT, pageable);
		 Page<GiuongDTO> giuongPageDTO = giuongPage.map(entity -> {
		        if (entity != null) {
		            return MapperUtils.toDto(entity, GiuongDTO.class);
		        }
		        return null;
		    });
		 return giuongPageDTO;
	}

}
