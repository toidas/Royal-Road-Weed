package com.example.mvt.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mvt.common.ResponseResult;
import com.example.mvt.common.StandardResponse;
import com.example.mvt.dto.GaDTO;
import com.example.mvt.model.Ga;
import com.example.mvt.model.QGa;
import com.example.mvt.model.User;
import com.example.mvt.repository.GaRepository;
import com.example.mvt.service.GaService;
import com.example.mvt.service.util.MapperUtils;

@RestController
@RequestMapping(value = "api/ga" , produces = "application/json")
public class GaController {
	
	@Autowired
	GaService gaService;
	
	@GetMapping("/get-all-ga-by-name/{name}")
	public List<GaDTO> getGaAllByName(@PathVariable(name = "name" , required = false ) String name) {
		return gaService.getGaAllByName(name);
	}
	
	@GetMapping("/get-all-ga-by-name")
	public List<GaDTO> getGaAll() {
		return gaService.getGaAllByName("");
	}
}
