package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Phong")
public class Phong {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long soHieuPhong;
	
	@Column(name = "so_phong")
	private String soPhong;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_toa_giuong")
	private ToaGiuong maToaGiuong;
	
	@OneToMany(mappedBy = "maPhong", cascade = CascadeType.REMOVE)
	private Set<Giuong> giuongs;

	public Long getSoHieuPhong() {
		return soHieuPhong;
	}

	public void setSoHieuPhong(Long soHieuPhong) {
		this.soHieuPhong = soHieuPhong;
	}

	public String getSoPhong() {
		return soPhong;
	}

	public void setSoPhong(String soPhong) {
		this.soPhong = soPhong;
	}

	public ToaGiuong getMaToaGiuong() {
		return maToaGiuong;
	}

	public void setMaToaGiuong(ToaGiuong maToaGiuong) {
		this.maToaGiuong = maToaGiuong;
	}

	public Set<Giuong> getGiuongs() {
		return giuongs;
	}

	public void setGiuongs(Set<Giuong> giuongs) {
		this.giuongs = giuongs;
	}
	
	
}
