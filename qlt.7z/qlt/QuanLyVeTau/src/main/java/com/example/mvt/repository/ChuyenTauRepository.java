package com.example.mvt.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.mvt.model.ChuyenTau;
import com.example.mvt.model.Ga;

@Repository
public interface ChuyenTauRepository extends JpaRepository<ChuyenTau, Long>, QuerydslPredicateExecutor<ChuyenTau>{
	@Query(value = "SELECT * FROM mvt.chuyen_tau Where ma_tuyen IN (SELECT e.ma_tuyen FROM (SELECT batdau.ma_tuyen FROM (SELECT a.ma_tuyen,a.diem FROM mvt.doan_duong as a,mvt.ga as b Where a.ma_ga = b.ma_ga And b.dia_dem = ?1) as batdau , (SELECT a.ma_tuyen,a.diem FROM mvt.doan_duong as a,mvt.ga as b Where a.ma_ga = b.ma_ga And b.dia_dem = ?2) as ketthuc Where batdau.ma_tuyen = ketthuc.ma_tuyen And batdau.diem < ketthuc.diem) as kqtuyen , mvt.tuyen as e Where kqtuyen.ma_tuyen = e.ma_tuyen) And thoi_gian_xp = ?3", nativeQuery = true)
	Page<ChuyenTau> getChuyenTauByTuyen(String gadi,String gaden,String date,Pageable pageable);
}
