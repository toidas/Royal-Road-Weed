package com.example.mvt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.mvt.model.User;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);
    
    Optional<User> findByid(Long id);
    
    Optional<User> findByFacebookID(String facebookID);

    Boolean existsByEmail(String email);
    
    @Query(value = "SELECT * FROM users WHERE email = :usernameOrEmail OR username = :usernameOrEmail" , nativeQuery = true)
    List<User> findByEmailOrUserName(@Param("usernameOrEmail") String usernameOrEmail); 
    
    @Query(value = "SELECT * FROM users WHERE id = :id" , nativeQuery = true)
    List<User> findCurrentUser(@Param("id") Long id); 
    
    Optional<User> findByUsername(String username);
}
