package com.example.mvt.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.example.mvt.model.ChuyenTau;
import com.example.mvt.model.Toa;

public class DoanTauDTO {

	private Long maTau;
	private String tenTau;
	private String hangSX;
	private String ngayVH;
	private String loai;
	private Set<ToaDTO> toas;
	public Long getMaTau() {
		return maTau;
	}
	public void setMaTau(Long maTau) {
		this.maTau = maTau;
	}
	public String getTenTau() {
		return tenTau;
	}
	public void setTenTau(String tenTau) {
		this.tenTau = tenTau;
	}
	public String getHangSX() {
		return hangSX;
	}
	public void setHangSX(String hangSX) {
		this.hangSX = hangSX;
	}
	public String getNgayVH() {
		return ngayVH;
	}
	public void setNgayVH(String ngayVH) {
		this.ngayVH = ngayVH;
	}
	public String getLoai() {
		return loai;
	}
	public void setLoai(String loai) {
		this.loai = loai;
	}
	public Set<ToaDTO> getToas() {
		return toas;
	}
	public void setToas(Set<ToaDTO> toas) {
		this.toas = toas;
	}
}
