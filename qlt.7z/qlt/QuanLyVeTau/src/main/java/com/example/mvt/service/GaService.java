package com.example.mvt.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.example.mvt.dto.GaDTO;

public interface GaService {
	List<GaDTO> getGaAllByName(String name);
}
