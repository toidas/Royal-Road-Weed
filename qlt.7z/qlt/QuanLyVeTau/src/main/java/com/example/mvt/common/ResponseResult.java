package com.example.mvt.common;

public interface ResponseResult {

	Integer SUCCESS_CODE = 200;
	String SUCCESS_MESSAGE = "success";

	Integer FAIL_CODE = 417;
	String FAIL_MESSAGE = "fail";
}
