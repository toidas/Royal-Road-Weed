package com.example.mvt.controller;

public class DataFacebook {
	PictureFacebook data;

	public PictureFacebook getData() {
		return data;
	}

	public void setData(PictureFacebook data) {
		this.data = data;
	}

}
