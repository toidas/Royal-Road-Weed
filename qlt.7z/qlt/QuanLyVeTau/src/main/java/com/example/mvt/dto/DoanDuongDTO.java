package com.example.mvt.dto;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.example.mvt.model.Ga;

public class DoanDuongDTO {
	private Long id;
	private String diem;
	private GaDTO maGa;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDiem() {
		return diem;
	}

	public void setDiem(String diem) {
		this.diem = diem;
	}

	public GaDTO getMaGa() {
		return maGa;
	}

	public void setMaGa(GaDTO maGa) {
		this.maGa = maGa;
	}
}
