package com.example.mvt.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.example.mvt.model.ChuyenTau;
import com.example.mvt.model.DoanDuong;

public class TuyenDTO {
	private Long maTuyen;
	private String tenTuyen;
	private Set<DoanDuongDTO> DoanDuongs;

	public Long getMaTuyen() {
		return maTuyen;
	}

	public void setMaTuyen(Long maTuyen) {
		this.maTuyen = maTuyen;
	}

	public String getTenTuyen() {
		return tenTuyen;
	}

	public void setTenTuyen(String tenTuyen) {
		this.tenTuyen = tenTuyen;
	}

	public Set<DoanDuongDTO> getDoanDuongs() {
		return DoanDuongs;
	}

	public void setDoanDuongs(Set<DoanDuongDTO> doanDuongs) {
		DoanDuongs = doanDuongs;
	}
}
