package com.example.mvt.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import com.example.mvt.model.ChuyenTau;
import com.example.mvt.model.Ghe;

@Repository
public interface GheRepository extends JpaRepository<Ghe, Long>, QuerydslPredicateExecutor<Ghe>{
	@Query(value = "SELECT ghe1.* FROM (SELECT ghe.* FROM mvt.ghe as ghe, mvt.toa_ghe as toaGhe, mvt.toa as toa , mvt.doan_tau as doanTau Where ghe.ma_toa_ghe = toaGhe.ma_toa And toaGhe.ma_toa = toa.ma_toa And toa.ma_tau = doanTau.ma_tau And doanTau.ma_tau = ?1) as ghe1 Where ghe1.so_hieu_ghe Not In (SELECT veGhe.so_hieu_ghe FROM mvt.ve as ve, mvt.ve_ghe as veGhe Where ve.ma_ve = veGhe.ma_ve And ve.ma_ct = ?1)", nativeQuery = true)
	Page<Ghe> getGheTrongByChuyenTau(Long maCT,Pageable pageable);
}
