package com.example.mvt.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TKNhanVien")
public class TKNhanVien {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ma_nv;
	
	@Column(name = "ho")
	private String ho;
	
	@Column(name = "ten_dem")
	private String tenDem;
	
	@Column(name = "ten_rieng")
	private String tenRieng;
	
	@Column(name = "cmt",unique = true)
	private String cmt;
	
	@Column(name = "ngay_sinh")
	private Date ngaySinh;
	
	@Column(name = "gioi_tinh")
	private String gioiTinh;
	
	@Column(name = "ten_tk",unique = true)
	private String tenTK;
	
	@Column(name = "mat_khau")
	private String matKhau;
	
	@Column(name = "vai_tro")
	private String vaiTro;
	
	@OneToMany(mappedBy = "maNV", cascade = CascadeType.REMOVE)
	private Set<TKNhanVienSDT> tKNhanVienSDTs;

	@OneToOne(mappedBy = "maNVQL", cascade = CascadeType.REMOVE)
	private TKNhanVienQuanLy tKNhanVienQuanLy;
	
	@OneToOne(mappedBy = "maNVBV", cascade = CascadeType.REMOVE)
	private TKNhanVienBanVe tKNhanVienBanVe;
	
	@OneToOne(mappedBy = "maNVTH", cascade = CascadeType.REMOVE)
	private TKNhanVienTinHoc tKNhanVienTinHoc;

	
	public TKNhanVienBanVe gettKNhanVienBanVe() {
		return tKNhanVienBanVe;
	}

	public void settKNhanVienBanVe(TKNhanVienBanVe tKNhanVienBanVe) {
		this.tKNhanVienBanVe = tKNhanVienBanVe;
	}

	public TKNhanVienTinHoc gettKNhanVienTinHoc() {
		return tKNhanVienTinHoc;
	}

	public void settKNhanVienTinHoc(TKNhanVienTinHoc tKNhanVienTinHoc) {
		this.tKNhanVienTinHoc = tKNhanVienTinHoc;
	}

	public Set<TKNhanVienSDT> gettKNhanVienSDTs() {
		return tKNhanVienSDTs;
	}

	public void settKNhanVienSDTs(Set<TKNhanVienSDT> tKNhanVienSDTs) {
		this.tKNhanVienSDTs = tKNhanVienSDTs;
	}

	public TKNhanVienQuanLy gettKNhanVienQuanLy() {
		return tKNhanVienQuanLy;
	}

	public void settKNhanVienQuanLy(TKNhanVienQuanLy tKNhanVienQuanLy) {
		this.tKNhanVienQuanLy = tKNhanVienQuanLy;
	}

	public Long getMa_nv() {
		return ma_nv;
	}

	public void setMa_nv(Long ma_nv) {
		this.ma_nv = ma_nv;
	}


	public String getHo() {
		return ho;
	}

	public void setHo(String ho) {
		this.ho = ho;
	}

	public String getTenDem() {
		return tenDem;
	}

	public void setTenDem(String tenDem) {
		this.tenDem = tenDem;
	}

	public String getTenRieng() {
		return tenRieng;
	}

	public void setTenRieng(String tenRieng) {
		this.tenRieng = tenRieng;
	}

	public String getCmt() {
		return cmt;
	}

	public void setCmt(String cmt) {
		this.cmt = cmt;
	}

	public Date getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	public String getGioiTinh() {
		return gioiTinh;
	}

	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}

	public String getTenTK() {
		return tenTK;
	}

	public void setTenTK(String tenTK) {
		this.tenTK = tenTK;
	}

	public String getMatKhau() {
		return matKhau;
	}

	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}

	public String getVaiTro() {
		return vaiTro;
	}

	public void setVaiTro(String vaiTro) {
		this.vaiTro = vaiTro;
	}
	
}
