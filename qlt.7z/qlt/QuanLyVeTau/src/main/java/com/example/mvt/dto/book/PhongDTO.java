package com.example.mvt.dto.book;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.example.mvt.model.Giuong;
import com.example.mvt.model.ToaGiuong;

public class PhongDTO {
	private Long soHieuPhong;
	private String soPhong;
	private ToaGiuongDTO maToaGiuong;
	public Long getSoHieuPhong() {
		return soHieuPhong;
	}
	public void setSoHieuPhong(Long soHieuPhong) {
		this.soHieuPhong = soHieuPhong;
	}
	public String getSoPhong() {
		return soPhong;
	}
	public void setSoPhong(String soPhong) {
		this.soPhong = soPhong;
	}
	public ToaGiuongDTO getMaToaGiuong() {
		return maToaGiuong;
	}
	public void setMaToaGiuong(ToaGiuongDTO maToaGiuong) {
		this.maToaGiuong = maToaGiuong;
	}
}
