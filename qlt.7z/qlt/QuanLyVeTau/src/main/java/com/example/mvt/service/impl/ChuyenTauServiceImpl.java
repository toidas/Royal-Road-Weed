package com.example.mvt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.example.mvt.dto.ChuyenTauDTO;
import com.example.mvt.model.ChuyenTau;
import com.example.mvt.repository.ChuyenTauRepository;
import com.example.mvt.service.ChuyenTauService;
import com.example.mvt.service.util.MapperUtils;

@Service
public class ChuyenTauServiceImpl implements ChuyenTauService{
	
	@Autowired
	ChuyenTauRepository chuyenTauRepository;
	
	@Override
	public Page<ChuyenTauDTO> getChuyenTauByTuyen(String gadi, String gaden, String date, int page, int size) {
		// TODO Auto-generated method stub
		
		 PageRequest pageable = PageRequest.of(page, size);
		
		 Page<ChuyenTau> chuyentauPage = chuyenTauRepository.getChuyenTauByTuyen(gadi, gaden, date, pageable);
		 Page<ChuyenTauDTO> chuyentauPageDTO = chuyentauPage.map(entity -> {
		        if (entity != null) {
		            return MapperUtils.toDto(entity, ChuyenTauDTO.class);
		        }
		        return null;
		    });
		 return chuyentauPageDTO;
	}

	@Override
	public ChuyenTauDTO getChuyenTauByMaCT(Long mact) {
		// TODO Auto-generated method stub
		ChuyenTau ct = chuyenTauRepository.getOne(mact);	
		return MapperUtils.toDto(ct, ChuyenTauDTO.class);
	}

}
