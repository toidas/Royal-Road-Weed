package com.example.mvt.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ve")
public class Ve {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long maVe;
	
	@Column(name = "diem_di")
	private String diemDi;
	
	@Column(name = "diem_den")
	private String diemDen;
	
	@Column(name = "thoi_gian_xp")
	private Date thoiGianXP;
	
	@Column(name = "loai")
	private String loai;
	
	@Column(name = "gia")
	private float gia;
	
	@Column(name = "ngay_mua")
	private Date ngayMua;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_ct")
	private ChuyenTau maCT;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cmt")
	private KhachHang cmt;
	
	@OneToOne(mappedBy = "maVe", cascade = CascadeType.REMOVE)
	private VeGhe veGhe;
	
	@OneToOne(mappedBy = "maVe", cascade = CascadeType.REMOVE)
	private VeGiuong veGiuong;

	public VeGhe getVeGhe() {
		return veGhe;
	}

	public void setVeGhe(VeGhe veGhe) {
		this.veGhe = veGhe;
	}

	public VeGiuong getVeGiuong() {
		return veGiuong;
	}

	public void setVeGiuong(VeGiuong veGiuong) {
		this.veGiuong = veGiuong;
	}

	public Date getNgayMua() {
		return ngayMua;
	}

	public void setNgayMua(Date ngayMua) {
		this.ngayMua = ngayMua;
	}

	public KhachHang getCmt() {
		return cmt;
	}

	public void setCmt(KhachHang cmt) {
		this.cmt = cmt;
	}

	public Long getMaVe() {
		return maVe;
	}

	public void setMaVe(Long maVe) {
		this.maVe = maVe;
	}

	public String getDiemDi() {
		return diemDi;
	}

	public void setDiemDi(String diemDi) {
		this.diemDi = diemDi;
	}

	public String getDiemDen() {
		return diemDen;
	}

	public void setDiemDen(String diemDen) {
		this.diemDen = diemDen;
	}

	public Date getThoiGianXP() {
		return thoiGianXP;
	}

	public void setThoiGianXP(Date thoiGianXP) {
		this.thoiGianXP = thoiGianXP;
	}

	public String getLoai() {
		return loai;
	}

	public void setLoai(String loai) {
		this.loai = loai;
	}

	public float getGia() {
		return gia;
	}

	public void setGia(float gia) {
		this.gia = gia;
	}

	public ChuyenTau getMaCT() {
		return maCT;
	}

	public void setMaCT(ChuyenTau maCT) {
		this.maCT = maCT;
	}
	
	
}
