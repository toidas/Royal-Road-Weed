package com.example.mvt.dto.book;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.example.mvt.model.Phong;
import com.example.mvt.model.VeGiuong;

public class GiuongDTO {
	private Long soHieuGiuong;
	private String so;
	private PhongDTO maPhong;
	public Long getSoHieuGiuong() {
		return soHieuGiuong;
	}
	public void setSoHieuGiuong(Long soHieuGiuong) {
		this.soHieuGiuong = soHieuGiuong;
	}
	public String getSo() {
		return so;
	}
	public void setSo(String so) {
		this.so = so;
	}
	public PhongDTO getMaPhong() {
		return maPhong;
	}
	public void setMaPhong(PhongDTO maPhong) {
		this.maPhong = maPhong;
	}
	
}
