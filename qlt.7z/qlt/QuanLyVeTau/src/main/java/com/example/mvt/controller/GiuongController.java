package com.example.mvt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mvt.dto.book.GiuongDTO;
import com.example.mvt.service.GiuongService;

@RestController
@RequestMapping(value = "api/giuong" , produces = "application/json")
public class GiuongController {
	@Autowired
	GiuongService giuongService;
	
	@GetMapping("/get-Giuong-by-ct/{maCT}/{page}/{size}")
	public Page<GiuongDTO> getGiuongByCT(@PathVariable(name = "maCT") Long maCT,@PathVariable(name = "page") int page,@PathVariable(name = "size") int size) {
		return giuongService.getGiuongTrongByChuyenTau(maCT, page, size);
	}
	
	@GetMapping("/get-Giuong-by-ct/{maCT}")
	public Page<GiuongDTO> getGiuongByCT(@PathVariable(name = "maCT") Long maCT) {
		return giuongService.getGiuongTrongByChuyenTau(maCT, 0, 10000);
	}
}
