package com.example.mvt.service;

import com.example.mvt.common.StandardResponse;
import com.example.mvt.dto.PasswordDto;
import com.example.mvt.dto.object_request.UserInfo;
import com.example.mvt.model.User;

public interface UserService {
	StandardResponse<String> ChangePassword(String email, PasswordDto passwordDto, String currentPassword);

	User editUser(String email, UserInfo userInfo);

}
