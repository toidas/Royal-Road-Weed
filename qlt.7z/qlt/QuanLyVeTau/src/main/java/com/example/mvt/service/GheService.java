package com.example.mvt.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.mvt.dto.book.GheDTO;
import com.example.mvt.model.Ghe;

public interface GheService {
	Page<GheDTO> getGheTrongByChuyenTau(Long maCT,int page,int size);
}
