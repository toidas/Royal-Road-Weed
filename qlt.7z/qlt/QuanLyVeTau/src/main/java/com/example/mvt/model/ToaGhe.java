package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ToaGhe")
public class ToaGhe {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_toa")
	private Toa maToa;
	
	@Column(name = "mo_ta")
	private String moTa;
	
	@OneToMany(mappedBy = "maToaGhe", cascade = CascadeType.REMOVE)
	private Set<Ghe> ghes;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Toa getMaToa() {
		return maToa;
	}

	public void setMaToa(Toa maToa) {
		this.maToa = maToa;
	}

	public String getMoTa() {
		return moTa;
	}

	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}

	public Set<Ghe> getGhes() {
		return ghes;
	}

	public void setGhes(Set<Ghe> ghes) {
		this.ghes = ghes;
	}
	
	
}
