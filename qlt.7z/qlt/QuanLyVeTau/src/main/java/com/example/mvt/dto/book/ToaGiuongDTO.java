package com.example.mvt.dto.book;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.example.mvt.model.Phong;
import com.example.mvt.model.Toa;

public class ToaGiuongDTO {

	private Long id;
	private ToaDTO maToa;
	private String moTa;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public ToaDTO getMaToa() {
		return maToa;
	}
	public void setMaToa(ToaDTO maToa) {
		this.maToa = maToa;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	
}
