package com.example.mvt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.mvt.dto.ChuyenTauDTO;
import com.example.mvt.dto.book.GheDTO;
import com.example.mvt.model.ChuyenTau;
import com.example.mvt.model.Ghe;
import com.example.mvt.repository.GheRepository;
import com.example.mvt.service.GheService;
import com.example.mvt.service.util.MapperUtils;

@Service
public class GheServiceImpl implements GheService{
	
	@Autowired
	GheRepository gheRepository;
	
	@Override
	public Page<GheDTO> getGheTrongByChuyenTau(Long maCT, int page, int size) {
		// TODO Auto-generated method stub
		 PageRequest pageable = PageRequest.of(page, size);
		
		 Page<Ghe> ghePage = gheRepository.getGheTrongByChuyenTau(maCT, pageable);
		 Page<GheDTO> ghePageDTO = ghePage.map(entity -> {
		        if (entity != null) {
		            return MapperUtils.toDto(entity, GheDTO.class);
		        }
		        return null;
		    });
		 return ghePageDTO;
	}

}
