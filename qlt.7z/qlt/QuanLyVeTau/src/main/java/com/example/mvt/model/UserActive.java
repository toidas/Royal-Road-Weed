package com.example.mvt.model;

public enum UserActive {
	ACTIVE,INACTIVE
}
