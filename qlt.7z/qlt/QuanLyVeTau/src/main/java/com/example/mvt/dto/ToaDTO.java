package com.example.mvt.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.example.mvt.model.DoanTau;
import com.example.mvt.model.ToaGhe;

public class ToaDTO {
	private Long soHieuToa;
	private String loai;
	private String maToa;

	public Long getSoHieuToa() {
		return soHieuToa;
	}

	public void setSoHieuToa(Long soHieuToa) {
		this.soHieuToa = soHieuToa;
	}

	public String getLoai() {
		return loai;
	}

	public void setLoai(String loai) {
		this.loai = loai;
	}

	public String getMaToa() {
		return maToa;
	}

	public void setMaToa(String maToa) {
		this.maToa = maToa;
	}

}
