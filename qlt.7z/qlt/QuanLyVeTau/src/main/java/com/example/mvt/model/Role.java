package com.example.mvt.model;

public enum Role {
	USER,
    ADMIN
}
