package com.example.mvt.dto;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.example.mvt.model.DoanTau;
import com.example.mvt.model.TKNhanVienQuanLy;
import com.example.mvt.model.Tuyen;
import com.example.mvt.model.Ve;

public class ChuyenTauDTO {

	private Long maCT;
	private Date thoiGianXP;
	private TuyenDTO maTuyen;
	private DoanTauDTO maTau;
	private Float giaVe;

	public Float getGiaVe() {
		return giaVe;
	}

	public void setGiaVe(Float giaVe) {
		this.giaVe = giaVe;
	}

	public Long getMaCT() {
		return maCT;
	}

	public void setMaCT(Long maCT) {
		this.maCT = maCT;
	}

	public Date getThoiGianXP() {
		return thoiGianXP;
	}

	public void setThoiGianXP(Date thoiGianXP) {
		this.thoiGianXP = thoiGianXP;
	}

	public TuyenDTO getMaTuyen() {
		return maTuyen;
	}

	public void setMaTuyen(TuyenDTO maTuyen) {
		this.maTuyen = maTuyen;
	}

	public DoanTauDTO getMaTau() {
		return maTau;
	}

	public void setMaTau(DoanTauDTO maTau) {
		this.maTau = maTau;
	}
}
