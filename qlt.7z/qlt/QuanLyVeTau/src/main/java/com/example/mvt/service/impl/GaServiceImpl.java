package com.example.mvt.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mvt.dto.GaDTO;
import com.example.mvt.model.Ga;
import com.example.mvt.model.QGa;
import com.example.mvt.repository.GaRepository;
import com.example.mvt.service.GaService;
import com.example.mvt.service.util.MapperUtils;
import com.querydsl.core.BooleanBuilder;

@Service
public class GaServiceImpl implements GaService{
	
	@Autowired
	GaRepository gaRepository;
	
	@Override
	public List<GaDTO> getGaAllByName(String name) {
		// TODO Auto-generated method stub
		QGa qGa = QGa.ga;
		BooleanBuilder predicate = new BooleanBuilder();
		predicate.and(qGa.maGa.isNotNull());
		predicate.and(qGa.diaDiem.like("%"+name+"%"));

		List<Ga> gaList = gaRepository.findAll(predicate);
		List<GaDTO> gaDTOList = new ArrayList<GaDTO>();
		for(Ga ga : gaList) {
			GaDTO gaDTO = MapperUtils.toDto(ga, GaDTO.class);
			gaDTOList.add(gaDTO);
		}
		return gaDTOList;
	}

}
