package com.example.mvt.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import com.example.mvt.model.Ghe;
import com.example.mvt.model.Giuong;

@Repository
public interface GiuongRepository extends JpaRepository<Giuong, Long>, QuerydslPredicateExecutor<Giuong>{
	@Query(value = "SELECT * FROM (SELECT giuong.* FROM mvt.giuong as giuong, mvt.phong as phong , mvt.toa_giuong as toaGiuong , mvt.toa as toa , mvt.doan_tau as doanTau Where giuong.ma_phong = phong.so_hieu_phong And phong.ma_toa_giuong = toaGiuong.id And toaGiuong.ma_toa = toa.so_hieu_toa And toa.ma_tau = doanTau.ma_tau And doanTau.ma_tau = ?1) as giuong1  Where giuong1.so_hieu_giuong Not In (SELECT veGiuong.so_hieu_giuong FROM mvt.ve as ve, mvt.ve_giuong as veGiuong Where ve.ma_ve = veGiuong.ma_ve And ve.ma_ct = ?1)", nativeQuery = true)
	Page<Giuong> getGiuongTrongByChuyenTau(Long maCT,Pageable pageable);
}
