package com.example.mvt.controller;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.mvt.common.ResponseResult;
import com.example.mvt.common.StandardResponse;
import com.example.mvt.dto.FileAttachmentDTO;
import com.example.mvt.dto.PasswordDto;
import com.example.mvt.dto.object_request.UserInfo;
import com.example.mvt.exception.BadRequestException;
import com.example.mvt.exception.ResourceNotFoundException;
import com.example.mvt.model.User;
import com.example.mvt.payload.SignUpRequest;
import com.example.mvt.repository.UserRepository;
import com.example.mvt.security.CurrentUser;
import com.example.mvt.security.UserPrincipal;
import com.example.mvt.service.UserService;

@RestController
@RequestMapping("api/users")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@GetMapping("/user/me")
	public User getCurrentUser(@CurrentUser UserPrincipal userPrincipal) {
		return userRepository.findById(userPrincipal.getId())
				.orElseThrow(() -> new ResourceNotFoundException("User", "id", userPrincipal.getId()));
	}

	final String EDIT_ERROR = "Sửa không thành công";
	final String EDIT_SUCCESS = "Sửa thành công";
	final String MAIL_IS_NOT_EXIST = "Mail chưa được đăng ký";

	@GetMapping("/me")
	public StandardResponse<User> getCurrentUserByEmail() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String id = auth.getName().toString();
		User user = null;
		List<User> userLisst = userRepository.findCurrentUser(Long.parseLong(id));
		if (userLisst == null || userLisst.size() < 1) {
			user = null;
		} else {
			user = userLisst.get(0);
		}
		StandardResponse<User> response = new StandardResponse<>();
		if (user == null) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(ResponseResult.FAIL_MESSAGE);
			response.setValue(null);
		} else {
			response.setCode(ResponseResult.SUCCESS_CODE);
			response.setMessage(ResponseResult.SUCCESS_MESSAGE);
			response.setValue(user);
		}
		return response;
	}

	@PutMapping("/change-pass")
	public StandardResponse<String> ChangePassword(@RequestBody PasswordDto passwordDto) {
		StandardResponse<String> response = new StandardResponse<>();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String currentPassword = auth.getCredentials().toString();
		return userService.ChangePassword(auth.getName(), passwordDto, currentPassword);
//		if (user == null) {
//			response.setCode(ResponseResult.FAIL_CODE);
//			response.setMessage(ResponseResult.FAIL_MESSAGE);
//			response.setValue(EDIT_ERROR);
//		} else {
//			response.setCode(ResponseResult.SUCCESS_CODE);
//			response.setMessage(ResponseResult.SUCCESS_MESSAGE);
//			response.setValue(EDIT_SUCCESS);
//		}
//		return response;
	}

	@PutMapping("/edit-user")
	public StandardResponse<String> editUser(@RequestBody UserInfo userInfo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String id = auth.getName().toString();
		User user = userService.editUser(id, userInfo);

		StandardResponse<String> response = new StandardResponse<>();

		if (user == null) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(ResponseResult.FAIL_MESSAGE);
			response.setValue(EDIT_ERROR);
		} else {
			response.setCode(ResponseResult.SUCCESS_CODE);
			response.setMessage(ResponseResult.SUCCESS_MESSAGE);
			response.setValue(EDIT_SUCCESS);
		}
		return response;
	}

}
