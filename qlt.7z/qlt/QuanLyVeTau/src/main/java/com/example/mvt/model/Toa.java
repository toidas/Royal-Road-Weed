package com.example.mvt.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Toa")
public class Toa {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long soHieuToa;
	
	@Column(name = "loai")
	private String loai;
	
	@Column(name = "ma_toa")
	private String maToa;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_tau")
	private DoanTau maTau;
	
	@OneToOne(mappedBy = "maToa", cascade = CascadeType.REMOVE)
	private ToaGhe toaGhe;
	
	@OneToOne(mappedBy = "maToa", cascade = CascadeType.REMOVE)
	private ToaGiuong toaGiuong;
	
//	@OneToOne(mappedBy = "maToa", cascade = CascadeType.REMOVE)
//	private ToaGiuong toaGiuong;

	public Long getSoHieuToa() {
		return soHieuToa;
	}

	public String getMaToa() {
		return maToa;
	}

	public void setMaToa(String maToa) {
		this.maToa = maToa;
	}

	public ToaGhe getToaGhe() {
		return toaGhe;
	}

	public void setToaGhe(ToaGhe toaGhe) {
		this.toaGhe = toaGhe;
	}

	public void setSoHieuToa(Long soHieuToa) {
		this.soHieuToa = soHieuToa;
	}

	public String getLoai() {
		return loai;
	}

	public void setLoai(String loai) {
		this.loai = loai;
	}

	public DoanTau getMaTau() {
		return maTau;
	}

	public void setMaTau(DoanTau maTau) {
		this.maTau = maTau;
	}
	
	
}
