package com.example.springsocial;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SpringSocialApplicationTests {

	@Test
	public void contextLoads() {
	}

}
