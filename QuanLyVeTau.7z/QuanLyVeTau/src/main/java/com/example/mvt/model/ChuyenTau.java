package com.example.mvt.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ChuyenTau")
public class ChuyenTau {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long maCT;
	
	@Column(name = "thoi_gian_xp")
	private Date thoiGianXP;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_nv_ql")
	private TKNhanVienQuanLy maNVQL;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_tuyen")
	private Tuyen maTuyen;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_tau")
	private DoanTau maTau;
	
	@OneToMany(mappedBy = "maCT", cascade = CascadeType.REMOVE)
	private Set<Ve> ves;

	public Long getMaCT() {
		return maCT;
	}

	public void setMaCT(Long maCT) {
		this.maCT = maCT;
	}

	public Date getThoiGianXP() {
		return thoiGianXP;
	}

	public void setThoiGianXP(Date thoiGianXP) {
		this.thoiGianXP = thoiGianXP;
	}

	public TKNhanVienQuanLy getMaNVQL() {
		return maNVQL;
	}

	public void setMaNVQL(TKNhanVienQuanLy maNVQL) {
		this.maNVQL = maNVQL;
	}

	public Tuyen getMaTuyen() {
		return maTuyen;
	}

	public void setMaTuyen(Tuyen maTuyen) {
		this.maTuyen = maTuyen;
	}

	public DoanTau getMaTau() {
		return maTau;
	}

	public void setMaTau(DoanTau maTau) {
		this.maTau = maTau;
	}
}
