package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Ga")
public class Ga {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long maGa;
	
	@Column(name = "dia_dem")
	private String diaDiem;
	
	@OneToMany(mappedBy = "maGa", cascade = CascadeType.REMOVE)
	private Set<DoanDuong> DoanDuongs;

	public Long getMaGa() {
		return maGa;
	}

	public void setMaGa(Long maGa) {
		this.maGa = maGa;
	}

	public String getDiaDiem() {
		return diaDiem;
	}

	public void setDiaDiem(String diaDiem) {
		this.diaDiem = diaDiem;
	}

	public Set<DoanDuong> getDoanDuongs() {
		return DoanDuongs;
	}

	public void setDoanDuongs(Set<DoanDuong> doanDuongs) {
		DoanDuongs = doanDuongs;
	}
}
