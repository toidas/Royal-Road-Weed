package com.example.mvt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DoanDuong")
public class DoanDuong {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "diem")
	private String diem;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_ga")
	private Ga maGa;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_tuyen")
	private Tuyen maTuyen;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDiem() {
		return diem;
	}

	public void setDiem(String diem) {
		this.diem = diem;
	}

	public Ga getMaGa() {
		return maGa;
	}

	public void setMaGa(Ga maGa) {
		this.maGa = maGa;
	}

	public Tuyen getMaTuyen() {
		return maTuyen;
	}

	public void setMaTuyen(Tuyen maTuyen) {
		this.maTuyen = maTuyen;
	}
	
	

}
