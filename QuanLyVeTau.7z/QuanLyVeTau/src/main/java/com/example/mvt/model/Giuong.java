package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Giuong")
public class Giuong {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long soHieuGiuong;
	
	@Column(name = "so")
	private String so;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ma_phong")
	private Phong maPhong;
	
	@OneToMany(mappedBy = "soHieuGiuong", cascade = CascadeType.REMOVE)
	private Set<VeGiuong> veGiuong;

	public Long getSoHieuGiuong() {
		return soHieuGiuong;
	}

	public void setSoHieuGiuong(Long soHieuGiuong) {
		this.soHieuGiuong = soHieuGiuong;
	}

	public String getSo() {
		return so;
	}

	public void setSo(String so) {
		this.so = so;
	}

	public Phong getMaPhong() {
		return maPhong;
	}

	public void setMaPhong(Phong maPhong) {
		this.maPhong = maPhong;
	}

	public Set<VeGiuong> getVeGiuong() {
		return veGiuong;
	}

	public void setVeGiuong(Set<VeGiuong> veGiuong) {
		this.veGiuong = veGiuong;
	}
	
	
}
