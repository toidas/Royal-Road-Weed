package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "DoanTau")
public class DoanTau {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long maTau;
	
	@Column(name = "ten_tau")
	private String tenTau;
	
	@Column(name = "hang_sx")
	private String hangSX;
	
	@Column(name = "ngay_vh")
	private String ngayVH;
	
	@Column(name = "loai")
	private String loai;
	
	@OneToMany(mappedBy = "maTau", cascade = CascadeType.REMOVE)
	private Set<ChuyenTau> chuyenTaus;
	
	@OneToMany(mappedBy = "maTau", cascade = CascadeType.REMOVE)
	private Set<Toa> toas;

	public Long getMaTau() {
		return maTau;
	}

	public void setMaTau(Long maTau) {
		this.maTau = maTau;
	}

	public String getTenTau() {
		return tenTau;
	}

	public void setTenTau(String tenTau) {
		this.tenTau = tenTau;
	}

	public String getHangSX() {
		return hangSX;
	}

	public void setHangSX(String hangSX) {
		this.hangSX = hangSX;
	}

	public String getNgayVH() {
		return ngayVH;
	}

	public void setNgayVH(String ngayVH) {
		this.ngayVH = ngayVH;
	}

	public String getLoai() {
		return loai;
	}

	public void setLoai(String loai) {
		this.loai = loai;
	}

	public Set<ChuyenTau> getChuyenTaus() {
		return chuyenTaus;
	}

	public void setChuyenTaus(Set<ChuyenTau> chuyenTaus) {
		this.chuyenTaus = chuyenTaus;
	}
	
	
}
