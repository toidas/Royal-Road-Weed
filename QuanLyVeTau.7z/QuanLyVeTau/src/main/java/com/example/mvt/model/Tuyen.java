package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Tuyen")
public class Tuyen {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long maTuyen;
	
	@Column(name = "ten_tuyen")
	private String tenTuyen;
	
	@OneToMany(mappedBy = "maTuyen", cascade = CascadeType.REMOVE)
	private Set<DoanDuong> DoanDuongs;
	
	@OneToMany(mappedBy = "maTuyen", cascade = CascadeType.REMOVE)
	private Set<ChuyenTau> chuyenTaus;

	public Long getMaTuyen() {
		return maTuyen;
	}

	public Set<ChuyenTau> getChuyenTaus() {
		return chuyenTaus;
	}

	public void setChuyenTaus(Set<ChuyenTau> chuyenTaus) {
		this.chuyenTaus = chuyenTaus;
	}

	public void setMaTuyen(Long maTuyen) {
		this.maTuyen = maTuyen;
	}

	public String getTenTuyen() {
		return tenTuyen;
	}

	public void setTenTuyen(String tenTuyen) {
		this.tenTuyen = tenTuyen;
	}

	public Set<DoanDuong> getDoanDuongs() {
		return DoanDuongs;
	}

	public void setDoanDuongs(Set<DoanDuong> doanDuongs) {
		DoanDuongs = doanDuongs;
	}
	
	
}
