package com.example.mvt.controller;

import org.apache.http.client.ClientProtocolException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.social.facebook.api.Facebook;
import org.springframework.social.facebook.api.UserOperations;
import org.springframework.social.facebook.api.impl.FacebookTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.mvt.common.ResponseResult;
import com.example.mvt.common.StandardResponse;
import com.example.mvt.dto.FileAttachmentDTO;
import com.example.mvt.dto.PasswordWithTokenDto;
import com.example.mvt.dto.object_request.SocialLogin;
import com.example.mvt.exception.BadRequestException;
import com.example.mvt.exception.ResourceNotFoundException;
import com.example.mvt.model.AuthProvider;
import com.example.mvt.model.FacebookInfo;
import com.example.mvt.model.GoogleInfo;
import com.example.mvt.model.Role;
import com.example.mvt.model.User;
import com.example.mvt.model.UserActive;
import com.example.mvt.payload.ApiResponse;
import com.example.mvt.payload.AuthResponse;
import com.example.mvt.payload.LoginRequest;
import com.example.mvt.payload.SignUpRequest;
import com.example.mvt.repository.UserRepository;
import com.example.mvt.security.CurrentUser;
import com.example.mvt.security.TokenProvider;
import com.example.mvt.security.UserPrincipal;
import com.example.mvt.service.AuthenService;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	private AuthenService authenService;
	

	final String ACCOUNT_IS_NOT_EXIST = "Tài khoản hoặc mật khẩu không đúng";
	final String ACCOUNT_IS_NOT_ACTIVE = "Tài khoản chưa được kích hoạt";
	final String GOOGLE_TOKEN_IS_INCORRECT = "Lỗi đăng nhập bằng gmail";
	final String FACEBOOK_TOKEN_IS_INCORRECT = "Lỗi đăng nhập bằng facebook";
	@PostMapping("/login")
	public StandardResponse<AuthResponse> authenticateUser(@RequestBody LoginRequest loginRequest) {
		StandardResponse<AuthResponse> response = new StandardResponse<>();
		List<User> users = userRepository.findByEmailOrUserName(loginRequest.getEmail());
		if (users == null || users.size() < 1) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(ACCOUNT_IS_NOT_EXIST);
			return response;
		}
		User user = users.get(0);
		if (!(user.getActive().toString().equals(UserActive.ACTIVE.toString()))) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(ACCOUNT_IS_NOT_ACTIVE);
			return response;
		}
		if(!passwordEncoder.matches(loginRequest.getPassword(),user.getPassword())) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(ACCOUNT_IS_NOT_EXIST);
			return response;
		}
			
		user.setLoginType(AuthProvider.normal);
		userRepository.save(user);
		
		Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(user.getId(), loginRequest.getPassword()));
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String token = tokenProvider.createToken(authentication);
		response.setCode(ResponseResult.SUCCESS_CODE);
		response.setMessage(ResponseResult.SUCCESS_MESSAGE);
		response.setValue(new AuthResponse(token));
		return response;
	}

	@PostMapping("/signup")
	public StandardResponse<String> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {
		return authenService.registerUser(signUpRequest);
	}

	@PostMapping("/change-pass-with-token")
	public StandardResponse<String> changePassWithToken(@Valid @RequestBody PasswordWithTokenDto passwordWithTokenDto) {
		return authenService.changePassWithToken(passwordWithTokenDto);
	}
	
	@PostMapping("/test_facebook")
	public StandardResponse<String> testFace() {
		String accessToken = "EAAhOeyQNDrcBAP5EMkQBWedzObA5jxST9WVfC5lVZB9AI0jTEmMaXDGt6yBbw3eRB2PJMUD72pKozVsKB0wvZAQ8bsYp2Yvl8pRDK7zEqk9ZBpJRQkyXqMHYl8ysTpoGtOeDBQuq1ZC3nO9DXEQQ7pM1mk0ghKKy2pE4NsftImfmZAZAh3hRs1005WgDZC99TTdGs4iavq6V9ml19o5BPlZB0twd8iybPcgZD"; // access token received from Facebook after OAuth authorization
		Facebook facebook = new FacebookTemplate(accessToken);
		//UserOperations userOperations = facebook.userOperations();
		String [] fields = { "id", "email",  "first_name", "last_name" };
		org.springframework.social.facebook.api.User userProfile = facebook.fetchObject("me", org.springframework.social.facebook.api.User.class, fields);
		System.out.println(userProfile.getFirstName());
		System.out.println(userProfile.getEmail());
		return null;
	}

	@GetMapping("/active-account")
	public StandardResponse<String> activeAccount(String email, String token) {
		return authenService.activeAccount(email, token);
	}

	@GetMapping("/forgot-password")
	public StandardResponse<String> forgotPassword(String email) {
		return authenService.forgotPassword(email);
	}

	@RequestMapping("/login-google")
	public StandardResponse<AuthResponse> loginGoogle(@RequestBody SocialLogin socialLogin) {
		GoogleInfo googleInfo = authenService.loginGoogle(socialLogin);
		StandardResponse<AuthResponse> response = new StandardResponse<>();
		
		if(googleInfo == null) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(GOOGLE_TOKEN_IS_INCORRECT);
			return response;
		}
		List<User> users = userRepository.findByEmailOrUserName(googleInfo.getEmail());
		User user = null;
		if (users == null || users.size() < 1) {
			User newUser = new User();
			
//			FileAttachment fileAttachment = new FileAttachment(); 
//			fileAttachment.setUrl(googleInfo.getPicture());
//			fileAttachment = fileAttachmentRepository.save(fileAttachment);
//			
//			newUser.setAvatar(fileAttachment);
			newUser.setEmail(googleInfo.getEmail());
			newUser.setName(googleInfo.getName());
			newUser.setProvider(AuthProvider.google);
			newUser.setCreate_date(new Date());
			newUser.setActive(UserActive.ACTIVE);
			newUser.setRole(Role.USER);
			newUser.setPassword(passwordEncoder.encode(socialLogin.getAccessToken()));
			newUser.setLoginType(AuthProvider.google);
			newUser = userRepository.save(newUser);
			user = newUser;
		}
		else {
			user = users.get(0);
			user.setLoginType(AuthProvider.google);
			user = userRepository.save(user);
		}
		Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(user.getId(), "google"));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String token = tokenProvider.createToken(authentication);
		response.setCode(ResponseResult.SUCCESS_CODE);
		response.setMessage(ResponseResult.SUCCESS_MESSAGE);
		response.setValue(new AuthResponse(token));
		return response;
	}
	
	@RequestMapping("/login-facebook")
	public StandardResponse<AuthResponse> loginFacebook(@RequestBody SocialLogin socialLogin) {
		FacebookInfo facebookInfo = authenService.loginFacebook(socialLogin);
		
		StandardResponse<AuthResponse> response = new StandardResponse<>();
		
		if(facebookInfo == null) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(FACEBOOK_TOKEN_IS_INCORRECT);
			return response;
		}
		Optional<User> users = userRepository.findByFacebookID(facebookInfo.getId());
		System.out.println(facebookInfo.getId());
		User user = null;
		if (!users.isPresent()) {
			User newUser = new User();
			
			if(facebookInfo.getPicture() != null) {
//				FileAttachment fileAttachment = new FileAttachment();
//				fileAttachment.setUrl(facebookInfo.getPicture().getData().getUrl());
//				fileAttachment = fileAttachmentRepository.save(fileAttachment);
//				
//				newUser.setAvatar(fileAttachment);
			}
			if(facebookInfo.getEmail() != null) {
				newUser.setEmail(facebookInfo.getEmail());
			}
			newUser.setName(facebookInfo.getName());
			newUser.setProvider(AuthProvider.facebook);
			newUser.setFacebookID(facebookInfo.getId());
			newUser.setCreate_date(new Date());
			newUser.setActive(UserActive.INACTIVE);
			newUser.setRole(Role.USER);
			newUser.setPassword(passwordEncoder.encode(socialLogin.getAccessToken()));
			newUser.setLoginType(AuthProvider.facebook);
			newUser = userRepository.save(newUser);
			user = newUser;
		}
		else {
			user = users.get();
			user.setLoginType(AuthProvider.facebook);
			user = userRepository.save(user);
		}
		Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(user.getId(), "facebook"));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String token = tokenProvider.createToken(authentication);
		response.setCode(ResponseResult.SUCCESS_CODE);
		response.setMessage(ResponseResult.SUCCESS_MESSAGE);
		response.setValue(new AuthResponse(token));
		return response;
	}
}
