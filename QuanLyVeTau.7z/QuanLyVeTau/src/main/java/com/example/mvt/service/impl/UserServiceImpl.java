package com.example.mvt.service.impl;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.mvt.common.ResponseResult;
import com.example.mvt.common.StandardResponse;
import com.example.mvt.common.exception.BadRequestException;
import com.example.mvt.dto.PasswordDto;
import com.example.mvt.dto.object_request.UserInfo;
import com.example.mvt.model.AuthProvider;
import com.example.mvt.model.User;
import com.example.mvt.model.UserActive;
import com.example.mvt.repository.UserRepository;
import com.example.mvt.service.UserService;
import com.example.mvt.util.RandomMethod;

@Service
public class UserServiceImpl implements UserService {
	
	
	private static String WEB_SERVER;
	@Value("${app.web_server}")
	public void setStoreServer(String web_server) {
		WEB_SERVER = web_server;
	}
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	UserRepository userRepository;


	@Override
	public StandardResponse<String> ChangePassword(String id, PasswordDto passwordDto, String currentPassword) {
		// TODO Auto-generated method stub
		StandardResponse<String> response = new StandardResponse<>();
		List<User> users = userRepository.findCurrentUser(Long.parseLong(id));
		if (users == null || users.size() < 1) {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(ResponseResult.FAIL_MESSAGE);
			response.setValue("Sai username hoặc mail");
			return response;
		}
		User user = users.get(0);
		currentPassword = user.getPassword();

		if (!user.getProvider().equals(AuthProvider.normal)
				|| passwordEncoder.matches(passwordDto.getOldPassword(), currentPassword)) {
			user.setPassword(passwordEncoder.encode(passwordDto.getNewPassword()));
			user.setProvider(AuthProvider.normal);
			userRepository.save(user);
			response.setCode(ResponseResult.SUCCESS_CODE);
			response.setMessage(ResponseResult.SUCCESS_MESSAGE);
			response.setValue("Đổi pass thành công");
			// userRepository.saveAndFlush(entity)
		} else {
			response.setCode(ResponseResult.FAIL_CODE);
			response.setMessage(ResponseResult.FAIL_MESSAGE);
			response.setValue("Mật khẩu cũ không đúng");
		}
		return response;
	}

	@Override
	public User editUser(String id, UserInfo userInfo) {
		// TODO Auto-generated method stub
		List<User> userList = userRepository.findCurrentUser(Long.parseLong(id));
		if (userList == null || userList.size() < 1) {
			return null;
		}
		User user = userList.get(0);
		if (user == null) {
			return null;
		}
//		FileAttachment fileAttachment = null;
//		if(userInfo.getFileid() != null){
//			fileAttachment = fileAttachmentRepository.findById((long) userInfo.getFileid()).get();
//		}
		if(userInfo.getName() != null){
			user.setName(userInfo.getName());
		}
//		if(fileAttachment != null){
//			user.setAvatar(fileAttachment);
//		}
		if(userInfo.getBirthday() != null){
			user.setBirthday(userInfo.getBirthday());
		}
		if(userInfo.getGender() != null){
			user.setGender(userInfo.getGender());
		}
		if(userInfo.getPhoneNumber() != null){
			user.setPhoneNumber(userInfo.getPhoneNumber());
		}
		System.out.println(user.getEmail());
		System.out.println(userInfo.getEmail());
		if((user.getEmail() == null || user.getEmail().trim().equals("")) && userInfo.getEmail() != null) {
			user.setEmail(userInfo.getEmail());
			user.setKeyToken(RandomMethod.randomKey(50));
			sendMailActive(userInfo.getEmail(),user.getKeyToken());
			user.setActive(UserActive.INACTIVE);
		}
		userRepository.save(user);

		return user;
	}
	
	public void sendMailActive(String email, String key) {
		try {
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "587");

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("Cmscorpx@gmail.com", "Cmspkl9!");
				}
			});
			Message msg = new MimeMessage(session);
			String urlActive = WEB_SERVER + "auth/active-account?email=" + email + "&token=" + key;
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
			msg.setSubject("ACtive Account");
			msg.setContent("Active Account click this url : " + urlActive, "text/html");
			msg.setSentDate(new Date());

			MimeBodyPart messageBodyPart = new MimeBodyPart();

			messageBodyPart.setContent("Active Account click this url : " + urlActive, "text/html");

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
		    Transport.send(msg);
		} catch (Exception e) {
			// TODO: handle exception
			throw new BadRequestException("Error");
		}
	}

}
