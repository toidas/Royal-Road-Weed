package com.example.mvt.model;

public enum  AuthProvider {
    normal,
    facebook,
    google,
    github
}
