package com.example.mvt.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "KhachHang")
public class KhachHang {
	
	@Id
	private String cmt;
	
	@Column(name = "dia_chi")
	private String diaChi;
	
	@Column(name = "ho_ten")
	private String hoTen;
	
	@Column(name = "emal")
	private String emal;
	
	@Column(name = "ngay_sinh")
	private String ngaySinh;
	
	@OneToMany(mappedBy = "cmt", cascade = CascadeType.REMOVE)
	private Set<Ve> ves;


	public String getCmt() {
		return cmt;
	}

	public void setCmt(String cmt) {
		this.cmt = cmt;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getEmal() {
		return emal;
	}

	public void setEmal(String emal) {
		this.emal = emal;
	}

	public String getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	
	
}
