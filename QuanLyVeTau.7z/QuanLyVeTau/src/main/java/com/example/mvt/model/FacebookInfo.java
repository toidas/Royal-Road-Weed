package com.example.mvt.model;

import com.example.mvt.controller.DataFacebook;

public class FacebookInfo {
	private String id;
	private String email;
	private String name;
	private DataFacebook picture;
	
	public DataFacebook getPicture() {
		return picture;
	}

	public void setPicture(DataFacebook picture) {
		this.picture = picture;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
