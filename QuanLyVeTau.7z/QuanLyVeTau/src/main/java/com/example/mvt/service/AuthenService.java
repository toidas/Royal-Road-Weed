package com.example.mvt.service;

import org.springframework.http.ResponseEntity;

import com.example.mvt.common.StandardResponse;
import com.example.mvt.dto.PasswordWithTokenDto;
import com.example.mvt.dto.object_request.SocialLogin;
import com.example.mvt.model.FacebookInfo;
import com.example.mvt.model.GoogleInfo;
import com.example.mvt.payload.SignUpRequest;

public interface AuthenService {
	StandardResponse<String> registerUser(SignUpRequest signUpRequest);
	StandardResponse<String> forgotPassword(String email);
	StandardResponse<String> activeAccount(String email,String token);
	StandardResponse<String> changePassWithToken(PasswordWithTokenDto passwordWithTokenDto);
	GoogleInfo loginGoogle(SocialLogin socialLogin);
	FacebookInfo loginFacebook(SocialLogin socialLogin);
}
