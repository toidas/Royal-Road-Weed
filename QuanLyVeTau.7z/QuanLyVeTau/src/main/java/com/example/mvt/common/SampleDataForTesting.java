package com.example.mvt.common;

public interface SampleDataForTesting {

    final public String[] threadTypes = {"normal", "stick"};

    final public String[] listWords = {"As", "you", "can", "see", "we", "were", "very", "easily", "able", "create", "dynamic", "queries", "based", "specific", "search", "needs", "at", "that",
            "current", "moment", "even", "when", "the", "repository", "developer", "was", "not", "aware", "requirements", "By", "not", "coupling", "a", "single", "method", "each", "search",
            "requirement", "as", "we", "saw", "with", "Spring", "Data", "implementation", "we", "can", "open", "up", "the", "flexibility", "search", "any", "combination", "terms", "as", "necessary",
            "without", "needing", "update", "repository", "layer", "WHATS", "NEXT", "Thank", "you", "for", "following", "along", "my", "first", "installment", "the", "What", "Can", "Querydsl", "Do",
            "for", "Me", "series", "In", "my", "next", "post", "Ill", "delve", "deeper", "into", "Querydsl", "and", "how", "it", "can", "support", "your", "efforts", "data", "as", "well", "as",
            "deeper", "initialization", "paths", "To", "of", "on", "our", "Microsoft", "Chromium", "Edge", "for", "Windows", "has", "been", "released", "and", "here", "is", "everything", "you",
            "need", "to", "know", "about", "how", "you", "can", "download", "and", "install", "the", "browser", "right", "now", "Microsoft", "Chromium", "Edge", "is", "an", "entirely", "new", "web",
            "browser", "and", "it", "comes", "with", "a", "series", "of", "improvements", "including", "support", "for", "Chrome", "extensions", "picture", "in", "picture", "mode", "and", "a", "lot",
            "more", "It", "has", "new", "interface", "new", "faster", "web", "rendering", "engine", "improved", "privacy", "features", "better", "accessibility", "options", "whole", "new",
            "experience", "In", "this", "guide", "well", "walk", "you", "through", "the", "different", "ways", "to", "download", "and", "install", "the", "Chromium-based", "Microsoft", "Edge", "on",
            "Windows"};

    final public String[] threadStatus = {"open", "close"};

    final public String[] paymentMethos = {"Cash", "Visa", "Momo", "Zalo Pay"};

    final public String[] colors = {"Amber", "Amethyst", "Apricot", "Aquamarine", "Azure", "Baby blue", "Beige", "Black", "Blue", "Blue-green", "Blue-violet", "Blush", "Bronze", "Brown", "Burgundy",
            "Byzantium", "Carmine", "Cerise", "Cerulean", "Champagne", "Chartreuse green", "Chocolate", "Cobalt blue", "Coffee", "Copper", "Coral", "Crimson", "Cyan", "Desert sand", "Electric blue",
            "Emerald", "Erin", "Gold", "Gray", "Green", "Harlequin", "Indigo", "Ivory", "Jade", "Jungle green", "Lavender", "Lemon", "Lilac", "Lime", "Magenta", "Magenta rose", "Maroon", "Mauve",
            "Navy blue", "Ochre", "Olive", "Orange", "Orange-red", "Orchid", "Peach", "Pear", "Periwinkle", "Persian blue", "Pink", "Plum", "Prussian blue", "Puce", "Purple", "Raspberry", "Red",
            "Red-violet", "Rose", "Ruby", "Salmon", "Sangria", "Sapphire", "Scarlet", "Silver", "Slate gray", "Spring bud", "Spring green", "Tan", "Taupe", "Teal", "Turquoise", "Ultramarine",
            "Violet", "Viridian", "White", "Yellow"};
}
