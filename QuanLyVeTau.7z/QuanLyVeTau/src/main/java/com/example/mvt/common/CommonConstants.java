package com.example.mvt.common;

public interface CommonConstants {

	// order
	final String ASCENDING = "ascending";
	final String DESCENDING = "descending";

	final long MAX_PRICE = 600000000000L;

	final double RELATED_PRICE = 0.5; // 0.2 ~ 20%

	final int DEFAULT_NUM_RELATED_THREAD = 5;

	//phuong.ndp server
//	final String FIREBASE_SERVER_KEY = "AAAAnB_0Gf4:APA91bH5x_Xq4arIirA6KUnzFwCASl3gFtj_Uq5omt2wuMt6Z0HtfyY2Vx7U0_hUGC0F7AYFKuNky9iDz8GSVIpa5m1BWSI3SKWAOJRuSbaQ18RvY8ppBYv2T0WVPeTYqA2N7Ip-lmuj";
	
	//cmd server
//	final String FIREBASE_SERVER_KEY = "AAAAEWsReBY:APA91bEp-waKsXlQuWjH30sQlfBwIy0KP8hYEAZPgSyAxEOdhjk2ks8rSgIOex_m5_IefoSR9xeIfkFC36F774cT7rMEBFntZxGwkiT-njju2CuxRdpiRdOdBeMdls4pYCR4M9-dNxMU";
	
	final String FIREBASE_SERVER_KEY = "AAAAm3jwFDQ:APA91bGqHmPBEaK2ph7oVzcxKyotxajpVqVeIn2VmsM7VcdCbwGCwhtt5_WXskmj0LC_DhxT09ZUpLJ9wejCxzkTcJvnFKRBLE0avnt-Oxe9gH2RjRLtjRis84IDnNvzrh_5YB8B7uNe";

	final String FIREBASE_API_URL = "https://fcm.googleapis.com/fcm/send";

	final String FIREBASE_NOTI_TITLE = "Bạn có tin nhắn mới từ ";
	final String FIREBASE_NOTI_CONTENT = "Bạn có một tin nhắn mới";
}
