const parseAllLinks = require('./src/import/parse/parse-all-links');

// parseAllLinks('series/lop-3.jsp', 'lop-3');
// parseAllLinks('series/lop-4.jsp', 'lop-4');
// parseAllLinks('series/lop-5.jsp', 'lop-5');
// parseAllLinks('series/lop-6.jsp', 'lop-6');
// parseAllLinks('series/lop-7.jsp', 'lop-7');
// parseAllLinks('series/lop-8.jsp', 'lop-8');
// parseAllLinks('series/lop-9.jsp', 'lop-9');
// parseAllLinks('series/lop-10.jsp', 'lop-10');
// parseAllLinks('series/lop-11.jsp', 'lop-11');
parseAllLinks('series/lop-12.jsp', 'lop-12');
// parseAllLinks('series/it-lap-trinh.jsp', 'it-lap-trinh');
