const connectDb = require("./src/connection");
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const utils = require('./src/utils');
const Series = require('./src/models/Series');

const { COPYFILE_EXCL } = fs.constants;

const vietjackJsonPath = (filePath) => path.join(__dirname, '../import-data/vietjack', filePath);

const handleLog = (e) => {
    console.log(e);
    if (typeof e == 'string') {
        runLogs += `${e}\n`;
    }
};

const importFolder = (folderPath) => {
    const directoryPath = vietjackJsonPath(folderPath);
    const resultsArray = fs.readdirSync(directoryPath);
    resultsArray.forEach(folder => {
        const indexFile = vietjackJsonPath(folderPath + '/' + folder + '/index.json');
        if (fs.existsSync(indexFile)) {
            const indexFileComplete = vietjackJsonPath(folderPath + '-temp/' + folder + '/index.json');
            const directories = path.dirname(indexFileComplete);
            fs.mkdirSync(directories, { recursive: true }, (err) => {
                if (err) throw err;
            });
            fs.copyFileSync(indexFile, indexFileComplete);
        }
    });
};

const copyCatFiles = async (seriesFolder) => {
    const seriesUrl = `series_${seriesFolder}`;
    let series = await Series.find({url: seriesUrl});

    if (!series.length) {
        return handleLog(`== No series: ${seriesUrl}`);
    }
    series = series[0];

    series.topics.forEach(topic => {
        topic.categories.forEach(topicCategory => {
            console.log(topicCategory.url);
            const filePath = topicCategory.url.replace('_', '/');
            const indexFile = vietjackJsonPath(seriesFolder + '/' + filePath + '.json');
            if (fs.existsSync(indexFile)) {
                const indexFileComplete = vietjackJsonPath(seriesFolder + '-temp/' + filePath + '.json');
                const directories = path.dirname(indexFileComplete);
                fs.mkdirSync(directories, { recursive: true }, (err) => {
                    if (err) throw err;
                });
                fs.copyFileSync(indexFile, indexFileComplete);
            } else {
                console.log('--- File not exist');
                console.log(indexFile);
            }
        });
    });
};

connectDb().then(async () => {
    // await copyCatFiles('lop-3');
    // await copyCatFiles('lop-4');
    // await copyCatFiles('lop-5');
    // await copyCatFiles('lop-6');
    // await copyCatFiles('lop-7');
    // await copyCatFiles('lop-8');
    await copyCatFiles('lop-9');
    // await copyCatFiles('lop-10');
    // await copyCatFiles('lop-11');
    // await copyCatFiles('lop-12');

    mongoose.connection.close();
    console.log("MongoDb closed");
});
// importFolder('lop-7');
