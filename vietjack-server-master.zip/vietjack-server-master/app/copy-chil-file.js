
const fs = require('fs');
const path = require('path');

const seriesFolder = 'lop-6';

let filePath = 'import-data/vietjack/lop-6-notcomplete/giai-toan-lop-6/index.json';
let level = 2;
// let removeComponent = false;
let removeComponent = true;
const componentHasRemove = [
    'Xem Đề kiểm tra',
    'Xem lời giải',
    'Xem chi tiết',
    'Xem bài văn mẫu'
];

let removeRegex = false;
// let removeRegex = true;
const regexHasRemove = [
    // /^Văn mẫu:/,
    /^Tổng hợp Lý thuyết Chương/,
    /^Chủ đề:/,
    /^Chuyên đề:/
    // /^Lý thuyết/,
    // /^Bài [0-9]{1,2}:/,
    // /^Bài [0-9]{1,2} - [0-9]{1,2}:/,
    // /^Bài [0-9]{1,2}-[0-9]{1,2}:/
    // /^Bài tập cuối chương/,
    // /^Bài tập ôn tập/,
    // /^Ôn tập cuối /,
    // /^Câu hỏi trắc nghiệm /,
    // /^Câu hỏi và bài tập chương /,
    // /^Đề toán tổng hợp /

];

// let storeRegex = false;
let storeRegex = true;
const regexHasStore = [
    // /^Lí thuyết/,
    // /^Lý thuyết/,
    /^Câu hỏi ôn tập/,
    /^Trả lời câu hỏi/,
    // /^Bài tập trắc nghiệm/,
    // /^Trả lời câu hỏi/,
    // /^Câu [0-9]{1,2}/,
    // /^Bài [0-9]{1,3} trang/
    /^Bài [0-9]{1,3} \(trang/,
    // /^Câu [0-9]{1,3} \(trang/,
    // /^Đề số [0-9]{1,2} \(trang/
    // /\(trang/
];

filePath = path.join(__dirname, '../' + filePath);
const vietjackJsonPath = (filePath) => path.join(__dirname, '../import-data/vietjack', filePath);

let content = fs.readFileSync(filePath, 'utf8');
let jsonContent = JSON.parse(content);

jsonContent.forEach(element => {
    if (element.level != level) {
        return;
    }
    const filePath = element.url.replace('_', '/');
    const indexFile = vietjackJsonPath(seriesFolder + '/' + filePath + '.json');

    if (fs.existsSync(indexFile)) {
        const indexFileComplete = vietjackJsonPath(seriesFolder + '-notcomplete/' + filePath + '.json');
        const directories = path.dirname(indexFileComplete);
        fs.mkdirSync(directories, { recursive: true }, (err) => {
            if (err) throw err;
        });
        if (!removeComponent) {
            fs.copyFileSync(indexFile, indexFileComplete);
            return;
        }

        let chilContent = fs.readFileSync(indexFile, 'utf8');

        let jsonChilContent = JSON.parse(chilContent);

        const saveData = [];

        for (let i = 0; i < jsonChilContent.length; i++) {
            if (componentHasRemove.indexOf(jsonChilContent[i].title) == -1) {

                let ctn = false;
                if (removeRegex) {
                    for (let j = 0; j < regexHasRemove.length; j++) {
                        if (jsonChilContent[i].title.match(regexHasRemove[j])) {
                            ctn = true;
                        }
                    }
                }

                if (ctn) {
                    continue;
                }

                if (!storeRegex) {
                    saveData.push(jsonChilContent[i]);
                    continue;
                }

                let isStore = false;
                for (let j = 0; j < regexHasStore.length; j++) {
                    if (jsonChilContent[i].title.match(regexHasStore[j])) {
                        isStore = true;
                    }
                }

                if (isStore) {
                    saveData.push(jsonChilContent[i]);
                }
            }
        }

        fs.writeFileSync(indexFileComplete, JSON.stringify(saveData, null, 4));
    }
});

// const directories = path.dirname(filePath);
// fs.mkdirSync(directories, { recursive: true }, (err) => {
//     if (err) throw err;
// });




// const filePath = url.replace('_', '/');
// const indexFile = vietjackJsonPath(seriesFolder + '/' + filePath + '.json');
// if (fs.existsSync(indexFile)) {
//     const indexFileComplete = vietjackJsonPath(seriesFolder + '-temp/' + filePath + '.json');
//     const directories = path.dirname(indexFileComplete);
//     fs.mkdirSync(directories, { recursive: true }, (err) => {
//         if (err) throw err;
//     });
//     fs.copyFileSync(indexFile, indexFileComplete);
// }
