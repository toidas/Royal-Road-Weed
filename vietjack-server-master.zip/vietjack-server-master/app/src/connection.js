const mongoose = require('mongoose');
const connection = 'mongodb://mongo:27017/mongo-test';
const connectDb = () => {
    // mongoose.set('useCreateIndex', true);
    return mongoose.connect(connection, { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true });
};

exports = module.exports = connectDb;
