const fs = require('fs');
const cheerio = require('cheerio')
const utils = require('../../utils');
const Category = require("../../models/Category");

const importCategory = (jsonLink) => {
    let content = fs.readFileSync(__dirname + '/data/' + jsonLink, 'utf8');
    let category = JSON.parse(content);

    let categoryModel = new Category(category);
    categoryModel.save(function (err) {
        if (err) return handleError(err);
        console.log('== Create category: ' + category.url);
    });
};

function importFile (filePath, title) {
    importCategory('giai-bai-tap-vat-ly-11.json');
    importCategory('tieng-anh-11.json');
}

exports = module.exports = importFile;
