const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio')
const mongoose = require('mongoose');
const utils = require('../../utils');
const Category = require("../../models/Category");
const Series = require("../../models/Series");
const {CATEGORY_TYPE, ARTICLE_TYPE} = require("../../models/Category");

const categoryJsonPath = (filePath) => path.join(__dirname, './json-data', filePath);

// const CATEGORY_TYPE = 0;
// const ARTICLE_TYPE = 1;

let runLogs = '';
let categories = [];
let filesImported = [];
let categoryNotFoundFile = [];
const newObjectId = () => mongoose.Types.ObjectId();

const saveRunLogs =  (fileName) => {
    runLogs += `========= File not found:\n` + categoryNotFoundFile.join(`\n`);
    const filePath = path.join(__dirname + '../../../../logs/categories/' + fileName.replace(/\.\.\//g, ''));
    const directories = path.dirname(filePath);
    fs.mkdirSync(directories, { recursive: true });
    fs.writeFileSync(filePath, runLogs);
    runLogs = '';
    categoryNotFoundFile = [];
};

const newCategory = (topicCategory = null) => (topicCategory ?
    {
        _id: topicCategory.category_id,
        url: topicCategory.url,
        title: topicCategory.title,
        text: "",
        type: CATEGORY_TYPE,
        group: topicCategory.group,
        group_name: topicCategory.group_name
    }
    :
    {
        _id: newObjectId(),
        url: "",
        title: "",
        text: "",
        type: CATEGORY_TYPE,
        group: utils.groupKey(utils.groupNameDefault),
        group_name: utils.groupNameDefault
    });

const handleLog = (e) => {
    // console.log(e);
    if (typeof e == 'string') {
        runLogs += `${e}\n`;
    }
};

const makeSeriesUrl = (name) => `series_${name}`;

const parseLevelCategory = (seriesFolder, categoriesJson, startIndex = 0, currentLevel = 0) => {
    const categoryGroup = [];
    for (let i = startIndex; i < categoriesJson.length; i++) {
        if (categoriesJson[i].level == currentLevel) {
            const newCategory = {
                title: categoriesJson[i].title,
                url: categoriesJson[i].url,
                type: 0,
            };

            const nextItem = i + 1;
            let hasChildren = (nextItem < categoriesJson.length && categoriesJson[nextItem].level > categoriesJson[i].level);
            if (hasChildren) {
                const {children, currentIndex} = parseLevelCategory(seriesFolder, categoriesJson, nextItem, categoriesJson[nextItem].level);
                newCategory.children = children;
                i = currentIndex;
                categoryGroup.push(newCategory);
                continue;
            }

            const childrenInFile = makeCategoryChildren(seriesFolder, newCategory.url);

            if (childrenInFile.length) {
                newCategory.children = childrenInFile;
            }

            if (!newCategory.children) {
                newCategory.type = 1;
            }

            categoryGroup.push(newCategory);
            continue;
        }

        return {
            children: categoryGroup,
            currentIndex: i - 1
        };
    }

    return {
        children: categoryGroup,
        currentIndex: categoriesJson.length
    };
};

const makeCategoryChildren = (seriesFolder, categoryUrl) => {
    const categoryJsonFile = categoryJsonPath(seriesFolder + '/' + categoryUrl.replace('_', '/') + '.json');
    // if (fs.existsSync(categoryJsonFile) && filesImported.indexOf(categoryJsonFile) != -1 && JSON.parse(fs.readFileSync(categoryJsonFile, 'utf8')).length > 0) {
    //     handleLog('[FilesImported] ' + categoryJsonFile);
    // }

    if (fs.existsSync(categoryJsonFile)) {
        const fileNotImported = filesImported.indexOf(categoryJsonFile) == -1;

        let categoriesJson = [];
        try {
            categoriesJson = JSON.parse(fs.readFileSync(categoryJsonFile, 'utf8'));
        } catch (e) {
            handleLog('[parse JSON error] ' + categoryJsonFile);
        }

        if (fileNotImported) {
            filesImported.push(categoryJsonFile);
            const {children} = parseLevelCategory(seriesFolder, categoriesJson);

            return children;
        }

        if (categoriesJson.length > 0) {
            handleLog('[FilesImported] ' + categoryJsonFile);
        }
    }

    return [];
}

const importCategory = async (seriesFolder) => {
    const seriesUrl = makeSeriesUrl(seriesFolder);
    let series = await Series.find({url: seriesUrl});

    if (!series.length) {
        return handleLog(`== No series: ${seriesUrl}`);
    }
    series = series[0];

    series.topics.forEach(topic => {
        topic.categories.forEach(topicCategory => {
            const category = newCategory(topicCategory);
            const categoryChildren = makeCategoryChildren(seriesFolder, category.url);
            category.children = categoryChildren;

            if (category.children.length) {
                categories.push(category);
            } else {
                categoryNotFoundFile.push(category.url);
                // handleLog('======[File not found] ' + category.url);
            }
        });
    });


    for (let i =  0; i < categories.length; i++) {
        const categoryModel = new Category(categories[i]);

        try {
            await Category.deleteMany({url: categories[i].url});
            await categoryModel.save();
            handleLog(`-- Create category: ${categories[i].url}`);
        } catch (err) {
            handleLog(`== Create category error: ${categories[i].url}`);
            handleLog(err.errmsg);
            handleLog(JSON.stringify(categories[i], null, 4));
        }
    }

    categories = [];
    saveRunLogs(seriesFolder + '.text');
};

const importCategories = async () => {
    await importCategory('lop-3');
    await importCategory('lop-4');
    await importCategory('lop-5');
    await importCategory('lop-6');
    await importCategory('lop-7');
    await importCategory('lop-8');
    await importCategory('lop-9');
    await importCategory('lop-10');
    await importCategory('lop-11');
    await importCategory('lop-12');

    // const fileUrl = 'giai-bai-tap-cong-nghe-7_index';
    // const fileUrl = 'giai-bai-tap-giao-duc-cong-dan-7_index';
    // const fileUrl = 'bai-tap-trac-nghiem-sinh-hoc-7_index';
    // const fileUrl = 'giai-sach-bai-tap-vat-li-7_index';
    // const category = newCategory();
    // category.title = fileUrl;
    // category.url = fileUrl;
    // category.children = makeCategoryChildren('lop-7', fileUrl);

    // const filePath = __dirname + '/json-result/' + fileUrl.replace('_', '/') + '.json';
    // const directories = path.dirname(filePath);
    // fs.mkdirSync(directories, { recursive: true });
    // fs.writeFileSync(filePath, JSON.stringify(category, null, 4));
    // console.log(JSON.stringify(category, null, 4));
    // const categoryModel = new Category(category);

    // try {
    //     await Category.remove({url: category.url});
    //     const newCategory = await categoryModel.save();
    //     handleLog(`-- Create category: ${category.url}`);
    // } catch (err) {
    //     handleLog(`== Create category error: ${category.url}`);
    //     handleLog(err);
    // }

    // saveRunLogs(fileUrl + '.text');
};

exports = module.exports = importCategories;
