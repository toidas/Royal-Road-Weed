const fs = require('fs');
const path = require('path');
const cheerio = require('cheerio');
const mongoose = require('mongoose');

const utils = require('../../utils');
const Article = require('../../models/Article');
const Series = require('../../models/Series');
const Category = require('../../models/Category');

let runLogs = '';
let articles = [];
const linksParsed = [];
const articlesDataNull = [];
const articlesCreateError = [];
const adsAfter = 25;

const handleLog = (e) => {
    console.log(e);
    return runLogs += `${e}\n`;
};

const componentHasRemove = [
    'Xem Đề kiểm tra',
    'Xem lời giải',
    'Xem chi tiết',
    'Xem bài văn mẫu'
];

const createNewDataContent = () => ({
    type: 0,
    content: ''
});

const createNewAudioContent = (src) => ({
    type: 1,
    content: src
});

const createNewToggleContent = (title, content) => ({
    type: 2,
    content: JSON.stringify({title, content})
});

const createNewAdsContent = () => ({
    type: 3,
    content: 'ads'
});

const newObjectId = () => mongoose.Types.ObjectId();

const createOrUpdateArticle = article => {
    const existArticle = findArticleByUrl(article.url);
    if (existArticle) {
        existArticle.title = article.title;
        existArticle.series_url = article.series_url;
        existArticle.topic_id = article.topic_id;
        existArticle.category_url = article.category_url;
        existArticle.data = article.data;
        existArticle.data_raw = article.data_raw;
        existArticle.data_raw_format = article.data_raw_format;
        existArticle.more = article.more;
        existArticle.related = article.related;
    } else {
        articles.push(article);
    }
};

const findArticleByUrl = (url) => {
    for (let i = 0; i < articles.length; i++) {
        if (articles[i].url == url) {
            return articles[i];
        }
    }

    return null;
};

const newEmptyArticle = (url, title = '') => {
    const newArticle = {
        _id: newObjectId(),
        title: title,
        series_url: '',
        topic_id: '',
        category_url: '',
        url: url,
        data: [],
        data_raw: '',
        more: [],
        related: [],
    };

    articles.push(newArticle);

    return newArticle;
};

const removeUnuseTag = (middleCol) => {
    middleCol.find('.fb-comments').remove();
    middleCol.find('.breadCrumb').remove();
    middleCol.find('.vj-tabs').remove();
    middleCol.find('.pre-btn').remove();
    middleCol.find('.clearer').remove();
    middleCol.find('.paging-btn').remove();
    middleCol.find('.social-btn').remove();
    middleCol.find('.nxt-btn').remove();
    return middleCol;
};

const isRelatedElm = elm => {
    const relatedRegex = [
        /^xem thêm .+ khác$/,
        /khác.*?:$/
    ];
    const text = elm.text().trim().toLowerCase();
    let regexMatched = false;

    for (let i = 0; i < relatedRegex.length; i++) {
        if (text.match(relatedRegex[i])) {
            regexMatched = true;
            break;
        }
    }

    return regexMatched && (elm.next().find('a').length || elm.next().next().find('a').length);
};

const saveArticle = ($, middleCol, url, category, topic, series) => {
    const parentUrlElm = middleCol.find('.parent-file');
    middleCol.find('hr').remove();
    parentUrlElm.remove();
    const elements = middleCol.children();
    let titleIndex = 0;

    if (elements.length < 1) {
        handleLog(`== no middleCol children ${url}`);
        return;
    }

    const article = {
        _id: newObjectId(),
        title: '',
        series_url: series.url,
        topic_id: topic._id,
        category_url: category.url,
        url: utils.makeUrlId(url),
        parent_url: utils.makeUrlId(parentUrlElm.text()),
        data_raw: '',
        data: [],
        more: [],
        related: [],
    };

    if (elements[titleIndex].tagName == 'h1' || elements[titleIndex].tagName == 'h2') {
        article.title = $(elements[titleIndex]).text();
    } else {
        handleLog(`-- no title ${url} ${elements[titleIndex].tagName} ${$(elements[titleIndex]).attr('class')}`);
        for (let j = 1; j < elements.length; j++) {
            handleLog(`-- find next chil: ${j}`);

            if (elements[j].tagName == 'h1' || elements[j].tagName == 'h2') {
                titleIndex = j;
                article.title = $(elements[j]).text();
                handleLog(`------ exist: ${article.title}`);
                break;
            }
            handleLog(`---- not match: ${elements[j].tagName}`);
        }
    }

    if (!article.title) {
        handleLog(`------ No title: ${url}`);
    }

    let dataContent = createNewDataContent();
    let addTopAds = false;
    let adsRemain = 2;
    let lineCount = 0;

    for (let i = titleIndex; i < elements.length; i++) {
        const chilElm = $(elements[i]);

        if (elements[i].name == 'hr') {
            continue;
        }

        if (!addTopAds && i > titleIndex && elements[i].name == 'p') {
            if (dataContent.content) {
                article.data.push(dataContent);
            }
            article.data.push(createNewAdsContent());
            dataContent = createNewDataContent();
            addTopAds = true;
        }

        // if (i == Math.round(elements.length / 2)) {
        //     if (dataContent.content) {
        //         article.data.push(dataContent);
        //     }
        //     article.data.push(createNewAdsContent());
        //     dataContent = createNewDataContent();
        // }

        if (elements[i].name == 'audio') {
            let audioSource = chilElm.find('source');
            if (dataContent.content) {
                article.data.push(dataContent);
            }

            if (audioSource.length) {
                article.data.push(createNewAudioContent(utils.makeVietjackFullUrl($(audioSource).attr('src'))));
            }

            dataContent = createNewDataContent();

            lineCount++;
            continue;
        }

        if (elements[i].name == 'section' && chilElm.hasClass('toggle')) {
            let toggleTitle = $(chilElm.find('label')).text();
            let toggleContent = $(chilElm.find('.toggle-content')).html()

            if (dataContent.content) {
                article.data.push(dataContent);
            }

            if (toggleTitle && toggleContent) {
                article.data.push(createNewToggleContent(toggleTitle, toggleContent));
            }

            dataContent = createNewDataContent();

            lineCount++;
            continue;
        }

        if (isRelatedElm(chilElm)) {
            chilElm.remove();
            continue;
        }

        let relatedLinks = chilElm.find('a');
        if (relatedLinks.length > 0) {
            for (let j = 0; j < relatedLinks.length; j++) {
                const href = $(relatedLinks[j]).attr('href');
                if (!href || componentHasRemove.indexOf($(relatedLinks[j]).text()) != -1) {
                    continue;
                }
                const rlUrl = utils.makeUrlId(href);
                const rlTitle = $(relatedLinks[j]).text();

                const existArticle = findArticleByUrl(rlUrl);

                article.related.push({
                    article_id: existArticle ? existArticle._id : newEmptyArticle(rlUrl, rlTitle)._id,
                    title: rlTitle,
                    url: rlUrl
                });
            }

            chilElm.remove();
            continue;
        }

        dataContent.content += utils.cleanHtmlContent($.html(chilElm));
        const chilElmText = chilElm.text();
        article.data_raw += ' ' + chilElmText;


        const chilElmTextWord = chilElmText.split(' ');
        lineCount += Math.floor(chilElmTextWord.length / 10) + 1;

        if (lineCount >= adsAfter && adsRemain > 0) {
            lineCount = 0;
            adsRemain = adsRemain - 1;
            if (dataContent.content) {
                article.data.push(dataContent);
            }
            article.data.push(createNewAdsContent());
            dataContent = createNewDataContent();
        }
    }

    if (dataContent.content) {
        article.data.push(dataContent);
    }

    article.data_raw = utils.formatString(article.data_raw);
    article.data_raw_format = utils.formatUnicodeString(article.data_raw);

    // const filePath = '../import-data/data-article-json/' + url.replace(/\.jsp$/, '.json').replace(/\//, '_');
    // const directories = path.dirname(filePath);
    // fs.mkdirSync(directories, { recursive: true }, (err) => {
    //     if (err) throw err;
    // });
    // fs.writeFileSync(filePath, JSON.stringify(article, null, 4));

    createOrUpdateArticle(article);
}

const storeArticle = (link, fileName, category, topic, series) => {
    const fullPath = utils.makeFileJspFullPath(link);
    if (!fs.existsSync(fullPath)) {
        handleLog(`[utils][getLinks] No such file: ${link}`);
        return;
    }

    const content = utils.cleanContent(fs.readFileSync(fullPath, 'utf8'));
    const $ = cheerio.load(content);
    const middleCol = removeUnuseTag($('.middle-col'));

    $('img').each(function() {
        let oldSrc = $(this).attr('src');
        let newSrc = utils.makeVietjackFullUrl(oldSrc);
        $(this).attr('src', newSrc);
    });

    const writeContent = middleCol.html();

    if (!writeContent) {
        const fileOriginContent = fs.readFileSync(fullPath, 'utf8').replace(/\n/gi, '');
        if (!fileOriginContent.match(/response\.setHeader/)) {
            handleLog(`++++ link not parsed: ${link}`);
            return;
        }

        const replaceMatch = fileOriginContent.match(/\.\.\/.*\.jsp/);
        if (replaceMatch) {
            handleLog(`++ link: ${link} redirect to ${replaceMatch[0]}`);
            return storeArticle(replaceMatch[0].replace(/\.\.\//gi, ''), link, category, topic, series);
        }
    }

    return saveArticle($, middleCol, fileName ? fileName : link, category, topic, series);
};

// const importFile = (filePath) => {
//     storeArticle(filePath);
//     linksParsed.push(filePath);

//     const links = utils.getLinks(filePath);
//     links.map((item) => {
//         const chilLink = item.url;
//         if (chilLink.match(/\.jsp$/) && linksParsed.indexOf(chilLink) == -1) {
//             importFile(chilLink);
//         }
//     });
// };

const saveRunLogs = (fileName) => {
    const filePath = __dirname + '/../../../logs/articles/' + fileName;
    const directories = path.dirname(filePath);
    fs.mkdirSync(directories, { recursive: true }, (err) => {
        if (err) throw err;
    });
    fs.writeFileSync(filePath, runLogs);
    runLogs = '';
};

const importCategoryChil = (category, children, topic, series) => {
    for (let i = 0; i < children.length; i++) {
        if (children[i].type == 0) {
            importCategoryChil(category, children[i].children, topic, series);
        } else {
            storeArticle(children[i].url.replace(/_/g, '/') + '.jsp', '', category, topic, series);
        }
    }
};

const importCategory = async (category, topic, series) => {
    const categoryModel = await Category.findOne({url: category.url});
    if (!categoryModel) {
        handleLog(`== Not found category ${category.url}`);
        return;
    }

    importCategoryChil(categoryModel, categoryModel.children, topic, series);
};

const importTopic = async (topic, series) => {
    for (let i = 0; i < topic.categories.length; i++) {
        await importCategory(topic.categories[i], topic, series);
    }
};

const importSeries = async (seriesPath) => {
    const series = await Series.findOne({url: utils.makeUrlId(seriesPath)});
    for (let i = 0; i < series.topics.length; i++) {
        const topic = series.topics[i];
        await importTopic(topic, series);
    }

    for (let i =  0; i < articles.length; i++) {
        if (articles[i].data.length == 0) {
            articlesDataNull.push(articles[i]);
            continue;
        }
        const article = articles[i];
        const relatedArticles = [];

        // Loại bỏ các article không được import (category)
        for (let k = 0; k < article.related.length; k++) {
            const relatedArticle = findArticleByUrl(article.related[k].url);

            if (relatedArticle && relatedArticle.data_raw != '') {
                relatedArticles.push(article.related[k]);
            }
        }

        article.related = relatedArticles;

        let articleModel = new Article(article);

        try {
            const newArticle = await articleModel.save();
            handleLog(`-- Create article: ${article.url}`);
        } catch (err) {
            handleLog(`== Create article error: ${article.url} ${err.message}`);
            articlesCreateError.push(article);
        }
    }

    articles = [];
    saveRunLogs(seriesPath.replace(/\.jsp$/, '.text').replace(/\//, '_'));
};

const importAllSeries = async () => {
    // storeArticle('tieng-viet-lop-4/ke-chuyen-su-tich-ho-ba-be.jsp');
    await Article.deleteMany({});
    await importSeries('series/lop-3.jsp');
    await importSeries('series/lop-4.jsp');
    await importSeries('series/lop-5.jsp');
    await importSeries('series/lop-6.jsp');
    await importSeries('series/lop-7.jsp');
    await importSeries('series/lop-8.jsp');
    await importSeries('series/lop-9.jsp');
    await importSeries('series/lop-10.jsp');
    await importSeries('series/lop-11.jsp');
    await importSeries('series/lop-12.jsp');
    // await importSeries('series/it-lap-trinh.jsp');
};

exports = module.exports = importAllSeries;
