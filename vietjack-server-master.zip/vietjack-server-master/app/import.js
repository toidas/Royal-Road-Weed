const connectDb = require("./src/connection");
const mongoose = require('mongoose');
const fs = require('fs');
const utils = require('./src/utils');
const path = require('path');
const importAllArticle = require('./src/import/articles/import-all');
const importAllFile = require('./src/import/import-all-file');
const importAllCategories = require('./src/import/categories/import-all');
const importJsonCategories = require('./src/import/categories/import-json');
const importAllSeries = require('./src/import/series/import-all');


connectDb().then(async () => {
    console.log("MongoDb connected");
    // importAllArticle();
    // importAllCategories()
    // await importAllFile();

    /* ==== new ====*/
    // await importAllSeries();
    // await importJsonCategories();
    await importAllArticle();

    mongoose.connection.close();
    console.log("MongoDb closed");
});
