
# User authenticate

## login

### request

POST /users/login-social

body
```json
{
    "uid": "social_uid",
    "token": "social_token",
    "type": 0,
    "avatar": "https://user_avatar_url.png",
    "email": "useremail@gmail.com",
    "name": "User Name",
    "phone": "0987654345",
    "birthday": "2000-12-12"
}
```

- uid: required|string
- token: required|string
- type: required|number|0 - facebook, 1 - google
- avatar: string
- email: string
- name: string
- phone: string

### response

```json
{
    "user": {
        "_id": "userid",
        "avatar": "https://user_avatar_url.png",
        "email": "useremail@gmail.com",
        "name": "User Name",
        "phone": "0987654345",
        "birthday": "2000-12-12"
    },
    "token": "authtoken"
}
```

- user: thông tin user
- token: auth token, dùng để thêm vào header của các request sau. Thời hạn của auth token là mãi mãi. Đế khi người dùng logout.

## get user info

### request

GET /users/me

header
```
Authorization: Bearer auth_token_auth_token_auth_token
```

### response

```json
{
    "user": {
        "_id": "userid",
        "avatar": "https://user_avatar_url.png",
        "email": "useremail@gmail.com",
        "name": "User Name",
        "phone": "0987654345",
        "birthday": "2000-12-12"
    }
}
```

## update user info

### request

POST /users/me

body
```json
{
    "email": "user@gmail.com",
    "name": "user",
    "phone": "0987654345",
    "birthday": "2000-12-12"
}
```

### response

```json
{
    "user": {
        "_id": "userid",
        "avatar": "https://user_avatar_url.png",
        "email": "user@gmail.com",
        "name": "user",
        "phone": "0987654345",
        "birthday": "2000-12-12"
    }
}
```

## logout

### request
POST /users/me/logout

header
```
Authorization: Bearer auth_token_auth_token_auth_token
```

## imei
add header
```
imei: deviceimei1234
```

imei phải là duy nhất.
Vì có 2 nền tảng với 2 phương pháp sinh số unique khác nhau nên có thể cho tiền tố `android` và `ios` để đảm bảo imei là duy nhất

### response

# Get data
Khi user đăng nhập thì phải có header `Authorization`

- Lấy tất cả series: http://domain.lc:8080/series
- Lấy series theo url: http://domain.lc:8080/series-url/ulr_cua_series


- Lấy tất cả categories: http://domain.lc:8080/categories
- Lấy categories theo url: http://domain.lc:8080/categories-url/ulr_cua_category

- Lấy article: http://domain.lc:8080/articles-url/ulr_cua_article


Series là cái menu to nhất: https://vietjack.com/series/lop-11.jsp
Series gồm nhiều categories
Category gồm nhiều articles

## search article

### request
GET /articles-search?q=search_keyword&p_url=series_lop-3&p_topic=5d99f87efa14c2021592645e&page=1

- q: từ khóa tìm kiếm
- p_url: url của series hoặc category. Vi dụ: p_url=series_lop-3 hoặc p_url=soan-van-lop-8_index
- p_topic: là _id của môn học (topic). Nếu p_url là url của quyển sách thì không cần p_topic
- page: số trang

### response
```json
{
    "docs": [
        {
            "_id": 1234,
            "title": "Article title 1",
            "url": "article_url_1",
            "short_data": "short data 150 char"
        },
        {
            "_id": 456,
            "title": "Article title 2",
            "url": "article_url_2",
            "short_data": "short data 150 char"
        },
    ],
    "total": 8867,
    "limit": 20,
    "page": null,
    "pages": 444
}
```
