import {HISTORY} from '../constants/action-type';
import {getHistory} from '../api/server-api';
export function updateHistory(data) {
    let obj = {
        type: HISTORY,
        data
    }
    return obj;
}

export function fetchData(pageNum,pageSize,isUploadForm = false) {
  return (dispatch) => {
     getHistory(pageNum,pageSize,response => {
        let data = {
            requestTest: response.content ? response.content : [],
            totalElement: response.totalElements ? response.totalElements : 0
        };
        if(!isUploadForm) {
            data = {...data, offset : 0}
        }
        dispatch(updateHistory(data));
     },err => {
        alert(err);
     })
  }
}