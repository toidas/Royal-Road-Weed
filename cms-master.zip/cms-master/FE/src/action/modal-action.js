import {MODAL_SHOW, UPDATE_MODAL_DATA} from '../constants/action-type';

export function toggleDialog(showModal) {
   let obj = {
    type : MODAL_SHOW,
    showModal
   }
   return obj;
}

export function updateModalData(data) {
    let obj = {
        type: UPDATE_MODAL_DATA,
        data
    }
    return obj;
}