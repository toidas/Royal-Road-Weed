import * as ActionType from '../../constants/action-type';

const initialState = { 
   requestTest: [],
   pageNumber: 0,
   pageSize: 10,
   totalElement: 10,
   offset: 0
}
export default function historyReducer (state = initialState , action) {
    switch (action.type) {
        case ActionType.HISTORY:
            let obj = action.data;
            return {...state,...obj};
        default:
            return state;
    }
}