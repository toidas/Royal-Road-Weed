import * as ActionType from  '../../constants/action-type';

const initState = {
    showModal : false,
    fileList: [{id: 1, description:"GOS"}, {id:2, description:"GOS TEST"}],
    notice: '',
    testCodeList: [1, 2, 3],
    version: '',
    idRequest: null,
    selectedDate: new Date('2014-08-18T21:11:54'),
    selectDeadLine: new Date('2014-08-18T21:11:54'),
    notify: [],
    requester: '',
    testItem: '',
    optionList: '',
    id: null
}

export default function ModalReducer (state = initState, action) {
   switch (action.type) {
       case ActionType.MODAL_SHOW:
           return {...state,showModal: action.showModal};
       case ActionType.UPDATE_MODAL_DATA:
           let obj = action.data;
           return {...state, ...obj}
       default:
           return state;
   }
}