import {combineReducers} from 'redux';
import historyData from './request-reducer/history-reducer';
import modal from './request-reducer/modal-reducer';
const rootReducer = combineReducers({
    historyData,
    modal
})

export default rootReducer;