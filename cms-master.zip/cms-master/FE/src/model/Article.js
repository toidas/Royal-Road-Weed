class Article {
    url = "";
    title = "";
    created_at = "";
    topics = [];

    randomData(index) {
        this.url = "Article " + index;
        this.title = "Article " + index;
        this.created_at = new Date();

        for (let i = 0; i < 5; i++) {
            let topic = new Topic();
            topic.createTopic("Topic " + i, "Categories " + i, "Type " + i);
            this.topics.push(topic);
        }
    }

    createNewArticle(){
        this.title = "New Article";
    }

    createArticle(url, title, created_at, tpoics){
        this.url = url;
        this.title = title;
        this.created_at = created_at;
        this.tpoics = tpoics;
    }
}

export default Article
