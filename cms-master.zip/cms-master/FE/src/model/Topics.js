class Topic{
    title = "";
    url = "";
    categories = [];
    type = 1;
    _id = null;

    createTopic(title,categories){
        this.title = title;
        this.categories = categories;
    }
}

export default Topic