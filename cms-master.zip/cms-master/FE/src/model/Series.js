import Topic from './Topics'
class Series {
    url = "";
    title = "";
    created_at = "";
    topics = [];

    randomData(index){
        this.url = "Series "+index;
        this.title = "Series "+index;
        this.created_at = new Date();

        for(let i=0;i<5;i++){
            let topic = new Topic();
            topic.createTopic("Topic "+i,"Categories "+i,"Type "+i);
            this.topics.push(topic);
        }
    }

    createNewSeries(){
        this.title = "New Series";
    }

    createSeries(url,title,created_at,tpoics){
        this.url = url;
        this.title = title;
        this.created_at = created_at;
        this.tpoics = tpoics;
    }
}

export default Series
