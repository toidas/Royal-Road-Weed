class Categories{
    category_id = "";
    _id = "";
    url = "";
    title = "";
    level = 0;
    children = [];
    type = 1;

    createNewCategories(level){
        this.url = "New Categories";
        this.title = "New Categories";
        this.level = level;
        this.type = 0;
    }
}

export default Categories