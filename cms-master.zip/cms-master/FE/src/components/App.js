import React, { Component } from 'react';
import './App.scss';
import { Router } from 'react-router-dom';
import { createBrowserHistory } from 'history';
import theme from './theme';
import { ThemeProvider } from '@material-ui/styles';
import 'bootstrap/dist/css/bootstrap.min.css';
import Routes from '../Routes';
const browserHistory = createBrowserHistory();
class App extends Component {
  render() {
    return (
      <ThemeProvider theme={theme}>
        <Router history={browserHistory}>
          <Routes />
        </Router>
      </ThemeProvider>
    );
  }
}

export default App;
