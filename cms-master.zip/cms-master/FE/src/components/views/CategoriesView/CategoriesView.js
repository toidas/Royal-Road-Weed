import React, {Component} from 'react';
import Categories from '../../../model/Categories.js'
import CategoriesViewItem from './CategoriesViewItem'
import './CategoriesView.scss';
import CategoriesServce from '../../../api/categories-api.js'
class CategoriesView extends Component {

    constructor(props){
        super(props);
        this.state = {categories: {children : []},level : 0,parentUrl:""};
    }

    createData = () => {
        // let categoriesTmp = [];
        // for(let i=0;i<5;i++){
        //     let a = new Categories(); 
        //     a.createNewCategories(this.state.level);
        //     categoriesTmp.push(a);
        // }
        // //console.log(seriesTmp);
        // this.setState({
        //   categories: categoriesTmp
        // })
        //console.log(CategoriesServce.categoriesId);
        let url = this.props.match.params.url;
        if(url != null && url !== ""){
            CategoriesServce.getCategories(url,this.fetchData);
            this.setState({
                parentUrl: url
            })
        }
       
    }

    saveCategories = () => {
        if (window.confirm("Bạn muốn lưu chỉnh sửa ?")) {
        //console.log(this.state.categories)
            CategoriesServce.saveCategories(this.state.categories,this.fetchData);
        }
    }

    saveCategoriesAndGoArtilce = (url) => {
        CategoriesServce.saveCategoriesAndGoArtilce(this.state.categories).then(val => {
            this.props.history.push("/articles/"+this.state.parentUrl+"/"+url);
        }).catch(err => {
            console.log(err);
        });
    }

    fetchData = (data) => {
        console.log(data);
        this.setState({
            categories: data
        })
    }

    addCategories = () =>{
        let categoriesTmp = this.state.categories;
        let categoriesChilTmp = categoriesTmp.children;
        let a = new Categories(); 
        a.createNewCategories(this.state.level);
        categoriesChilTmp.push(a);
        this.setState({
          categories: categoriesTmp
        })
    }
    

    componentWillMount = () => {
        //console.log("123");
        this.createData();
    }

    getCurrentTime = () => {
        let date = new Date();
        return date.getTime();
    }

    deleteCategoriesByIndex = (index) => {
        //console.log(index+"");
        let categoriesTmp = this.state.categories;
        let categoriesChilTmp = categoriesTmp.children;
        categoriesChilTmp.splice(index, 1);
        //console.log(seriesTmp);
        this.setState({
            categories: categoriesTmp
        })
        //console.log("delete");
    }

    render() {
        //console.log(this.state.categories);
        return (
            <div>
                <div class="series">
                    <div id="accordion">
                        <h1>{this.state.categories.title}</h1>
                        {this.state.categories.children.map((item, index) => (
                            <CategoriesViewItem parentUrl={this.state.parentUrl} saveCategories = {this.saveCategoriesAndGoArtilce} deleteCategoriesByIndex={this.deleteCategoriesByIndex} history={this.props.history} item={item} id={index} level={this.state.level+1}/>
                        ))}
                        <div>
                            <button class="btn btn-link" onClick={this.addCategories}>Thêm Categories</button>
                        </div>
                        <button class="btn btn-primary" onClick={this.saveCategories}>Lưu Mục Lục</button>
                    </div>    
                </div>
            </div>
        )
    }

}
export default CategoriesView;