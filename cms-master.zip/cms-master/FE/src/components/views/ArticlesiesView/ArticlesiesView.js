import React, {Component} from 'react';
import ArticleViewItem from './ArticleViewItem'
import ArticleServce from '../../../api/article-api.js'

class ArticlesiesView extends Component {

    constructor(props){
        super(props);
        this.state = {
            article : {},
            releted: []
        };
    }

    componentDidUpdate = (prevProps,prevState) => {
        
    }

    componentDidMount = () => {
        let articleID = this.props.match.params.id
        let categoriesID = this.props.match.params.url
        console.log(articleID+" / "+categoriesID);
        if(articleID != null && articleID !== "" ){
            ArticleServce.getArticle(articleID,this.fetchData);
            
        }
        if(categoriesID != null && categoriesID !== ""){
            ArticleServce.getRelated(categoriesID,this.fetchRelate);
        }
    }


    fetchRelate = (data) => {
        //console.log(data);
        this.setState({
            releted: data        
        })
    }

    fetchData = (data) => {
        this.setState({
            article: data        
        })
    }

    render() {
        //console.log(this.state.series);
        return (
            <div>
                <ArticleViewItem releted={this.state.releted} article={this.state.article}/>
            </div>
        );
    }
}

export default ArticlesiesView;
