import React, {Component} from 'react';
import Multiselect from 'react-widgets/lib/Multiselect';
import TextareaAutosize from 'react-textarea-autosize';
import CategoriesServce from '../../../../api/categories-api.js'
import ArticleServce from '../../../../api/article-api.js'
import { Modal ,Button} from 'react-bootstrap';
import renderHTML from 'react-render-html';

import './ArticleViewItem.scss';

class ArticleViewItem extends Component {

    constructor(props){
        super(props);
        this.state = {
            article : {},
            releted : [],
            show : false,
            html : ""
        };
    }
    

    componentDidUpdate = (prevProps,prevState) => {
        //console.log(this.props.article);
        if(prevProps.article !== this.props.article) {
            let releted = []
            if(this.props.article != null && this.props.article.related != null){
                this.props.article.related.forEach((item) => {
                    releted.push(item);
                })
            }
            if(this.props.article != null){
                this.setState({
                    article: this.props.article,
                    releted : releted
                })
            }
        }
    }

    componentDidMount = () => {
        
    }

    saveArticle = () => {
        if (window.confirm("Bạn muốn lưu lại chỉnh sửa ?")) {
            ArticleServce.saveArticle(this.state.article);
        }
    }

    changeTitle = (e) => {
        let article = this.state.article;
        article.title = e.target.value;
        this.setState({
            article: article
        })
    }

    changeUrl = (e) => {
        let article = this.state.article;
        article.url = e.target.value;
        this.setState({
            article: article
        })
    }

    onChangeSelect = (value ) => {
        let article = this.state.article;
        article.related = value;
        this.setState({
            article: article
        })
    }

    changeText = (e) => {
        let article = this.state.article;
        article.html = e.target.value;
        this.setState({
            article: article
        })
    }

    handleClose = () => {
        this.setState({
            show: false
        })
    }

    handleShow = () => {
        this.setState({
            show: true,
            html: this.state.article.html
        })
    }

    previewHtml = () => {
        this.handleShow();
    }

    render() {

        return (
            <div className='container-fluid article-item'>
                <form>
                    <div className='form-group'>
                        <label for='title'>Tiêu đề</label>
                        <input type='text' value={this.state.article.title} onChange={this.changeTitle} className='form-control' id='title' />
                    </div>
                    <div className='form-group'>
                        <label for='url'>Url</label>
                        <input type='text' value={this.state.article.url} onChange={this.changeUrl} className='form-control' id='url' />
                    </div>
                    <div className='form-group'>
                        <label for='related'>Bài viết liên quan</label>
                        {this.props.releted != null && this.props.article != null &&  this.state.article.related != null ?
                        <Multiselect
                            onChange={value => this.onChangeSelect({value})}
                            data={this.props.releted}
                            defaultValue={this.state.article.related}
                            textField='title'
                            caseSensitive={false}
                            minLength={3}
                            filter='contains'
                        />:null
                        }
                    </div>
                    <div className='form-group'>
                        <label for='data'>Nôi dung HTML</label>
                        <TextareaAutosize onChange={this.changeText} value={this.state.article.html}  className='form-control' minRows={15} inputRef={tag => (this.textarea = tag)} />
                    </div>
                </form>
                <button class="btn btn-primary" onClick={this.previewHtml}>Preview Html</button>
                <br></br>
                <div style={{marginTop: '1em'}}>
                    <button class="btn btn-primary" onClick={this.saveArticle}>Lưu Bài Viết</button>
                </div>
                <div className = 'modalDiv'>
                    <Modal show={this.state.show} onHide={this.handleClose}>
                        <Modal.Header closeButton>
                        <Modal.Title>Preview Html</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div>{
                                renderHTML(this.state.html)
                                }
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                        <Button variant="secondary" onClick={this.handleClose}>
                            Close
                        </Button>
                        </Modal.Footer>
                    </Modal>
                </div>
                
            </div>
        )
    }
}

export default ArticleViewItem;
