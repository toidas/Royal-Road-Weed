import React, {Component} from 'react';
import Series from '../../../../model/Series.js'
import Topic from '../../../../model/Topics.js'
import TopicViewItem from './TopicViewItem'
import TopicServce from '../../../../api/topic-api.js'
import './SeriesViewItem.scss';

class SeriesViewItem extends Component {

    constructor(props){
        super(props);
        this.state = {series : new Series(), target: ''};

    }

    componentDidUpdate = (prevProps,prevState) => {
        if(prevProps.item !== this.props.item) {
             this.setState({
                 target: "#"+this.props.id,
                 series: this.props.item
            })
        }
        //console.log(this.props.id);
    }

    componentDidMount = () => {
        this.setState({
            target: "#"+this.props.id,
            series: this.props.item
        })
        //console.log(this.props.id);
    }

    addTopic = () => {
        let series = this.state.series;
        let topics = series.topics;
        let topic = new Topic();
        topic.createTopic("New Topic",[]);
        topics.push(topic);
        this.setState({
          series: series
        })
        //console.log("click them");
    }

    saveTopic = () => {

    }

    saveSeries = () => {
        if (window.confirm("Bạn muốn lưu chỉnh sửa ?")) {
            TopicServce.saveTopic(this.state.series, this.fetchData);
        }
    }

    fetchData = (data) => {
        this.setState({
            series: data
        })
    }

    deleteTopic = (index) => {
        let series = this.state.series;
        let topics = series.topics;
        topics.splice(index, 1);
        //console.log(seriesTmp);
        this.setState({
          series: series
        })
    }

    deleteSeries = () => {
        if (window.confirm("Bạn có chắc muốn xóa không ?")) {
            this.props.deleteSeriesByIndex(this.props.id);
        }
    }

    changeTitle = (e) => {
        let series = this.state.series;
        series.title = e.target.value;
        this.setState({
          series: series
        })
    }

    changeTitleTopic = (index , e) => {
        //console.log("123");
        let series = this.state.series;
        series.topics[index].title = e.target.value;
        this.setState({
          series: series
        })
    }

    deleteTopic = (index) => {
        let series = this.state.series;
        let topic = series.topics;
        topic.splice(index, 1);
        this.setState({
            series: series
        })
    }

    goCategories = (index , e) => {

    }

    render() {
        return (
            <div className="card">
                <div className="card-header" id="myCollapsible">
                <h5 className="mb-0">
                    <button className="btn btn-link" data-toggle="collapse" data-target={this.state.target} aria-expanded="false" aria-controls="collapseOne">
                    {"Click"}
                    </button>
                    <input type="text" value={this.state.series.title} onChange={this.changeTitle}/>
                    <button className="btn btn-link" onClick={this.saveSeries}>Save</button>
                    <button className="btn btn-link" onClick={this.deleteSeries}>Delete</button>
                </h5>
                </div>

                <div id={this.props.id} className="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                <div className="card-body">
                    {this.state.series.topics.map((item, index) => (
                         <div key={index}>
                             {/* <input type="text" value={item.title} onChange={this.changeTitleTopic.bind(this,index)}/>
                             <button className="btn btn-link" onClick={this.deleteTopic.bind(this,index)}>Delete</button>
                             {this.state.series.topics[index]._id != null ?
                                <button className="btn btn-link" onClick={this.goCategories.bind(this,index)}>Go</button> : null
                             } */}
                             <TopicViewItem deleteTopic={this.deleteTopic} history={this.props.history} item={item} id={index} level={this.props.index}/>
                        </div>
                    ))}
                    <div>
                        <button className="btn btn-link" onClick={this.addTopic}>Thêm Topic</button>
                    </div>
                </div>
                </div>
            </div>
        )
    }
}

export default SeriesViewItem;
