import React, {Component} from 'react';
import Categories from '../../../../../model/Categories.js'
import Topic from '../../../../../model/Topics.js'
import './TopicViewItem.scss';
import CategoriesServce from '../../../../../api/categories-api.js'

class TopicViewItem extends Component {

    constructor(props){
        super(props);
        this.state = {topic : new Topic(), target: '',targetID: '',dataParentID: ''};

    }

    componentDidUpdate = (prevProps,prevState) => {
        if(prevProps.item !== this.props.item) {
             this.setState({
                 target: "#"+this.props.level+this.props.id,
                 targetID: ""+this.props.level+this.props.id,
                 dataParentID: "#accordion"+this.props.level,
                 topic: this.props.item
            })
        }
    }

    componentDidMount = () => {
        this.setState({
            target: "#"+this.props.level+this.props.id,
            targetID: ""+this.props.level+this.props.id,
            dataParentID: "#accordion"+this.props.level,
            topic: this.props.item
        })
        //console.log("#"+this.props.level+this.props.id);
    }

    addCategories = () => {
        let topic = this.state.topic;
        let categories = topic.categories;
        let newCategories = new Categories();
        newCategories.createNewCategories(this.props.level);
        categories.push(newCategories);
        this.setState({
            topic: topic
        })
        //console.log("click them");
    }

    // saveTopic = () => {

    // }

    // saveCategories = () => {
    //     console.log(this.state.categories);
    // }

    deleteTopic = () => {
        if (window.confirm("Bạn có chắc muốn xóa không ?")) {
            this.props.deleteTopic(this.props.id);
        }
    }

    // deleteCategories = () => {
    //     this.props.deleteCategoriesByIndex(this.props.id);
    // }

    changeTitle = (e) => {
        let topic = this.state.topic;
        topic.title = e.target.value;
        this.setState({
            topic: topic
        })
    }

    changeTitleCategories = (index,e) => {
        let topic = this.state.topic;
        let categories = topic.categories;
        categories[index].title = e.target.value;
        this.setState({
            topic: topic
        })
    }

    goCategories = (index) => {
        let topic = this.state.topic;
        let categories = topic.categories;
        //CategoriesServce.categoriesName = categories[index].title;
        this.props.history.push("/categories/"+categories[index].url);
    }

    deleteCategories = (index) => {
        if (window.confirm("Bạn có chắc muốn xóa không ?")) {
            let topic = this.state.topic;
            let categories = topic.categories;
            categories.splice(index, 1);
            this.setState({
                topic: topic
            })
        }
    }


    render() {

        return (
            <div className="card">
                <div className="card-header"  >
                    <h5 className="mb-0">
                        <button className="btn btn-link" data-toggle="collapse" data-target={this.state.target} aria-expanded="false">{"Click"}</button>
                        <input type="text" value={this.state.topic.title} onChange={this.changeTitle}/>
                        <button className="btn btn-link" onClick={this.deleteTopic}>Delete</button>
                    </h5>
                </div>

                <div id={this.state.targetID} className="collapse"  data-parent={this.state.dataParentID}>
                    <div className="card-body">
                        {this.state.topic.categories.map((item, index) => (
                            <div key={index}>
                                <input type="text" value={item.title} onChange={this.changeTitleCategories.bind(this,index)}/>
                                <button className="btn btn-link" onClick={this.deleteCategories.bind(this,index)}>Delete</button>
                                {item._id != "" ?
                                    <button className="btn btn-link" onClick={this.goCategories.bind(this,index)}>Go</button> : null
                                }
                            </div>
                        ))}
                        <div>
                            <button className="btn btn-link" onClick={this.addCategories}>Thêm Categories</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default TopicViewItem;
