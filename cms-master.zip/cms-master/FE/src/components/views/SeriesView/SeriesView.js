import React, {Component} from 'react';
import Series from '../../../model/Series.js'
import SeriesViewItem from './SeriesViewItem'
import './SeriesView.scss';
import TopicServce from '../../../api/topic-api.js'

class SeriesView extends Component {

    constructor(props){
        super(props);
        this.state = {series: []};
    }

    createData = () => {
        TopicServce.getTopic(this.fetchDate);

    }

    fetchDate = (series_list) => {
        this.setState({
            series: series_list
        })
    }

    addSeries = () =>{
        let seriesTmp = this.state.series;
        let a = new Series();
        a.createNewSeries();
        seriesTmp.push(a);
        this.setState({
          series: seriesTmp
        })
    }

    updateSeries = (index, series) => {
        const seriesTmp = this.state.series;
        seriesTmp[index] = series;

        this.setState({
            series: seriesTmp
        })
    }

    componentWillMount = () => {
        this.createData();
    }

    getCurrentTime = () => {
        let date = new Date();
        return date.getTime();
    }

    deleteSeriesByIndex = (index) => {
        //console.log(index+"");
        let seriesTmp = this.state.series;
        seriesTmp.splice(index, 1);
        //console.log(seriesTmp);
        this.setState({
          series: seriesTmp
        })
        //console.log("delete");
    }

    addTopic = () => {

    }

    render() {
        //console.log(this.state.series);
        return (
            <div>
                <div className="series">
                    <div id="accordion">
                        {this.state.series.map((item, index) => (
                            <SeriesViewItem history={this.props.history} key={index} item={item} id={index} deleteSeriesByIndex={this.deleteSeriesByIndex} update={this.updateSeries} index={index}/>
                        ))}
                        <div>
                            <button className="btn btn-link" onClick={this.addSeries}>Thêm Series</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}
export default SeriesView;
