import React, { Component } from 'react';
import './History.scss';
import * as action from "../../../../action/history-action";
import * as modalAction from '../../../../action/modal-action';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import Pagination from "material-ui-flat-pagination";
import CssBaseline from "@material-ui/core/CssBaseline";
import Button from '@material-ui/core/Button';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
const theme = createMuiTheme();
class History extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const {historyData,actions} = this.props;
    actions.fetchData(historyData.pageNumber,historyData.pageSize,false);
  }

  handleClick(offset) {
    const {historyData, actions} = this.props;
    actions.updateHistory({
      pageNumber: offset / historyData.pageSize,
      offset : offset
    })
  }

  componentDidUpdate (prevProps, prevState) {
    if(prevProps.historyData.offset !== this.props.historyData.offset) {
      const {historyData,actions} = this.props;
      actions.fetchData(historyData.pageNumber,historyData.pageSize,false);
    }
  }
 
  goDetailRequest(id) {
    this.props.parent.props.history.push(`/request/detail/${id}`);
  } 

  showModalUploadForm() {
    this.props.modalActions.toggleDialog(true);
  }
  openModal(item) {
    if(item === null) {
      this.props.modalActions.updateModalData({
        showModal: true,
        fileList: [{id: 1, description:"GOS"}, {id:2, description:"GOS TEST"}],
        notice: '',
        testCodeList: [1, 2, 3],
        version: '',
        idRequest: null,
        selectedDate: new Date('2014-08-18T21:11:54'),
        selectDeadLine: new Date('2014-08-18T21:11:54'),
      })
    } else {
      this.props.modalActions.updateModalData({
        showModal: true,
        notice : item.notice,
        version: item.version,
        selectedDate: new Date('2014-08-18T21:11:54'),
        selectDeadLine: new Date('2014-08-18T21:11:54'),
        fileList: item.fileAttachmentList,
        idRequest: item.id
      })
    }
  }
  render() {
    const {
      historyData } = this.props;
    return (
      <div className="container block-history" style={{ marginTop: 50 }}>
        <div className="block-title"> 
        <h5>History</h5>
        <Button variant="contained" color="primary" className="btn-start" onClick={() =>this.openModal(null)}>
          Create Test
        </Button>
        </div>
        <table className="table  table-hover table-striped">
          <thead>
            <tr className="block-header-table">
              <th>ID</th>
              <th>Create Date</th>
              <th>Status</th>
              <th>Version</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {historyData.requestTest && historyData.requestTest.map((item, index) => {
              return (
                <tr key={item.id} >
                  <td onClick= {() => this.goDetailRequest(item.id)}>{item.id}</td>
                  <td onClick= {() => this.goDetailRequest(item.id)}>{item.createDate}</td>
                  <td onClick= {() => this.goDetailRequest(item.id)}>{item.status}</td>
                  <td onClick= {() => this.goDetailRequest(item.id)}>{item.version}</td>
                  <td>  
                    <Button variant="contained" color="primary" onClick={() => this.openModal(item)}>
                        Retest
                    </Button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>

        <MuiThemeProvider theme={theme}>
          <CssBaseline />
          <Pagination
            limit={historyData.pageSize}
            offset={historyData.offset}
            total={historyData.totalElement}
            onClick={(e, offset) => this.handleClick(offset)}
          />
        </MuiThemeProvider>

      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    historyData : state.historyData,
    modal : state.modal
  }
}

const mapDispatchToProps = (dispatch) => {
   return {
    actions: bindActionCreators(action, dispatch),
    modalActions: bindActionCreators(modalAction,dispatch)
   }
}

export default connect(mapStateToProps,mapDispatchToProps) (History);
