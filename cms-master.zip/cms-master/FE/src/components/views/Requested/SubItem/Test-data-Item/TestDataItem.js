import React, { Component } from "react";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import './TestDataItem.scss';
import Dropzone from 'react-dropzone'
import {CloudUploadOutlined} from '@material-ui/icons';
import FileItem from '../../../../items/file/fileItem';
class TestDataItem extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="container">
                <ExpansionPanel>
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                    >
                        <Typography className="heading">Test data:</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails className="content">
                        <Dropzone onDrop={acceptedFiles => console.log(acceptedFiles)}>
                            {({ getRootProps, getInputProps }) => (
                                <section >
                                    <div {...getRootProps() } className="block-drag-drop">
                                        <input {...getInputProps() } />
                                        <p>Drag 'n' drop some files here, or click to select files</p>
                                         <CloudUploadOutlined className="image-upload" />
                                    </div>
                                </section>
                            )}
                        </Dropzone>
                        <div className="file-out"> 
                                         <FileItem />
                                         <FileItem />
                                         <FileItem />
                                         <FileItem />
                                         <FileItem />
                                         </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>
        )
    }
}

export default TestDataItem;