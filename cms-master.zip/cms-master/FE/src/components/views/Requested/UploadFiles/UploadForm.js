import React, { Component } from 'react';
import * as ServerApi from "../../../../api/server-api";
import * as IdConstant from '../../../../constants/id-constant';
import TextField from '@material-ui/core/TextField';
import DateFnsUtils from '@date-io/date-fns';
import { Input } from '@material-ui/core';
import '../UploadFiles/UploadForm.scss';
import Button from '@material-ui/core/Button';
import { Modal } from 'react-bootstrap';
import { bindActionCreators } from 'redux';
import * as action from "../../../../action/history-action";
import * as modalActions from "../../../../action/modal-action";
import { connect } from 'react-redux';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';

import RequestInfomationItem from '../SubItem/Request-Infomation-Item/RequestInfomationItem';
import TestDataItem from '../SubItem/Test-data-Item/TestDataItem';
import TestPreconditionItem from '../SubItem/Test-precondition-Item/TestPreconditionItem';
class UploadForm extends Component {

    constructor(props) {
        super(props);
        this.state = {
            fileGSO: null,
            fileGSOTest: null,
            fileList: []
        }
    }
    handleChange = (name, e) => {
        console.log(name + ":" + e.target.value);
        this.props.modal_actions.updateModalData({
            [name]: e.target.value
        })

    }

    handleDateChange = (name, date) => {
        console.log(name + " : " + date);
        this.props.modal_actions.updateModalData({
            [name]: date
        })

    }

    handleFileChange = (fileDto) => {
        let data = new FormData();
        data.append('file', fileDto);
        ServerApi.uploadFile(data, response => {
            let file = {
                id: response.value.id,
                description: "GOS test"
            }
            let { fileList } = this.props.modal;
            fileList.push(file);
            this.props.modal_actions.updateModalData({
                fileList: fileList
            })
        }, err => {
            alert(err.message);
        })

    }

    sentRequest() {
        const { fileList, notice, testCodeList, version, } = this.props.modal;
        const { history_data, actions, modal_actions } = this.props
        let _request_test = history_data.requestTest;
        const body = {
            fileList: fileList,
            notice: notice,
            testCodeList: testCodeList,
            version: version
        }
        ServerApi.updateTestRequest(body, response => {
            if (response.id) {
                this.runTest(response.id);
                _request_test.push(response);
                actions.updateHistory({ requestTest: _request_test });
                modal_actions.updateModalData({
                    idRequest: response.id
                })
            }
        }, err => {
            alert(err.message);
        })
    }

    runTest(id) {
        const { historyData, actions } = this.props;
        ServerApi.runTestRequest(id, response => {
            if (response.status === 404) {
                alert(response.message);
            }
            actions.fetchData(historyData.pageNumber, historyData.pageSize, true);
        }, err => {
            alert(err.message);
        })
    }



    handleSubmit = (e) => {
        const { idRequest } = this.props.modal;
        if (idRequest) {
            this.runTest(idRequest);
        } else {
            this.sentRequest();
        }
        e.preventDefault();
    }
    closeModal = () => {
        this.props.modal_actions.toggleDialog(false);
    }

    render() {
        const {
            modal
        } = this.props;
        return (
            <Modal
                {...this.props}
                size="md"
                aria-labelledby={IdConstant.UPLOAD_FORM}
                centered
            >
                <form onSubmit={(e) => this.handleSubmit(e)}>
                    <Modal.Header closeButton>
                        <Modal.Title id={IdConstant.UPLOAD_FORM}>
                            Request Test
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <RequestInfomationItem />
                        <TestPreconditionItem />
                        <TestDataItem />
                     
                        {/* <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <KeyboardDatePicker
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                fullWidth
                                margin="normal"
                                label="Date "
                                value={modal.selectedDate}
                                onChange={(date) => this.handleDateChange('selectedDate', date)}
                                KeyboardButtonProps={{
                                    'aria-label': 'change date',
                                }}
                            />
                            <TextField
                                label="Version"
                                fullWidth
                                value={modal.version}
                                onChange={(e) => this.handleChange('version', e)}
                                margin="normal"
                            />
                            <Input
                                label="Choose File"
                                type="file"
                                fullWidth
                                className="input-file"
                                onChange={(e) => this.handleFileChange(e.target.files[0])}
                            />

                            <Input
                                label="Choose File"
                                type="file"
                                fullWidth
                                className="input-file"
                                onChange={(e) => this.handleFileChange(e.target.files[0])}
                            />
                            <TextField
                                label="Notice"
                                fullWidth
                                value={modal.notice}
                                onChange={(e) => this.handleChange('notice', e)}
                                margin="normal"
                            />
                            <KeyboardDatePicker
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                fullWidth
                                margin="normal"
                                label="Dead line"
                                value={modal.selectDeadLine}
                                onChange={(date) => this.handleDateChange('selectDeadLine', date)}
                                KeyboardButtonProps={{
                                    'aria-label': 'change date',
                                }}
                            />

                        </MuiPickersUtilsProvider> */}
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="contained" onClick={() => this.closeModal()}>
                            Close
                        </Button>
                        <Button variant="contained" color="primary" type="submit">
                            Run
                        </Button>
                    </Modal.Footer>
                </form>
            </Modal>

        )
    }
}
const mapStateToProps = (state) => {
    return {
        history_data: state.historyData,
        modal: state.modal
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(action, dispatch),
        modal_actions: bindActionCreators(modalActions, dispatch)
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(UploadForm)
