export const BASE_URL = "https://stg-apps.vietjack.com:8086";
export const GET_HISTORY_POINT = '/api/test-request/get-test-request';
export const UPLOAD_FILE_POINT = '/api/file/upload-single-file';
export const UPDATE_TEST_REQUEST = '/api/test-request/update-test-request';
export const RUN_TEST_REQUEST = '/api/test-request/run-test-request';
