export const RANDOM_NUMBER = 'RANDOM_NUMBER';
export const HISTORY = 'HISTORY';
export const MODAL_SHOW = 'MODAL_SHOW';
export const UPDATE_MODAL_DATA = 'UPDATE_MODAL_DATA';