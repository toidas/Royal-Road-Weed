export const UPLOAD_FORM = 'uploadForm'
export const UPLOAD_FORM_C = '#uploadForm'
export const DETAIL_REQUEST = 'detailRequest'
export const DETAIL_REQUEST_C = '#detailRequest'