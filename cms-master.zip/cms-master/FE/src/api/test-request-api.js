import { BASE_URL } from "../constants/api-constants";


export function get_api(endpoint, headers = {}, params = {}) {
  console.log(BASE_URL + endpoint);
  let url = new URL(BASE_URL + endpoint);
  
  Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

  return fetch(url, {
    method: "GET",
    mode: "cors",
    cache: "no-cache",
    headers: headers
  }).then(response => response.json());
}

export function post_api(endpoint, headers = {}, body = {}) {
  if (!(body instanceof FormData)) {
    body = JSON.stringify(body);
  }

  return fetch(BASE_URL + endpoint, {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    headers: headers,
    body: body
  }).then(response => response.json());
}

export function upload_api(endpoint, headers = {}, body) {

  return fetch(BASE_URL + endpoint, {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    headers: headers,
    body: body
  }).then(response => response.json());
}

export function post(endpoint, headers = {}, body = {}) {
  if (!(body instanceof FormData)) {
    body = JSON.stringify(body);
  }

  return fetch(BASE_URL + endpoint, {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    headers: headers,
    body: body
  }).then(response => response.json());
}


export function put(endpoint, headers = {}, body = {}) {
  if (!(body instanceof FormData)) {
    body = JSON.stringify(body);
  }

  return fetch(BASE_URL + endpoint, {
    method: "PUT",
    mode: "cors",
    cache: "no-cache",
    headers: headers,
    body: body
  }).then(response => response.json());
}

export function del(endpoint, headers = {}, params = {}) {
  let url = new URL(BASE_URL + endpoint);
  Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

  return fetch(url, {
    method: "DELETE",
    mode: "cors",
    cache: "no-cache",
    headers: headers
  }).then(response => response.json());
}
