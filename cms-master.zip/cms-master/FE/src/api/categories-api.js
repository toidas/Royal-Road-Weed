import { get_api,post_api} from './test-request-api';
// import * as BASE_URL from '../constants/api-constants';

class CategoriesServce{

    static categoriesId = "";

    static getCategories(categoriesUrl,fetchData) {
        const url = "/categories-url/"+categoriesUrl;
        const params = {
            
        }
        let mHeader = {"Content-Type": "application/json"}
        get_api(url,mHeader,params).then(
            response => {
                fetchData(response);
            }
        ).catch(err =>{
            console.log(err);
        })
    }

    static saveCategories(body,fetchData,artiicleUrl) {
        const url = "/categories";
        let mHeader = {"Content-Type": "application/json"}
        post_api(url, mHeader, body)
            .then(response => 
                {
                    if(artiicleUrl == null){
                        fetchData(response);
                    }
                }
            )
            .catch(err => console.log(err));
    }

    static saveCategoriesAndGoArtilce(body) {
        return new Promise(function(resolve, reject) { 
            const url = "/categories";
            let mHeader = {"Content-Type": "application/json"}
            post_api(url, mHeader, body)
                .then(response => 
                    {
                        resolve(response)
                    }
                )
                .catch(err => reject(err));
        });
        
    }
}

export default CategoriesServce