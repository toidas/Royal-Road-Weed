import { get_api,post_api} from './test-request-api';
// import * as BASE_URL from '../constants/api-constants';

class ArticleServce{

    static articleID = "tieng-viet-lop-3_tap-doc-cau-be-thong-minh";
    static categoriesID = "tieng-viet-lop-3_index";

    static getArticle(categoriesUrl,fetchData) {
        const url = "/articles-url/"+categoriesUrl;
        const params = {
            
        }
        let mHeader = {"Content-Type": "application/json"}
        get_api(url,mHeader,params).then(
            response => {
                fetchData(response);
            }
        ).catch(err =>{
            console.log(err);
        })
    }

    static getRelated(categoriesUrl,fetchData) {
        const url = "/articles-same-category/"+categoriesUrl;
        const params = {
            
        }
        let mHeader = {"Content-Type": "application/json"}
        get_api(url,mHeader,params).then(
            response => {
                fetchData(response);
            }
        ).catch(err =>{
            console.log(err);
        })
    }

    static saveArticle(body,fetchData) {
        const url = "/articles";
        let mHeader = {"Content-Type": "application/json"}
        post_api(url, mHeader, body)
            .then(response => console.log(response))
            .catch(err => console.log(err));
    }
}

export default ArticleServce