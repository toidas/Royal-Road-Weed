import { get_api, upload_api, post_api } from './test-request-api';
import * as BASE_URL from '../constants/api-constants';
const headers = {
    Authorization: "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxIiwiaWF0IjoxNTcxMDM0MDAzLCJleHAiOjE1NzE4OTgwMDN9.RtKFzacnrcSMnh-0ikmtwS_yKts0spoJek-o7RU96spv9QgJRbuESoBdVUfKFv1GTKy8cm8l2LnTE0NxDLlwmQ",
};

export function getHistory(pageNum,pageSize,onSucess,onError) {
    const url = BASE_URL.GET_HISTORY_POINT;
    const params = {
        pageNum: pageNum,
        pageSize: pageSize
    }
    let mHeader = {...headers,"Content-Type": "application/json"}
    get_api(url,mHeader,params).then(
        response => {
          onSucess(response);
        }
    ).catch(err =>{
        onError(err);
    })
}

export function uploadFile(formdata,onSucess,onError){
   const url = BASE_URL.UPLOAD_FILE_POINT;
   upload_api(url,headers,formdata).then(
        response => {
          onSucess(response);
        }
   ).catch(err => {
       onError(err);
   })
}

export function updateTestRequest(body,onSucess,onError){
    const url = BASE_URL.UPDATE_TEST_REQUEST;
    let mHeader = {...headers,"Content-Type": "application/json"}
    post_api(url,mHeader,body).then(
        response => {
          onSucess(response);
        }
    ).catch(err => {
        onError(err);
    })
}

export function runTestRequest(id, onSucess, onError) {
    const url = `${BASE_URL.RUN_TEST_REQUEST}/${id}`;
    let mHeader = {...headers,"Content-Type": "application/json"}
    get_api(url,mHeader).then(
        response => {
          onSucess(response);
        }
    ).catch(err => onError(err))
}

export function makeGetRequest(onSucess,onError) {
   const url = `/api/sso/getToken`;
   let mHeader = {...headers,"Content-Type": "application/json"}
   get_api(url,mHeader).then(
    response => {
      onSucess(response);
    }
   ).catch(err => onError(err))
}