import { get_api, upload_api, post_api, get_api_series } from './test-request-api';
import * as BASE_URL from '../constants/api-constants';

class TopicServce{
    static getTopic(fetchData) {
        const url = "/series";
        const params = {

        }
        let mHeader = {"Content-Type": "application/json"}
        get_api(url,mHeader,params).then(
            response => {
                fetchData(response);
            }
        ).catch(err =>{
            console.log(err);
        })
    }

    static saveTopic(body, fetchData) {
        const url = "/series";
        let mHeader = {"Content-Type": "application/json"}
        post_api(url, mHeader, body)
            .then(response => fetchData(response))
            .catch(err => console.log(err));
    }
}

export default TopicServce
