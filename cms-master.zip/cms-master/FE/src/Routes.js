import React from 'react';
import { Switch, Redirect } from 'react-router-dom';

import { RouteWithLayout } from '../src/components/routing';
import { Main as MainLayout , Minimal as MinimalLayout} from '../src/components/layouts';

import {
  ArticlesiesView as ArticlesiesView,
  CategoriesView as CategoriesView,
  SeriesView as SeriesView,
  Document as DocumentView,
  SignIn as SignInView,
  NotFound as NotFoundView
} from '../src/components/views';
import DetailRequest from '../src/components/views/Requested/DetailRequest/DetailRequest'

var Routes = () => {
  return (
    <Switch>
      <Redirect
        exact
        from="/"
        to="/series"
      />
      <RouteWithLayout
        component={ArticlesiesView}
        exact
        layout={MainLayout}
        path="/articles"
      />
      <RouteWithLayout
        component={ArticlesiesView}
        exact
        layout={MainLayout}
        path="/articles/:url/:id"
      />
      <RouteWithLayout
        component={CategoriesView}
        exact
        layout={MainLayout}
        path="/categories"
      />
      <RouteWithLayout
        component={CategoriesView}
        exact
        layout={MainLayout}
        path="/categories/:url"
      />
      <RouteWithLayout
        component={SeriesView}
        exact
        layout={MainLayout}
        path="/series"
      />
      <RouteWithLayout
        component={SignInView}
        exact
        layout={MinimalLayout}
        path="/sign-in"
      />
      <RouteWithLayout
        component={NotFoundView}
        exact
        layout={MinimalLayout}
        path="/not-found"
      />
      <Redirect to="/not-found" />
    </Switch>
  );
};

export default Routes;
