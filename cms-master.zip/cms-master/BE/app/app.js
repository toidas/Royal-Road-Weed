// require('dotenv').config();
const fs = require('fs');
const http = require('http');
const https = require('https');
const express = require('express');
const mongoose = require('mongoose');

const app = express();
const connectDb = require('./src/core/connection');
const userRouter = require('./src/routes/user');
const dataRouter = require('./src/routes/data');
const PORT =  process.env.PORT || 8080;
const HTTPS_PORT =  process.env.PORT || 8080;

app.use(express.json());
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.use(userRouter);
app.use(dataRouter);

if (process.env.APP_ENV == 'prod' || process.env.APP_ENV == 'production') {
    const privateKey  = fs.readFileSync('ssl/vietjack_app.key', 'utf8');
    const certificate = fs.readFileSync('ssl/vietjack_app.pem', 'utf8');
    const ca1 = fs.readFileSync('ssl/vietjack_app_ca1.crt', 'utf8');
    const ca2 = fs.readFileSync('ssl/vietjack_app_ca2.crt', 'utf8');
    const ca3 = fs.readFileSync('ssl/vietjack_app_ca3.crt', 'utf8');
    const credentials = {key: privateKey, cert: certificate, ca: [ca1, ca2, ca3]};
    const httpsServer = https.createServer(credentials, app);
    httpsServer.listen(HTTPS_PORT, function() {
        console.log(`Listening on ${HTTPS_PORT}`);
        connectDb().then(() => {
            console.log('MongoDb connected');
        });
    });
} else {
    const httpServer = http.createServer(app);
    httpServer.listen(PORT, function() {
        console.log(`Listening on ${PORT}`);
        connectDb().then(() => {
            console.log('MongoDb connected');
        });
    });
}
