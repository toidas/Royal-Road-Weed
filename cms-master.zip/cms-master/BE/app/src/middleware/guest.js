const jwt = require('jsonwebtoken');
const User = require('../models/User');

const guest = async (req, res, next) => {
    if (req.user) {
        return res.status(400).send({ error: 'User is login!' });
    }

    return next();
};

module.exports = guest;
