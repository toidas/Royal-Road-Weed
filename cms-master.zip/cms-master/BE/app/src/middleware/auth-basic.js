const jwt = require('jsonwebtoken');
const User = require('../models/User');

const imeiAuth = async (req, res, next) => {
    const imei = req.header('imei');

    if (!imei) {
        req.user = null;
        req.token = null;
        next();
        return;
    }

    try {
        const user = await User.findOrCreateByImei(imei);
        req.user = user;
        req.token = null;
        next();
    } catch (error) {
        req.user = null;
        req.token = null;
        next();
    }
};

const storeImei = async (user, req) => {
    const imei = req.header('imei');

    if (!imei) {
        return;
    }

    for (let i = 0; i < user.imeis.length; i++) {
        if (user.imeis[i].imei == imei) {
            return;
        }
    }

    await user.storeImei(imei);
};

const authBasic = async (req, res, next) => {
    return next();

    let token = req.header('Authorization');
    if (!token) {
        req.user = null;
        req.token = null;
        imeiAuth(req, res, next);
        return;
    }
    token = token.replace('Bearer ', '');

    if (!token) {
        req.user = null;
        req.token = null;
        imeiAuth(req, res, next);
        return;
    }

    try {
        const data = jwt.verify(token, process.env.JWT_KEY);
        const user = await User.findOne({ _id: data._id, 'tokens.token': token });
        if (!user) {
            throw new Error();
        }
        storeImei(user, req);
        req.user = user;
        req.token = token;

        next();
    } catch (error) {
        res.status(401).send({ error: 'Not authorized to access this resource' });
    }
};

module.exports = authBasic;
