const jwt = require('jsonwebtoken');
const History = require('../models/History');

const guest = async (req, res, next) => {
    if (req.user) {
        const history = new History({
            user_id: req.user._id,
            rq_params: req.params,
            rq_query: req.query,
            route_path: req.route.path
        });
        history.save();
    }

    return next();
};

module.exports = guest;
