// Trạng thái thể hiện thao tác của người dùng
const STATE_DELETE = 0;
const STATE_UPDATE = 1;
const STATE_CREATE = 2;

// Trạng thái thể hiện việc admin đã duyệt hay chưa
const STATUS_NEW = 0;
const STATUS_APPLY = 1;
const STATUS_REJECT = 2;

exports = module.exports = {
    STATE_DELETE,
    STATE_UPDATE,
    STATE_CREATE,

    STATUS_NEW,
    STATUS_APPLY,
    STATUS_REJECT
};
