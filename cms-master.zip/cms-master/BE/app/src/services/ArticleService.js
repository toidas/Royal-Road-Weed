const cheerio = require('cheerio');
const Entities = require('html-entities').XmlEntities;
const utils = require('../core/utils');

const entities = new Entities();
const adsAfter = 25;

const textBlock2Html = (block) => {
    return block.content;
};

const audioBlock2Html = (block) => {
    return `
        <audio controls="">
            <source src="${block.content}" type="audio/mpeg">
        </audio>
    `;
};

const toggleBlock2Html = (block) => {
    const data = JSON.parse(block.content);
    return `
        <section class="toggle">
            <label><i class="icon icon-minus"></i><i class="icon icon-plus"></i><strong style="color:red;">${data.title}</strong></label>
            <div class="toggle-content" style="display: none;">${data.content}</div>
        </section>
    `;
};

const adsBlock2Html = (block) => {
    return '';
};

const componentHasRemove = [
    'Xem Đề kiểm tra',
    'Xem lời giải',
    'Xem chi tiết',
    'Xem bài văn mẫu'
];

const createNewDataContent = () => ({
    type: 0,
    content: ''
});

const createNewAudioContent = (src) => ({
    type: 1,
    content: src
});

const createNewToggleContent = (title, content) => ({
    type: 2,
    content: JSON.stringify({title, content})
});

const createNewAdsContent = () => ({
    type: 3,
    content: 'ads'
});

const makeArticle = ($, middleCol) => {
    const parentUrlElm = middleCol.find('.parent-file');
    middleCol.find('hr').remove();
    parentUrlElm.remove();
    const elements = middleCol.children();
    let titleIndex = 0;

    if (elements.length < 1) {
        throw new Error('Dữ liệu html không được trống');
    }

    const article = {
        title: '',
        data_raw: '',
        data_raw_format: '',
        data: [],
        related: [],
    };

    if (elements[titleIndex].tagName == 'h1' || elements[titleIndex].tagName == 'h2') {
        article.title = $(elements[titleIndex]).text();
    } else {
        // handleLog(`-- no title ${url} ${elements[titleIndex].tagName} ${$(elements[titleIndex]).attr('class')}`);
        for (let j = 1; j < elements.length; j++) {
            // handleLog(`-- find next chil: ${j}`);
            if (elements[j].tagName == 'h1' || elements[j].tagName == 'h2') {
                titleIndex = j;
                article.title = $(elements[j]).text();
                // handleLog(`------ exist: ${article.title}`);
                break;
            }
            // handleLog(`---- not match: ${elements[j].tagName}`);
        }
    }

    // if (!article.title) {
    //     handleLog(`------ No title: ${url}`);
    // }

    let dataContent = createNewDataContent();
    let addTopAds = false;
    let adsRemain = 2;
    let lineCount = 0;

    for (let i = titleIndex; i < elements.length; i++) {
        const chilElm = $(elements[i]);

        if (elements[i].name == 'hr') {
            continue;
        }

        if (!addTopAds && i > titleIndex && elements[i].name == 'p') {
            if (dataContent.content) {
                article.data.push(dataContent);
            }
            article.data.push(createNewAdsContent());
            dataContent = createNewDataContent();
            addTopAds = true;
        }

        // if (i == Math.round(elements.length / 2)) {
        //     if (dataContent.content) {
        //         article.data.push(dataContent);
        //     }
        //     article.data.push(createNewAdsContent());
        //     dataContent = createNewDataContent();
        // }

        if (elements[i].name == 'audio') {
            let audioSource = chilElm.find('source');
            if (dataContent.content) {
                article.data.push(dataContent);
            }

            if (audioSource.length) {
                article.data.push(createNewAudioContent(utils.makeVietjackFullUrl($(audioSource).attr('src'))));
            }
            dataContent = createNewDataContent();

            lineCount++;
            continue;
        }

        if (elements[i].name == 'section' && chilElm.hasClass('toggle')) {
            let toggleTitle = $(chilElm.find('label')).text();
            let toggleContent = $(chilElm.find('.toggle-content')).html()

            if (dataContent.content) {
                article.data.push(dataContent);
            }

            if (toggleTitle && toggleContent) {
                article.data.push(createNewToggleContent(toggleTitle, toggleContent));
            }

            dataContent = createNewDataContent();

            lineCount++;
            continue;
        }

        let relatedLinks = chilElm.find('a');
        if (relatedLinks.length > 0) {
            chilElm.remove();
            continue;
        }

        dataContent.content += utils.cleanHtmlContent($.html(chilElm));
        const chilElmText = chilElm.text();
        article.data_raw += ' ' + chilElmText;


        const chilElmTextWord = chilElmText.split(' ');
        lineCount += Math.floor(chilElmTextWord.length / 10) + 1;

        if (lineCount >= adsAfter && adsRemain > 0) {
            lineCount = 0;
            adsRemain = adsRemain - 1;
            if (dataContent.content) {
                article.data.push(dataContent);
            }
            article.data.push(createNewAdsContent());
            dataContent = createNewDataContent();
        }
    }

    if (dataContent.content) {
        article.data.push(dataContent);
    }

    article.data_raw = utils.formatString(article.data_raw);
    article.data_raw_format = utils.formatUnicodeString(article.data_raw);

    return article;
};

const removeUnuseTag = (middleCol) => {
    middleCol.find('.fb-comments').remove();
    middleCol.find('.breadCrumb').remove();
    middleCol.find('.vj-tabs').remove();
    middleCol.find('.pre-btn').remove();
    middleCol.find('.clearer').remove();
    middleCol.find('.paging-btn').remove();
    middleCol.find('.social-btn').remove();
    middleCol.find('.nxt-btn').remove();
    return middleCol;
};

const parseHtml = (html) => {
    html = `<div id="middle-col">${html}</div>`;
    const content = utils.cleanHtmlContent(utils.cleanContent(html));
    const $ = cheerio.load(content);

    const middleCol = removeUnuseTag($('#middle-col'));

    $('img').each(function() {
        let oldSrc = $(this).attr('src');
        let newSrc = utils.makeVietjackFullUrl(oldSrc);
        $(this).attr('src', newSrc);
    });

    const writeContent = middleCol.html();

    if (!writeContent) {
        throw new Error('Dữ liệu html không hợp lệ');
    }

    return makeArticle($, middleCol);
};

const datablockToHtml = (data) => {
    let htmlContent = '';
    for (let i = 0; i < data.length; i++) {
        const block = data[i];
        switch (block.type) {
            case 0: htmlContent += textBlock2Html(block);
                break;
            case 1: htmlContent += audioBlock2Html(block);
                break;
            case 2: htmlContent += toggleBlock2Html(block);
                break;
            case 3: htmlContent += adsBlock2Html(block);
                break;
        }

    }

    return entities.decode(htmlContent);
};

exports.datablockToHtml = datablockToHtml;
exports.parseHtml = parseHtml;
