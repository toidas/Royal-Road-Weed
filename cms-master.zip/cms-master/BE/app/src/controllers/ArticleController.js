
const mongoose = require('mongoose');
const _ = require('lodash');
const utils = require('../core/utils');
const Category = require('../models/Category');
const Article = require('../models/Article');
const ArticleChanged = require('../models/ArticleChanged');
const ArticleService = require('../services/ArticleService');
const changedState = require('../config/changed-state');

const createArticleChanged = (article, state) => {
    const data = {
        article: article,
        state: state,
        status: changedState.STATUS_NEW,
    };
    const articleChangedModel = new ArticleChanged(data);
    articleChangedModel.save();
};

const transformArticle = (article) => {
    if (!article) {
        return null;
    }

    return {
        _id: article._id,
        title: article.title,
        series_url: article.series_url,
        topic_id: article.topic_id,
        category_url: article.category_url,
        url: utils.vietjackWebUrl(article.url),
        html: ArticleService.datablockToHtml(article.data),
        related: article.related,
        created_at: article.created_at
    };
};

const makeRelated = async (related) => {
    const articleUrls = _.map(related, 'url');

    const articleRelateds = await Article.find({
        url: { $in: articleUrls }
    }, '_id title url');

    return _.map(articleRelateds, item => ({
        article_id: item._id,
        title: item.title,
        url: item.url
    }));
};

exports.count = async (req, res) => {
    const articles = await Article.count();
    res.json(articles);
};

exports.create = async (req, res) => {
    try {
        const {_id, title, url, related, html, category_url} = req.body;
        const category = await Category.findOne({url: category_url});
        let articleModel = await Article.findById(_id);

        if (!category) {
            throw new Error('Không tồn tại category với url: ' + category_url);
        }

        if (!articleModel) {
            throw new Error('Không tồn tại article với id: ' + _id);
        }

        const oldHtml = ArticleService.datablockToHtml(articleModel.data);
        if (oldHtml != html) {
            const article = ArticleService.parseHtml(html);
            articleModel.data = article.data;
            articleModel.data_raw = article.data_raw;
            articleModel.data_raw_format = article.data_raw_format;
        }

        if (url) {
            articleModel.url = utils.vietjackAppUrl(url);
        }

        articleModel.title = title;
        articleModel.related = await makeRelated(related);
        articleModel = await articleModel.save();
        createArticleChanged(articleModel, changedState.STATE_UPDATE);

        res.send(transformArticle(articleModel));
    } catch (error) {
        res.status(400).send({error: error.message});
    }
};

exports.delete = async (req, res) => {
    const articleId = req.params.articleId;
    const articleModel = await Article.findOne({_id: articleId});
    if (articleModel) {
        createArticleChanged(articleModel, changedState.STATE_DELETE);
        await Article.deleteOne({_id: articleId});
    }

    res.json({status: 'ok'});
};

exports.show = async (req, res) => {
    const articleId = req.params.articleId;
    if (!mongoose.Types.ObjectId.isValid(articleId)) {
        res.json(null);
        return;
    }

    const article = await Article.findById(req.params.articleId);
    res.json(transformArticle(article));
};

exports.showByUrl = async (req, res) => {
    const article = await Article.findOne({url: req.params.url});
    res.json(transformArticle(article));
};

exports.listSameCategory = async (req, res) => {
    const articles = await Article.find({category_url: req.params.categoryUrl}, '_id title url');
    const result = [];
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        result.push({
            _id: '',
            article_id: article._id,
            title: article.title,
            url: article.url
        });
    }
    res.json(result);
};
