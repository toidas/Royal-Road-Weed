const mongoose = require('mongoose');
const utils = require('../core/utils');
const Category = require('../models/Category');
const {ARTICLE_TYPE} = require('../models/Category');
const Article = require('../models/Article');
const CategoryChanged = require('../models/CategoryChanged')
const changedState = require('../config/changed-state');

const createCategoryChanged = (category, state) => {
    const data = {
        category: category,
        state: state,
        status: changedState.STATUS_NEW,
    };
    const categoryChangedModel = new CategoryChanged(data);
    categoryChangedModel.save();
};

const makeChildren = async (children, category) => {
    if (!Array.isArray(children)) {
        return [];
    }

    for (let i = 0; i < children.length; i++) {
        const child = children[i];
        if (!child._id) {
            child._id = utils.newObjectId();
            child.url = await Article.generateUrl(child.title);
        }

        if (Array.isArray(child.children)) {
            child.children = await makeChildren(child.children, category);
        }

        if (child.type == ARTICLE_TYPE) {
            await Article.updateOrCreateByMiniData(child, category.series_url, category.topic_id, category.url);
        }
    }

    return children;
};

exports.create = async (req, res) => {
    try {
        const {_id, title, text, children, type, group, group_name} = req.body;
        let categoryModel = await Category.findById(_id);
        let chStatus = changedState.STATE_UPDATE;

        if (!categoryModel) {
            categoryModel = new Category();
            categoryModel.url = await Category.generateUrl(title);
            chStatus = changedState.STATE_CREATE;
        }

        categoryModel.title = title;
        categoryModel.text = text;
        categoryModel.children = await makeChildren(children, categoryModel);
        categoryModel.type = type;
        categoryModel.group = group;
        categoryModel.group_name = group_name;
        categoryModel = await categoryModel.save();
        createCategoryChanged(categoryModel, chStatus);

        res.send(categoryModel);
    } catch (error) {
        res.status(400).send({error: error.message});
    }
};

exports.delete = async (req, res) => {
    const categoryId = req.params.categoryId;
    const categoryModel = await Category.findOne({_id: categoryId});
    if (categoryModel) {
        createCategoryChanged(categoryModel, changedState.STATE_DELETE);
        await Category.deleteOne({_id: categoryId});
    }
    res.json({status: 'ok'});
};

exports.show = async (req, res) => {
    const categoryId = req.params.categoryId;
    if (!mongoose.Types.ObjectId.isValid(categoryId)) {
        res.json(null);
        return;
    }

    const category = await Category.findById(req.params.categoryId);
    res.json(category);
};

exports.showByUrl = async (req, res) => {
    const category = await Category.findOne({url: req.params.url});
    res.json(category);
};
