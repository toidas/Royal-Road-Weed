const Series = require('../models/Series');
const utils = require('../core/utils');
const Category = require('../models/Category');
const SeriesChanged = require('../models/SeriesChanged')
const changedState = require('../config/changed-state');

const createSeriesChanged = (series, state) => {
    const data = {
        series: series,
        state: state,
        status: changedState.STATUS_NEW,
    };
    const seriesChangedModel = new SeriesChanged(data);
    seriesChangedModel.save();
};

const makeCategories = async (categories) => {
    if (!Array.isArray(categories)) {
        return [];
    }

    for (let i = 0; i < categories.length; i++) {
        const category = categories[i];
        if (!category._id) {
            category._id = utils.newObjectId();
            category.url = await Category.generateUrl(category.title);
        }
        const categoryModel = await Category.updateOrCreateByMiniData(category);
        category.category_id = categoryModel._id;
    }

    return categories;
};

const makeTopics = async (topics) => {
    if (!Array.isArray(topics)) {
        return [];
    }

    for (let i = 0; i < topics.length; i++) {
        const topic = topics[i];
        if (!topic._id) {
            topic._id = utils.newObjectId();
        }

        topic.categories = await makeCategories(topic.categories);
    }

    return topics;
};

exports.index = async (req, res) => {
    const series = await Series.find();
    res.json(series);
};

exports.create = async (req, res) => {
    try {
        const {_id, title, topics} = req.body;
        let seriesModel = await Series.findById(_id);
        let chStatus = changedState.STATE_UPDATE;

        if (!seriesModel) {
            seriesModel = new Series();
            seriesModel.url = await Series.generateUrl(title);
            chStatus = changedState.STATE_CREATE;
        }

        seriesModel.title = title;
        seriesModel.topics = await makeTopics(topics);
        seriesModel = await seriesModel.save();
        createSeriesChanged(seriesModel, chStatus);

        res.send(seriesModel);
    } catch (error) {
        res.status(400).send({error: error.message});
    }
};

exports.delete = async (req, res) => {
    const seriesId = req.params.seriesId;
    const seriesModel = await Series.findOne({_id: seriesId});
    if (seriesModel) {
        createSeriesChanged(seriesModel, changedState.STATE_DELETE);
        await Series.deleteOne({_id: seriesId});
    }
    res.json({status: 'ok'});
};

exports.show = async (req, res) => {
    const seriesId = req.params.seriesId;
    if (!mongoose.Types.ObjectId.isValid(seriesId)) {
        res.json(null);
        return;
    }

    const series = await Series.findById(seriesId);
    res.json(series);
};

exports.showByUrl = async (req, res) => {
    const series = await Series.find({url: req.params.url});
    res.json(series.length ? series[0] : null);
};

exports.topics = async (req, res) => {
    const series = await Series.findOne({url: req.params.url});
    if (series) {
        return res.json(series.topics);
    }

    res.json(null);
};

exports.topicShow = async (req, res) => {
    const series = await Series.findOne({url: req.params.url});
    const topicId = req.params.topicId;
    if (series) {
        for (let i = 0; i < series.topics.length; i++) {
            if (topicId == series.topics[i]._id) {
                return res.json(series.topics[i]);
            }
        }
    }

    res.json(null);
};
