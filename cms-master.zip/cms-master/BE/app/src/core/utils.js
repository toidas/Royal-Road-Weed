const fs = require('fs');
const cheerio = require('cheerio');
const archiver = require('archiver');
const mongoose = require('mongoose');

const trimChar = (s, c) => {
    if (c === "]") c = "\\]";
    if (c === "\\") c = "\\\\";
    return s.replace(new RegExp("^[" + c + "]+|[" + c + "]+$", "g"), "");
}

const SGK = 1;
const SBT = 2;

const groupKeyMap = {
    'sách giáo khoa': SGK,
    'sách/vở bài tập': SBT,
    'khác': SBT
};

const groupKeyDefault = SBT;
const groupNameDefault = 'khác';

const groupKey = name => groupKeyMap[name] || groupKeyDefault;

const makeFileJspFullPath = path => `${__dirname}/../../../vietjack/${trimChar(path, '/')}`;
const importFileFullPath = path => `${__dirname}/import/${trimChar(path, '/').replace(/\/index\.jsp$/, '\.js').replace(/\.jsp$/, '\.js')}`;
const parseEngineFullPath = path => `${__dirname}/import/parse-engine/${trimChar(path, '/').replace(/\/index\.jsp$/, '\.js').replace(/\.jsp$/, '\.js')}`;

const existJspFile = path => fs.existsSync(makeFileJspFullPath(path));

const importArticle = (articleUrl, articleTitle) => {
    const importFileDefault = importFileFullPath('articles/parse-default');
    const importFile = parseEngineFullPath(articleUrl);
    const importFileSubDefault = importFile.replace(/\.js$/, '/default.js');
    const importEngine = require(fs.existsSync(importFile) ? importFile : (fs.existsSync(importFileSubDefault) ? importFileSubDefault : importFileDefault));
    importEngine(articleUrl, articleTitle);
};

const importCategory = (categoryUrl, categoryTitle) => {
    const importFileDefault = importFileFullPath('categories/parse-default');
    const importFile = parseEngineFullPath(categoryUrl);
    const importFileSubDefault = importFile.replace(/\.js$/, '/default.js');
    const importEngine = require(fs.existsSync(importFile) ? importFile : (fs.existsSync(importFileSubDefault) ? importFileSubDefault : importFileDefault));
    importEngine(categoryUrl, categoryTitle);
};

const importSeries = async (seriesUrl, seriesTitle, categoryGroup) => {
    const importFileDefault = importFileFullPath('series/parse-default');
    const importFile = parseEngineFullPath(seriesUrl);
    const importFileSubDefault = importFile.replace(/\.js$/, '/default.js');
    const importEngine = require(fs.existsSync(importFile) ? importFile : (fs.existsSync(importFileSubDefault) ? importFileSubDefault : importFileDefault));
    await importEngine(seriesUrl, seriesTitle, categoryGroup);
};

const cleanContent = content => content.replace(/\n/gi, '').replace(/<%(.*?)%>/gi, '');
const cleanHref = href => href.replace(/^\.\.\//, '').replace(/[\t]/g, '');

const makeUrlId = url => url.replace(/\.\.\//, '').replace(/\.jsp$/, '').replace(/\//gi, '_');

const removeUnuseTag = (middleCol) => {
    middleCol.find('.fb-comments').remove();
    middleCol.find('.breadCrumb').remove();
    middleCol.find('.vj-tabs').remove();
    middleCol.find('.pre-btn').remove();
    middleCol.find('.clearer').remove();
    middleCol.find('.paging-btn').remove();
    middleCol.find('.social-btn').remove();
    middleCol.find('.nxt-btn').remove();
    return middleCol;
};

const makeVietjackFullUrl = link => link.replace(/^\.\.\//, 'https://vietjack.com/');
const vietjackWebUrl = link => link ? `https://vietjack.com/${link.replace(/_/g, '/')}.jsp` : '';
const vietjackAppUrl = link => link ? makeUrlId(link.replace('https://vietjack.com/', '')) : '';

const cleanHtmlContent = content => {
    const replaceItems = [
        [/display:(\s+)?inline(;)?/g, ''],
        [/display:(\s+)?inline-block(;)?/g, ''],
    ];

    for (let i = 0; i < replaceItems.length; i++) {
        content = content.replace(replaceItems[i][0], replaceItems[i][1]);
    }

    return content;
};

const getLinks = (filePath) => {
    const links = [];
    const fullPath = makeFileJspFullPath(filePath);
    if (!fs.existsSync(fullPath)) {
        console.error('[utils][getLinks] No such file');
        console.error(fullPath);
        return links;
    }

    let content = cleanContent(fs.readFileSync(fullPath, 'utf8'));
    const $ = cheerio.load(content);
    const middleCol = removeUnuseTag($('.middle-col'));

    middleCol.find('a').map((index, item) => {
        const href = $(item).attr('href');
        if (!href) {
            return;
        }

        const chilLink = cleanHref(href);
        if (chilLink.match(/\.jsp$/)) {
            links.push({
                title: $(item).text(),
                url: chilLink
            });
        }
    });
if (filePath == 'series/lop-12.jsp') {
    console.log(links);
}
    return links;
};

const zipFolder = (srcFolder, zipFilePath, callback) => {
	let output = fs.createWriteStream(zipFilePath);
	let zipArchive = archiver('zip');

	output.on('close', function() {
		callback();
	});

	zipArchive.pipe(output);

	zipArchive.bulk([
		{ cwd: srcFolder, src: ['**/*'], expand: true }
	]);

	zipArchive.finalize(function(err, bytes) {
		if(err) {
			callback(err);
		}
	});
}

const writeFileSync = (filePath, content) => {
    const directories = path.dirname(filePath);
    fs.mkdirSync(directories, { recursive: true }, (err) => {
        if (err) throw err;
    });
    fs.writeFileSync(filePath, content);
};

const getTopicType = (topicTitle) => {
    const topics = [
        {
           regex: /^đề/,
           type: 1
        },
        {
           regex: /^(môn tiếng việt|môn ngữ văn)$/,
           type: 2
        },
        {
           regex: /^môn toán$/,
           type: 3
        },
        {
           regex: /^môn tiếng anh$/,
           type: 4
        },
        {
           regex: /^môn tự nhiên và xã hội$/,
           type: 5
        },
        {
           regex: /^môn đạo đức$/,
           type: 6
        },
        {
           regex: /^môn tin học$/,
           type: 7
        },
        {
           regex: /^môn khoa học$/,
           type: 8
        },
        {
           regex: /^môn lịch sử$/,
           type: 9
        },
        {
           regex: /^(môn địa lí|môn địa lý)$/,
           type: 10
        },
        {
           regex: /^(môn vật lý|môn vật lí)$/,
           type: 11
        },
        {
           regex: /^môn sinh học$/,
           type: 12
        },
        {
           regex: /^môn gdcd$/,
           type: 13
        },
        {
           regex: /^môn công nghệ$/,
           type: 14
        },
        {
           regex: /^môn hóa học$/,
           type: 15
        },
        {
            regex: /.+/,
            type: 0
        }
    ];

    topicTitle = topicTitle.toLowerCase();
    for (let i = 0; i < topics.length; i++) {
        if (topicTitle.match(topics[i].regex)) {
            return topics[i].type;
        }
    }

    return 0;
};

const formatString = str => str.trim().replace(/\s\s+/g, ' ').replace(/\t/g, '').toLowerCase();

const formatUnicodeString = str => {

    // str = str.toLowerCase();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g,"e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\-|\"|\&|\#|\[|\]|~|$|_/g, '');
    str = str.replace(/\s\s+/g, ' ');

    // str = str.replace(/-+-/g,"-"); //thay thế 2- thành 1-
    // str = str.replace(/^\-+|\-+$/g,"");

    return str;
};

const limitLength = (input, maxLength) => {
    //trim the string to the maximum length
    let trimmedString = input.substr(0, maxLength);
    //re-trim if we are in the middle of a word
    return trimmedString.substr(0, Math.min(trimmedString.length, trimmedString.lastIndexOf(" ")));
};

const newObjectId = () => mongoose.Types.ObjectId();

exports = module.exports = {
    trimChar,
    cleanHref,
    existJspFile,
    makeFileJspFullPath,
    importFileFullPath,
    parseEngineFullPath,
    importArticle,
    importCategory,
    importSeries,
    cleanContent,
    makeVietjackFullUrl,
    makeUrlId,
    getLinks,
    removeUnuseTag,
    cleanHtmlContent,
    groupKey,
    groupNameDefault,
    getTopicType,
    writeFileSync,
    limitLength,
    formatUnicodeString,
    formatString,
    vietjackWebUrl,
    vietjackAppUrl,
    newObjectId
};
