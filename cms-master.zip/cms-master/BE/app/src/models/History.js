const mongoose = require('mongoose');

const paramsSchema = new mongoose.Schema({});

const historySchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    rq_params: {
        type: Map,
        of: String,
        required: true
    },
    rq_query: {
        type: Map,
        of: String,
        required: true
    },
    route_path: {
        type: String,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

const History = mongoose.model('History', historySchema);

exports = module.exports = History;
