const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');
const slugify = require('vietnamese-slug');

const dataBlockSchema = new mongoose.Schema({
    type: {
        type: Number,
        required: true
    },
    content: {
        type: String,
        required: true
    }
});

const shortArticleSchema = new mongoose.Schema({
    article_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Article',
        required: true
    },
    title: {
        type: String,
        required: true
    },
    url: {
        type: String,
        required: true
    }
});

const articleSchema = new mongoose.Schema({
    url: {
        type: String,
        index: true,
        required: true
    },
    series_url: {
        type: String,
        required: false
    },
    topic_id: {
        type: String,
        required: false
    },
    category_url: {
        type: String,
        required: false
    },
    parent_url: {
        type: String,
        required: false
    },
    title: {
        type: String,
        required: true
    },
    data_raw: {
        type: String,
        required: false
    },
    data_raw_format: {
        type: String,
        required: false
    },
    data: {
        type: [dataBlockSchema],
        required: true
    },
    more: {
        type: [shortArticleSchema],
        required: true
    },
    related: {
        type: [shortArticleSchema],
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

articleSchema.statics.generateUrl = async (title) => {
    let urlRoot = slugify(title || '');
    let url = urlRoot;
    let i = 0;
    do {
        let article = await Article.findOne({url});
        if (!article) {
            return url;
        }
        i = i + 1;
        url = `${urlRoot}-${i}`;
    } while (i < 100);

    return '';
};

articleSchema.statics.updateOrCreateByMiniData = async (miniArticle, seriesUrl, topicId, categoryUrl) => {
    const article = await Article.findOne({url: miniArticle.url});
    if (article) {
        if (article.title == miniArticle.title) {
            return article;
        }

        article.title = miniArticle.title;
        return await article.save();
    }

    const data = {
        url: miniArticle.url,
        series_url: seriesUrl,
        topic_id: topicId,
        category_url: categoryUrl,
        parent_url: miniArticle.parent_url,
        title: miniArticle.title,
        data_raw: '',
        data_raw_format: '',
        data: [],
        more: [],
        related: []
    };

    const articleModel = new Article(data);
    return await articleModel.save();
};

articleSchema.plugin(mongoosePaginate);
articleSchema.index({title: 'text', data_raw: 'text'});
const Article = mongoose.model('Article', articleSchema);

exports = module.exports = Article;
