const mongoose = require('mongoose');
const slugify = require('vietnamese-slug');
const Series = require('./Series');

const CATEGORY_TYPE = 0;
const ARTICLE_TYPE = 1;

const subCategorySchema = new mongoose.Schema({
    // article_id: {
    //     type: mongoose.Schema.Types.ObjectId,
    //     ref: 'Article',
    //     required: function() {
    //         return this.type == ARTICLE_TYPE;
    //     }
    // },
    title: {
        type: String,
        required: true
    },
    url: {
        type: String,
        required: false
    },
    type: {
        type: Number,
        required: true
    }
});

subCategorySchema.add({children: [subCategorySchema]});

const categorySchema = new mongoose.Schema({
    url: {
        type: String,
        index: true,
        required: true
    },
    series_url: {
        type: String,
        required: false
    },
    topic_id: {
        type: String,
        required: false
    },
    title: {
        type: String,
        required: true
    },
    text:  {
        type: String,
        required: false
    },
    children: {
        type: [subCategorySchema],
        required: true
    },
    type: {
        type: Number,
        required: true
    },
    group: {
        type: Number,
        required: false
    },
    group_name: {
        type: String,
        required: false
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

categorySchema.statics.getCategoriesFromUrl = async (url, topiccId = null) => {
    let categories = await Category.find({url});
    if (!categories.length) {
        return await Series.getCategoriesFromUrl(url, topiccId);
    }

    const categoriesUrl = [];
    for (let i = 0; i < categories.length; i++) {
        categoriesUrl.push(categories[i].url);
    }

    return categoriesUrl;
};

categorySchema.statics.generateUrl = async (title) => {
    let urlRoot = slugify(title || '');
    let url = urlRoot;
    let i = 0;
    do {
        let category = await Category.findOne({url});
        if (!category) {
            return url;
        }
        i = i + 1;
        url = `${urlRoot}-${i}`;
    } while (i < 100);

    return '';
};

categorySchema.statics.updateOrCreateByMiniData = async (miniCategory) => {
    const category = await Category.findOne({url: miniCategory.url});
    if (category) {
        category.title = miniCategory.title;
        category.group = miniCategory.group;
        category.group_name = miniCategory.group_name || '';
        return await category.save();
    }

    const data = {
        url: miniCategory.url,
        title: miniCategory.title,
        text: '',
        children: [],
        type: CATEGORY_TYPE,
        group: miniCategory.group,
        group_name: miniCategory.group_name || ''
    };

    const categoryModel = new Category(data);
    return await categoryModel.save();
};

const Category = mongoose.model('Category', categorySchema);

exports = module.exports = Category;
exports.CATEGORY_TYPE = CATEGORY_TYPE;
exports.ARTICLE_TYPE = ARTICLE_TYPE;
