const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');

const searchSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: true
    },
    content_format: {
        type: String,
        required: true
    },
    type: {
        type: Number,
        required: true
    },
    // series_url topic_id category_url chil_category_id chil_chil_category_id
    // phân cách bởi dấu phẩy
    levels: {
        type: String,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

searchSchema.plugin(mongoosePaginate);
const Search = mongoose.model('Search', searchSchema);

exports = module.exports = Search;
