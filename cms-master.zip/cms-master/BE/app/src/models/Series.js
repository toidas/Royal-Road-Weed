const mongoose = require('mongoose');
const slugify = require('vietnamese-slug');

const shortCategorySchema = new mongoose.Schema({
    category_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        required: true
    },
    title: {
        type: String,
        required: true
    },
    url: {
        type: String,
        required: true
    },
    group: {
        type: Number,
        required: false
    },
    group_name: {
        type: String,
        required: false
    }
});

const topicSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    categories: {
        type: [shortCategorySchema],
        required: true
    },
    type: {
        type: Number,
        required: true
    }
});

const seriesSchema = new mongoose.Schema({
    url: {
        type: String,
        index: true,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    topics: {
        type: [topicSchema],
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

seriesSchema.statics.getCategoriesFromUrl = async (url, topiccId) => {
    let series = await Series.findOne({url});
    if (!series) {
        return [];
    }

    const categoriesUrl = [];

    for (let i = 0; i < series.topics.length; i++) {
        const topic = series.topics[i];
        if (topiccId && topic._id != topiccId) {
            continue;
        }

        for (let j = 0; j < topic.categories.length; j++) {
            categoriesUrl.push(topic.categories[j].url);
        }
    }

    return categoriesUrl;
};

seriesSchema.statics.generateUrl = async (title) => {
    let urlRoot = `series_` + slugify(title || '');
    let url = urlRoot;
    let i = 0;
    do {
        let series = await Series.findOne({url});
        if (!series) {
            return url;
        }
        i = i + 1;
        url = `${urlRoot}-${i}`;
    } while (i < 100);

    return '';
};

const Series = mongoose.model('Series', seriesSchema);

exports = module.exports = Series;
