const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');

const categoryChangedSchema = new mongoose.Schema({
    category: {
        type: Object,
        required: true
    },
    state: {
        type: Number,
        required: true
    },
    status: {
        type: Number,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

categoryChangedSchema.plugin(mongoosePaginate);
const CategoryChanged = mongoose.model('CategoryChanged', categoryChangedSchema);

exports = module.exports = CategoryChanged;
