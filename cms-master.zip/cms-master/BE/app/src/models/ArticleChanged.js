const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');

const articleChangedSchema = new mongoose.Schema({
    article: {
        type: Object,
        required: true
    },
    state: {
        type: Number,
        required: true
    },
    status: {
        type: Number,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

articleChangedSchema.plugin(mongoosePaginate);
const ArticleChanged = mongoose.model('ArticleChanged', articleChangedSchema);

exports = module.exports = ArticleChanged;
