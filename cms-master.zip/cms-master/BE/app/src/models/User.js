const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// token, type, uid, avatar, email, name, phone

const TYPE = {
    FACEBOOK: 0,
    GOOGLE: 1,
};

const userSchema = mongoose.Schema({
    avatar: {
        type: String,
        default: '',
        required: false
    },
    email: {
        type: String,
        default: '',
        required: false,
        lowercase: true,
        // validate: value => {
        //     if (value && !validator.isEmail(value)) {
        //         throw new Error({error: 'Invalid Email address'});
        //     }
        // }
    },
    name: {
        type: String,
        default: '',
        required: false,
        trim: true
    },
    phone: {
        type: String,
        default: '',
        required: false,
        trim: true
    },
    birthday: {
        type: Date,
        default: null
    },
    socials: [{
        uid: {
            type: String,
            required: true
        },
        token: {
            type: String,
            required: true
        },
        type: {
            type: Number,
            required: true
        }
    }],
    password: {
        type: String,
        required: false,
        minLength: 7
    },
    tokens: [{
        token: {
            type: String,
            required: true
        }
    }],
    imeis: [{
        imei: {
            type: String,
            required: true
        }
    }],
    created_at: {
        type: Date,
        default: Date.now
    }
})

userSchema.pre('save', async function (next) {
    // Hash the password before saving the user model
    const user = this;
    if (user.password && user.isModified('password')) {
        user.password = await bcrypt.hash(user.password, 8);
    }
    next();
});

userSchema.methods.generateAuthToken = async function() {
    // Generate an auth token for the user
    const user = this;
    const token = jwt.sign({_id: user._id}, process.env.JWT_KEY);
    user.tokens = user.tokens.concat({token});
    await user.save();
    return token;
};

userSchema.methods.getInfo = function() {
    const user = this;
    const {_id, avatar, email, name, phone, birthday} = user;
    return {_id, avatar, email, name, phone, birthday};
};

userSchema.statics.findByCredentials = async (email, password) => {
    // Search for a user by email and password.
    const user = await User.findOne({ email} );
    if (!user) {
        throw new Error({ error: 'Invalid login credentials' });
    }
    const isPasswordMatch = await bcrypt.compare(password, user.password);
    if (!isPasswordMatch) {
        throw new Error({ error: 'Invalid login credentials' });
    }
    return user;
};

userSchema.statics.findOrCreateBySocial = async (uid, token, type, userData = {}) => {
    // Search for a user by email and password.
    let user = await User.findOne({'socials.uid': uid, 'socials.token': token, 'socials.type': type});

    if (user) {
        return user;
    }

    const {avatar, name, phone, birthday} = userData;
    let email = userData.email;
    const social = {uid, token, type};
    if (email) {
        console.log(email)
        email = email.trim().toLowerCase();
        user = await User.findOne({email});
        if (user) {
            user.socials.push(social);
            await user.save();

            return user;
        }
    }

    user = new User({
        avatar,
        email,
        name,
        phone,
        birthday,
        socials: [social]
    });
    await user.save();

    return user;
};

userSchema.statics.findOrCreateByImei = async (imei) => {
    // Search for a user by imei.

    let users = await User.find({'imeis.imei': imei});

    for (let i = 0; i < users.length; i++) {
        const user = users[i];
        if (user.email || user.name || user.phone || (user.socials.length > 0)) {
            await user.removeImei(imei);
        } else {
            return user;
        }
    }

    user = new User({imeis: [{imei}]});
    await user.save();

    return user;
};

userSchema.methods.storeImei = async function(imei) {
    const user = this;
    user.imeis.push({imei});
    await user.save();
    return user;
};

userSchema.methods.removeImei = async function(imei) {
    const user = this;
    for (let i = 0; i < user.imeis.length; i++ ) {
        if (user.imeis[i].imei == imei) {
            user.imeis.splice(i, 1);
            break;
        }
    }

    await user.save();
    return user;
};

const User = mongoose.model('User', userSchema);

module.exports = User;
