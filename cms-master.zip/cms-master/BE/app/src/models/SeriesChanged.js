const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');

const seriesChangedSchema = new mongoose.Schema({
    series: {
        type: Object,
        required: true
    },
    state: {
        type: Number,
        required: true
    },
    status: {
        type: Number,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

seriesChangedSchema.plugin(mongoosePaginate);
const SeriesChanged = mongoose.model('SeriesChanged', seriesChangedSchema);

exports = module.exports = SeriesChanged;
