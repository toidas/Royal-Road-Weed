const express = require('express');
const authBasicMiddleware = require('../middleware/auth-basic');
const storeHistoryMiddleware = require('../middleware/store-history');
const utils = require('../core/utils');
const SeriesController = require('../controllers/SeriesController');
const CategoryController = require('../controllers/CategoryController');
const ArticleController = require('../controllers/ArticleController');

const router = express.Router();

const historyMiddleware = [authBasicMiddleware];

router.get('/series', historyMiddleware, SeriesController.index);
router.post('/series', historyMiddleware, SeriesController.create);
router.post('/series/:seriesId/delete', historyMiddleware, SeriesController.delete);
router.get('/series/:seriesId', historyMiddleware, SeriesController.show);
router.get('/series-url/:url', historyMiddleware, SeriesController.showByUrl);
router.get('/series-url/:url/topics', historyMiddleware, SeriesController.topics);
router.get('/series-url/:url/topics/:topicId', historyMiddleware, SeriesController.topicShow);

router.post('/categories', historyMiddleware, CategoryController.create);
router.post('/categories/:categoryId/delete', historyMiddleware, CategoryController.delete);
router.get('/categories/:categoryId', historyMiddleware, CategoryController.show);
router.get('/categories-url/:url', historyMiddleware, CategoryController.showByUrl);

router.get('/articles', historyMiddleware, ArticleController.count);
router.post('/articles', historyMiddleware, ArticleController.create);
router.post('/articles/:articleId/delete', historyMiddleware, ArticleController.delete);
router.get('/articles/:articleId', historyMiddleware, ArticleController.show);
router.get('/articles-url/:url', historyMiddleware, ArticleController.showByUrl);
router.get('/articles-same-category/:categoryUrl', historyMiddleware, ArticleController.listSameCategory);

module.exports = router;
