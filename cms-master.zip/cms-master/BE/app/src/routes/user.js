const express = require('express');
const User = require('../models/User');
const authBasicMiddleware = require('../middleware/auth-basic');
const authUserMiddleware = require('../middleware/auth-user');
const guestMiddleware = require('../middleware/guest');

const router = express.Router();

const authUser = [authBasicMiddleware, authUserMiddleware];
const guest = [authBasicMiddleware, guestMiddleware];

// router.get('/users', async (req, res) => {
//     const users = await User.find();
//     res.json(users);
// });

// router.get('/users-remove', async (req, res) => {
//     const result = await User.remove({});
//     res.json(result);
// });

/**
 * Login by password
 */
// router.post('/users/login', guest, async (req, res) => {
//     try {
//         const { email, password } = req.body;
//         const user = await User.findByCredentials(email, password);
//         if (!user) {
//             return res.status(401).send({error: 'Login failed! Check authentication credentials'});
//         }
//         const token = await user.generateAuthToken();
//         res.send({ user: user.getInfo(), token });
//     } catch (error) {
//         res.status(400).send({error: error.message});
//     }
// });

/**
 * Login by socials
 */
// router.post('/users/login-social', async (req, res) => {
//     try {
//         const { uid, token, type } = req.body;
//         if (!uid || !token || type === undefined) {
//             throw new Error('uid, token, type is required');
//         }

//         const user = await User.findOrCreateBySocial(uid, token, type, req.body);
//         if (!user) {
//             return res.status(401).send({error: 'Login failed! Check authentication credentials'});
//         }
//         const authToken = await user.generateAuthToken();
//         res.send({user: user.getInfo(), token: authToken });
//     } catch (error) {
//         res.status(400).send({error: error.message});
//     }
// });

/**
 * View logged in user profile
 */
// router.get('/users/me', authUser, async (req, res) => {
//     res.send({user: req.user.getInfo()});
// });


/**
 * update user profile
 */
// router.post('/users/me', authUser, async (req, res) => {
//     try {
//         const user = req.user;
//         const canUpdateField = ['email', 'name', 'phone', 'birthday'];
//         canUpdateField.forEach(element => {
//             if (req.body[element]) {
//                 user[element] = req.body[element];
//             }
//         });
//         await user.save();
//         res.send({user: req.user.getInfo()});
//     } catch (error) {
//         res.status(400).send(error);
//     }
// });

/**
 * Log user out of the application
 */
// router.post('/users/me/logout', authUser, async (req, res) => {
//     try {
//         req.user.tokens = req.user.tokens.filter((token) => {
//             return token.token != req.token;
//         })
//         await req.user.save();
//         res.send();
//     } catch (error) {
//         res.status(400).send({error: error.message});
//     }
// });

/**
 * Log user out of all devices
 */
// router.post('/users/me/logoutall', authUser, async (req, res) => {
//     try {
//         req.user.tokens.splice(0, req.user.tokens.length);
//         await req.user.save();
//         res.send();
//     } catch (error) {
//         res.status(400).send({error: error.message});
//     }
// });

module.exports = router;
