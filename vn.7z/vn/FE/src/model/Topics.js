class Topic{
    url = "";
    categories = "";
    type = "";

    createTopic(url,categories,type){
        this.url = url;
        this.categories = categories;
        this.type = type;
    }
}

export default Topic