class Categories{
    url = "";
    title = "";
    created_at = "";
    level = 0;
    categories = [];

    createNewCategories(level){
        this.url = "New Categories";
        this.title = "New Categories";
        this.level = level;
    }
}

export default Categories