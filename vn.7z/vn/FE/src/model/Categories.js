class Categories{
    _id = null;
    url = "";
    title = "";
    level = 0;
    children = [];
    type = 0;

    createNewCategories(level){
        this.url = "New Categories";
        this.title = "New Categories";
        this.level = level;
    }
}

export default Categories