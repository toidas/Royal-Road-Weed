import React, { Component } from 'react';
import { ClearOutlined } from '@material-ui/icons';
import './notifyItem.scss';
class NotifyItem extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="root">
                <ClearOutlined />
                <span> aaaa </span>
            </div>
        )
    }
}

export default NotifyItem;