import React, {Component} from 'react';
import { ClearOutlined } from '@material-ui/icons';
import './fileItem.scss';
class FileItem extends Component {
    constructor(props){
        super(props);
    }

    render() {
        return (
            <div className="root">
              <ClearOutlined /> 
              <span> image.jpg </span>
            </div>
        )
    }
}

export default FileItem;