import React, {Component} from 'react';
import Categories from '../../../model/Categories.js'
import CategoriesViewItem from './CategoriesViewItem'
import './CategoriesView.scss';
import { isThisSecond } from 'date-fns';
class CategoriesView extends Component {

    constructor(props){
        super(props);
        this.state = {categories: [],level : 0};
    }

    createData = () => {
        let categoriesTmp = [];
        for(let i=0;i<5;i++){
            let a = new Categories(); 
            a.createNewCategories(this.state.level);
            categoriesTmp.push(a);
        }
        //console.log(seriesTmp);
        this.setState({
          categories: categoriesTmp
        })
    }

    addCategories = () =>{
        let categoriesTmp = this.state.categories;
        let a = new Categories(); 
        a.createNewCategories(this.state.level);
        categoriesTmp.push(a);
        this.setState({
          categories: categoriesTmp
        })
    }
    

    componentWillMount = () => {
        this.createData();
    }

    getCurrentTime = () => {
        let date = new Date();
        return date.getTime();
    }

    deleteCategoriesByIndex = (index) => {
        //console.log(index+"");
        let categoriesTmp = this.state.categories;
        categoriesTmp.splice(index, 1);
        //console.log(seriesTmp);
        this.setState({
            categories: categoriesTmp
        })
        //console.log("delete");
    }

    render() {
        console.log(this.state.categories);
        return (
            
            <div>
                <div class="series">
                    <div id="accordion">
                        {this.state.categories.map((item, index) => (
                            <CategoriesViewItem deleteCategoriesByIndex={this.deleteCategoriesByIndex} history={this.props.history} item={item} id={index} level={this.state.level+1}/>
                        ))}
                        <div>
                            <button class="btn btn-link" onClick={this.addCategories}>Thêm Categories</button>
                        </div>
                    </div>    
                </div>
            </div>
        )
    }

}
export default CategoriesView;