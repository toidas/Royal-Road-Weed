import React, {Component} from 'react';
import Categories from '../../../../model/Categories.js'
import './CategoriesViewItem.scss';

class CategoriesViewItem extends Component {

    constructor(props){
        super(props);
        this.state = {categories : new Categories(), target: '',targetID: '',dataParentID: ''};
        
    }

    componentDidUpdate = (prevProps,prevState) => {
        if(prevProps.item !== this.props.item) {
             this.setState({
                 target: "#"+this.props.level+this.props.id,
                 targetID: ""+this.props.level+this.props.id,
                 dataParentID: "#accordion"+this.props.level,
                 categories: this.props.item
            })
        }
        //console.log(this.props.id);
    }

    componentDidMount = () => {
        this.setState({
            target: "#"+this.props.level+this.props.id,
            targetID: ""+this.props.level+this.props.id,
            dataParentID: "#accordion"+this.props.level,
            categories: this.props.item
        })
        console.log("#"+this.props.level+this.props.id);
    }

    addCategories = () => {
        let categoriesParent = this.state.categories;
        let categoriesChil = categoriesParent.children;
        let categories = new Categories();
        categories.createNewCategories(this.props.level);
        categoriesChil.push(categories);
        this.setState({
          categories: categoriesParent
        })
        //console.log("click them");
    }

    saveTopic = () => {

    }

    saveCategories = () => {
        console.log(this.state.categories);
    }

    deleteTopic = () => {

    }

    deleteCategories = () => {
        this.props.deleteCategoriesByIndex(this.props.id);
    }    

    changeTitle = (e) => {
        let categories = this.state.categories;
        categories.title = e.target.value;
        this.setState({
            categories: categories
        })
    }

    deleteCategoriesByIndex = (index) => {
        //console.log(index+"");

        let categoriesParent = this.state.categories;
        let categoriesChil = categoriesParent.children;
        categoriesChil.splice(index, 1);
        this.setState({
            categories: categoriesParent
        })
    }

    goArticle = () => {
        //this.props.history.push("/articles");
        let categoriesParent = this.state.categories;
        categoriesParent.type = 1;
        this.setState({
            categories: categoriesParent
        })

    }

    render() {
        
        return (
            <div class="card">
                {this.state.categories.type == 0 ?
                <div class="card-header"  >
                <h5 class="mb-0">
                    
                    <button class="btn btn-link" data-toggle="collapse" data-target={this.state.target} aria-expanded="false">
                    {"Click"}
                    </button>
                        
                    
                    <input type="text" value={this.state.categories.title} onChange={this.changeTitle}/>
                    {this.props.level == 1 ?
                        <button class="btn btn-link" onClick={this.saveCategories}>Save</button>:null
                    }
                    <button class="btn btn-link" onClick={this.deleteCategories}>Delete</button>
                    {this.state.categories.children.length == 0 && this.props.level > 0 && this.state.categories._id != null ? 
                        <button class="btn btn-link" onClick={this.goArticle}>Go</button>:null
                    }
                </h5>
                </div>
                :
                <div class="card-header" style={{backgroundColor: "#8CC152"}} >
                <h5 class="mb-0">     
                    
                    <input type="text" value={this.state.categories.title} onChange={this.changeTitle}/>
                    {this.props.level == 1 ?
                        <button class="btn btn-link" onClick={this.saveCategories}>Save</button>:null
                    }
                    <button class="btn btn-link" onClick={this.deleteCategories}>Delete</button>
                    {this.state.categories.children.length == 0 && this.props.level > 0 && this.state.categories._id != null ? 
                        <button class="btn btn-link" onClick={this.goArticle}>Go</button>:null
                    }
                </h5>
                </div>
                }   

                <div id={this.state.targetID} class="collapse"  data-parent={this.state.dataParentID}>
                <div class="card-body">
                    {this.state.categories.children.map((item, index) => (
                         <div>
                             <CategoriesViewItem deleteCategoriesByIndex={this.deleteCategoriesByIndex} history={this.props.history} item={item} id={index} level={this.props.level+1}/>
                        </div>
                    ))}
                    <div>
                        <button class="btn btn-link" onClick={this.addCategories}>Thêm Categories</button>
                    </div>
                </div>
                </div>
            </div>
        )
    }
}

export default CategoriesViewItem;