import React, {Component} from 'react';
import Multiselect from 'react-widgets/lib/Multiselect';
import TextareaAutosize from 'react-textarea-autosize';

import './ArticleViewItem.scss';

class ArticleViewItem extends Component {

    constructor(props){
        super(props);
        this.state = {
            article : {},
            arget: ''
        };
    }

    render() {
        const relatedArticle = [
            { _id: 0, name: 'Soạn bài: Tổng quan văn học Việt Nam', url: 'url' },
            { _id: 1, name: 'Soạn bài: Hoạt động giao tiếp bằng ngôn ngữ', url: 'url' },
            { _id: 2, name: 'Soạn bài: Khái quát văn học dân gian Việt Nam', url: 'url'},
            { _id: 3, name: 'Soạn bài: Hoạt động giao tiếp bằng ngôn ngữ (tiếp theo)', url: 'url' },
        ];


        return (
            <div className='container-fluid article-item'>
                <form>
                    <div className='form-group'>
                        <label for='title'>Tiêu đề</label>
                        <input type='email' className='form-control' id='title' />
                    </div>
                    <div className='form-group'>
                        <label for='url'>Url</label>
                        <input type='email' className='form-control' id='url' />
                    </div>
                    <div className='form-group'>
                        <label for='related'>Bài viết liên quan</label>
                        <Multiselect
                            data={relatedArticle}
                            textField='name'
                            caseSensitive={false}
                            minLength={3}
                            filter='contains'
                        />
                    </div>
                    <div className='form-group'>
                        <label for='data'>Nôi dung HTML</label>
                        <TextareaAutosize className='form-control' minRows={15} inputRef={tag => (this.textarea = tag)} />
                    </div>
                </form>
            </div>
        )
    }
}

export default ArticleViewItem;
