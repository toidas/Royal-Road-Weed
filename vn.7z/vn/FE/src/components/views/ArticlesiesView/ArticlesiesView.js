import React, {Component} from 'react';
import ArticleViewItem from './ArticleViewItem'

class ArticlesiesView extends Component {
    render() {
        //console.log(this.state.series);
        return (
            <div>
                <ArticleViewItem />
            </div>
        );
    }
}

export default ArticlesiesView;
