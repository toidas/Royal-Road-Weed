import React, { Component } from 'react';
import './SignIn.scss';
import { FormControl, Checkbox, Button , Form} from 'react-bootstrap';
import cookie from 'react-cookie';
import IconLogin from '../../../constants/assets/images//ic-login.png';
import IconLogout from '../../../constants/assets/images//ic-logout.png';
import * as apiServer from '../../../api/server-api';
var checkGetUser = false;

class SignIn extends Component {

  constructor(props) {
    super(props);
    this.state = {
      isDisabled: false,
      showLastLogin: false,
      accessIp: '',
      lastLogin: '',
      authorities: {},
      isCheckBtnLogoutGlobal: true,
    }
    // console.log(this.props.history.push('/dashboard'));
  }

  componentDidMount() {
    this.getTokenByADSSO();
  }

  getTokenByADSSO() {

    apiServer.makeGetRequest(res => {
      if (res.data.id_token && res.data.id_token !== "" && localStorage.getItem('check') === 'true') {
        document.cookie = "crowd.token_key_portal=" + res.data.id_token + ";path=/";
        document.cookie = "crowd.token_key=" + res.data.id_token + ";path=/";
        this.setState({
          isDisabled: false,
          showLastLogin: true,
          accessIp: res.data.accessIp,
          lastLogin: res.data.lastLogin,
          authorities: res.data.authorities
        });
        checkGetUser = true;
      }
    }, err => {
      this.setState({
        isDisabled: false,
        showLastLogin: false
      });
    })
  }

  loginWithADSSO = () => {
    // localStorage.setItem('check', 'true');
    // if (window.location.hostname === "107.113.53.217") {
    //   window.location.href = 'https://107.113.53.217:1130/saml/login'
    // } else if (window.location.hostname === "10.252.249.72") {
    //   window.location.href = 'https://10.252.249.72:12608/saml/login'
    // } else if (window.location.hostname === "10.252.249.73" || window.location.hostname === "toolhub.sec.samsung.net") {
    //   window.location.href = 'https://10.252.249.73:12608/saml/login'
    // } else {
    //   window.location.href = 'https://localhost:44364/saml/login?idp=http://sts-dev.secsso.net/adfs/services/trust'
    // }
  }


  globalSignOut = () => {
    // if (window.location.hostname === "107.113.53.217") {
    //   window.location.href = 'https://107.113.53.217:1130/saml/logout'
    // } else if (window.location.hostname === "10.252.249.72") {
    //   window.location.href = 'https://10.252.249.72:12608/saml/logout'
    // } else if (window.location.hostname === "10.252.249.73" || window.location.hostname === "toolhub.sec.samsung.net") {
    //   window.location.href = 'https://10.252.249.73:12608/saml/logout'
    // } else {
    //   window.location.href = 'https://107.113.53.217:1130/saml/logout'
    // }
  }

  submitLogin = () => {
    
  }

  render() {
    let minutes = (new Date(this.state.lastLogin)).getMinutes();
    minutes = minutes < 10 ? '0' + minutes : minutes;
    return (
      <div className="login">
        <div className="login-container">
          <div className="dimmed"></div>
          <div className="login-form-container">         
              <Form>
                <Form.Group controlId="formBasicEmail">
                  <Form.Label>Email address</Form.Label>
                  <Form.Control type="email" placeholder="Enter email" />
                </Form.Group>
                
                <Form.Group controlId="formBasicPassword">
                  <Form.Label>Password</Form.Label>
                  <Form.Control type="password" placeholder="Password" />
                </Form.Group>
                <Button variant="primary" type="button"  onClick={this.submitLogin}>
                  Submit
                </Button>
              </Form>
            </div>
          </div>
      </div>
    )
  }

}
export default SignIn;