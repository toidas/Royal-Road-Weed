import React, {Component} from 'react';
import Series from '../../../model/Series.js'
import SeriesViewItem from './SeriesViewItem'
import './SeriesView.scss';
class SeriesView extends Component {

    constructor(props){
        super(props);
        this.state = {series: []};
    }

    createData = () => {
        let seriesTmp = [];
        for(let i=0;i<5;i++){
            let a = new Series(); 
            a.randomData(i);
            console.log(a);
            seriesTmp.push(a);
        }
        //console.log(seriesTmp);
        this.setState({
          series: seriesTmp
        })
    }

    addSeries = () =>{
        let seriesTmp = this.state.series;
        let a = new Series(); 
        a.createNewSeries();
        seriesTmp.push(a);
        this.setState({
          series: seriesTmp
        })
    }

    componentWillMount = () => {
        this.createData();
    }

    getCurrentTime = () => {
        let date = new Date();
        return date.getTime();
    }

    deleteSeriesByIndex = (index) => {
        console.log(index+"");
        let seriesTmp = this.state.series;
        seriesTmp.splice(index, 1);
        //console.log(seriesTmp);
        this.setState({
          series: seriesTmp
        })
        //console.log("delete");
    }

    render() {
        //console.log(this.state.series);
        return (
            <div>
                <div class="series">
                    <div id="accordion">
                        {this.state.series.map((item, index) => (
                            <SeriesViewItem item={item} id={index} deleteSeriesByIndex={this.deleteSeriesByIndex}/>
                        ))}
                        <div>
                            <button class="btn btn-link" onClick={this.addSeries}>Thêm Series</button>
                        </div>
                    </div>    
                </div>
            </div>
        )
    }

}
export default SeriesView;