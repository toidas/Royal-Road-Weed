import React, {Component} from 'react';
import Series from '../../../../model/Series.js'
import Topic from '../../../../model/Topics.js'
import './SeriesViewItem.scss';

class SeriesViewItem extends Component {

    constructor(props){
        super(props);
        this.state = {series : new Series(), target: ''};
        
    }

    componentDidUpdate = (prevProps,prevState) => {
        if(prevProps.item !== this.props.item) {
             this.setState({
                 target: "#"+this.props.id,
                 series: this.props.item
            })
        }
        //console.log(this.props.id);
    }

    componentDidMount = () => {
        this.setState({
            target: "#"+this.props.id,
            series: this.props.item
        })
        //console.log(this.props.id);
    }

    addTopic = () => {
        let series = this.state.series;
        let topics = series.topics;
        let topic = new Topic();
        topic.createTopic("New Topic","New Categories","New Type");
        topics.push(topic);
        this.setState({
          series: series
        })
        //console.log("click them");
    }

    saveTopic = () => {

    }

    saveSeries = () => {

    }

    deleteTopic = () => {

    }

    deleteSeries = () => {
        this.props.deleteSeriesByIndex(this.props.id);
    }    

    changeTitle = (e) => {
        let series = this.state.series;
        series.title = e.target.value;
        this.setState({
          series: series
        })
    }

    render() {
        return (
            <div class="card">
                <div class="card-header" id="myCollapsible">
                <h5 class="mb-0">
                    <button class="btn btn-link" data-toggle="collapse" data-target={this.state.target} aria-expanded="false" aria-controls="collapseOne">
                    {"Click"}
                    </button>
                    <input type="text" value={this.state.series.title} onChange={this.changeTitle}/>
                    <button class="btn btn-link" onClick={this.saveSeries}>Save</button>
                    <button class="btn btn-link" onClick={this.deleteSeries}>Delete</button>
                </h5>
                </div>

                <div id={this.props.id} class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                    {this.state.series.topics.map((item, index) => (
                         <div>
                             <input type="text" value={item.url}/>
                             <button class="btn btn-link" onClick={this.saveTopic}>Save</button>
                             <button class="btn btn-link" onClick={this.deleteTopic}>Delete</button>
                        </div>
                    ))}
                    <div>
                        <button class="btn btn-link" onClick={this.addTopic}>Thêm Topic</button>
                    </div>
                </div>
                </div>
            </div>
        )
    }
}

export default SeriesViewItem;