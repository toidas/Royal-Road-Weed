import React, { Component } from 'react';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import '../Request-Infomation-Item/RequestInfomationItem.scss';
import TextField from '@material-ui/core/TextField';
import DateFnsUtils from '@date-io/date-fns';
import { Input } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as action from "../../../../../action/history-action";
import * as modalActions from "../../../../../action/modal-action";
import InputAdornment from '@material-ui/core/InputAdornment';
import IconButton from '@material-ui/core/IconButton';
import NotifyItem from '../../../../items/notify/notifyItem';
class RequestInformationItem extends Component {
    constructor(props) {
        super(props);
    }

    handleChange = (name, e) => {
        console.log(name + ":" + e.target.value);
        this.props.modal_actions.updateModalData({
            [name]: e.target.value
        })

    }

    handleDateChange = (name, date) => {
        console.log(name + " : " + date);
        this.props.modal_actions.updateModalData({
            [name]: date
        })

    }

    render() {
        const {modal} = this.props;
        return (
            <div className="container">
                <ExpansionPanel>
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography className="heading">Request infomation:</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails className="content">
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>

                            <TextField
                                label="Test item"
                                fullWidth
                                value={modal.testItem}
                                onChange={(e) => this.handleChange('testItem', e)}
                                margin="normal"
                            />

                            <KeyboardDatePicker
                                disableToolbar
                                variant="inline"
                                format="MM/dd/yyyy"
                                fullWidth
                                margin="normal"
                                label="Request date"
                                value={modal.selectDeadLine}
                                onChange={(date) => this.handleDateChange('selectDeadLine', date)}
                                KeyboardButtonProps={{
                                    'aria-label': 'change date',
                                }}
                            />

                            <TextField
                                label="Requester"
                                fullWidth
                                value={modal.requester}
                                onChange={(e) => this.handleChange('requester', e)}
                                margin="normal"
                            />

                            <TextField
                                label="Version"
                                fullWidth
                                value={modal.version}
                                onChange={(e) => this.handleChange('version', e)}
                                margin="normal"
                            />

                            <TextField
                                    label="Notify"
                                    fullWidth
                                    margin="normal"
                                    InputProps={{
                                        endAdornment: (
                                          <InputAdornment position="end">
                                            <IconButton
                                              edge="end"
                                              aria-label="toggle password visibility"
                                            //   onClick={handleClickShowPassword}
                                            //   onMouseDown={handleMouseDownPassword}
                                            >
                                             <AddIcon /> 
                                            </IconButton>
                                          </InputAdornment>
                                        ),
                                      }}
                            />
                            <div className="notify-block"> 
                                <NotifyItem />
                            </div>
                        </MuiPickersUtilsProvider>
                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        history_data: state.historyData,
        modal: state.modal
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(action, dispatch),
        modal_actions: bindActionCreators(modalActions, dispatch)
    }
}

export default  connect(mapStateToProps, mapDispatchToProps) (RequestInformationItem);