import React, { Component } from 'react';
import History from './History/History.js'
import './Request.scss';
import UploadForm from './UploadFiles/UploadForm';
import * as action from './../../../action/modal-action';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
class Request extends Component {

  constructor(props) {
    super(props);
  }


  render() {
    const {modal,actions} = this.props;
    return (
      <div className="block-request" >
        <div className="table-history">
          <History
            parent={this}
            >
          </History>
        </div>
          <UploadForm
            parent={this}
            show={modal.showModal}
            onHide={() => actions.toggleDialog(false)}
           >
          </UploadForm>
      </div>
    )
  }
}
const mapStateToProps = (state) => {
  return {
    modal : state.modal
  }
}

const mapDispatchToProps = (dispatch) => {
   return {
    actions: bindActionCreators(action, dispatch)
   }
}
export default connect(mapStateToProps,mapDispatchToProps) (Request);
