import React, { Component } from 'react';
import '../DetailRequest/DetailRequest.scss';
import * as APIUtils from "../../../../api/test-request-api.js";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';



const renderCustomBarLabel = ({ payload, x, y, width, height, value }) => {
  return <text x={x + width / 2} y={y} fill="#666" textAnchor="middle" dy={-6}>{`${value}`}</text>;
};

class DetailRequest extends Component {
  constructor(props) {
    super(props);
    console.log(Number.parseInt(props.match.params.id));
    this.state ={
      data: []
    }
  }

  componentDidMount(){
    this.getData()
  }

  getData() {
    let id = Number.parseInt(this.props.match.params.id);
    const headers = {
      Authorization: "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxIiwiaWF0IjoxNTY5ODk2MjM4LCJleHAiOjE1NzA3NjAyMzh9.Chilj-rpTxj_fHzYmkOwqO204K-fDjmEZOP8Yuq5IIEOi4K__eNuCeDwm-p2BKA7cD7HC9tTqga4tZijQfK1yg",
      Accept: "application/json"
    };
    APIUtils.get_api(`/api/test-request/get-test-request/${id}`,headers)
    .then(response => {
       console.log(response);
       let listData = response.basicTestList;
       let temp = [];
       listData.forEach(element => {
           let mData = {};
           if(element.testCode === '1') {
              mData = {
                name: 'Verification Test', 
                pass: element.pass ? element.pass : 0,
                fail: element.fail ? element.fail : 0 
              }
           }
           if(element.testCode === '2') {
            mData = {
              name: 'FPS Test', 
              pass: element.pass ? element.pass : 0,
              fail: element.fail ? element.fail : 0 
            }
          }
          if(element.testCode === '3') {
            mData = {
              name: 'Stress Test', 
              pass: element.pass ? element.pass : 0,
              fail: element.fail ? element.fail : 0 
            }
          }
          temp.push(mData);
        
       });
       this.setState({
         data : temp
       })
    })
  }
  render() {
    const {data} = this.state;
    return (
      <div className="block-summary">
        <div className="block-title">
          <h3>SPA AUTOMATION - SUMMARY REPORT </h3>
        </div>

        <table className="table table-bordered">
          <thead className="block-header-table">
            <tr>
              <th>GOS ver</th>
              <th>Date </th>
              <th>Tester</th>
              <th>Total model</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td>1.0.2 version</td>
              <td rowSpan="2">18/9/2019 </td>
              <td>vanson.duong </td>
              <td rowSpan="2">77</td>
            </tr>

            <tr>
              <td>Ver name  2.1.01.1 </td>
              <td>anh.ht6</td>
            </tr>
          </tbody>
        </table>
        <div className="block-part"> <h5>1. Result </h5></div>  
        <BarChart
          width={800}
          height={400}
          data={data}
          margin={{
            top: 5, right: 30, left: 20, bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis domain={[0, 100]} />
          <Tooltip />
          <Legend />
          <Bar dataKey="pass" fill="#5A9BD5" label={renderCustomBarLabel}/>
          <Bar dataKey="fail" fill="#ED7D31" label={renderCustomBarLabel}/>
        </BarChart>
        <div className="block-part"> <h5>2. Detail </h5></div>
        <h5>I. Verification Test </h5>
        <div className="block-link">
          <span>Link log on PLM: </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="#a">Log Verification Test </a>
        </div>
        <table className="table table-bordered">
          <tbody>
            <tr>
              <td className="block-header-table">Group name</td>
              <td rowSpan="2">All model</td>
              <td>beyond0lte </td>
              <td>beyond1lte </td>
              <td>crown_lsi </td>
              <td>crown_qc </td>
              <td>d1_q </td>
              <td>d2_q </td>
              <td>winnerlte </td>
            </tr>

            <tr>
              <td className="block-header-table">Model</td>
              <td>G970F</td>
              <td>G973F</td>
              <td>N960F</td>
              <td>N960U1</td>
              <td>G970U</td>
              <td>N975U</td>
              <td>F900F</td>
            </tr>
            <tr>
              <td className="block-header-table">Case fail</td>
              <td>301;313;314</td>
              <td>403</td>
              <td>101</td>
              <td>309</td>
              <td>309</td>
              <td>309</td>
              <td>309</td>
              <td>401</td>
            </tr>
          </tbody>
        </table>  

        <h5>II. Basic Test </h5>
        <div className="block-link">
          <span>Link log on PLM: </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="#a">Log Basic Test </a>
        </div>

        <table className="table table-bordered">
          <thead className="block-header-table">
            <tr>
              <th>Group name</th>
              <th>Model </th>
              <th>avg_FPS</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td>a50</td>
              <td>A505F </td>
              <td>46.55 </td>
            </tr>
            <tr>
              <td>a7y17 </td>
              <td>A720s</td>
              <td>30.05 </td>
            </tr>
            <tr>
              <td>beyond0lte </td>
              <td>G970U</td>
              <td>46.49 </td>
            </tr>
            <tr>
              <td>beyond1lte </td>
              <td>G973F</td>
              <td>54.14 </td>
            </tr>
            <tr>
              <td>beyond2lte </td>
              <td>G975F</td>
              <td>45.31</td>
            </tr>
            <tr>
              <td>a50</td>
              <td>A505F </td>
              <td>46.55 </td>
            </tr>
            <tr>
              <td>a7y17 </td>
              <td>A720s</td>
              <td>30.05 </td>
            </tr>
            <tr>
              <td>beyond0lte </td>
              <td>G970U</td>
              <td>46.49 </td>
            </tr>
            <tr>
              <td>beyond1lte </td>
              <td>G973F</td>
              <td>54.14 </td>
            </tr>
            <tr>
              <td>beyond2lte </td>
              <td>G975F</td>
              <td>45.31</td>
            </tr>
          </tbody>
        </table>
        <h5>II. Stress Test </h5>
        <div className="block-link">
          <span>Link log on PLM: </span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="#a">Log Stress Test </a>
        </div>
      </div>
       
    )
  }
}

export default DetailRequest