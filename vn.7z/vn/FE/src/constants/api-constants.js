export const BASE_URL = "http://107.113.53.217:1122";
export const GET_HISTORY_POINT = '/api/test-request/get-test-request';
export const UPLOAD_FILE_POINT = '/api/file/upload-single-file';
export const UPDATE_TEST_REQUEST = '/api/test-request/update-test-request';
export const RUN_TEST_REQUEST = '/api/test-request/run-test-request';
